import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text || '',
      html: params.html,
    });
    console.log(`Email sent successfully to ${params.to}`);
    return true;
  } catch (error: any) {
    console.error('SendGrid email error:', error);
    if (error.response && error.response.body && error.response.body.errors) {
      console.error('SendGrid error details:', error.response.body.errors);
    }
    return false;
  }
}

export async function sendInvitationEmail(
  email: string, 
  name: string, 
  role: string, 
  inviteToken: string,
  invitedBy: string = "Watchdog Admin"
): Promise<boolean> {
  const baseUrl = process.env.REPL_URL || 'http://localhost:5000';
  const inviteUrl = `${baseUrl}/invite/${inviteToken}`;
  
  const subject = `Invitation to Join Watchdog Emergency Response System`;
  
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #1a1a1a; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f9f9f9; }
        .button { display: inline-block; background-color: #dc2626; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
        .role-badge { background-color: #dc2626; color: white; padding: 4px 8px; border-radius: 3px; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🚨 Watchdog Emergency Response</h1>
          <p>Emergency Response Coordination Platform</p>
        </div>
        
        <div class="content">
          <h2>You've been invited to join the team!</h2>
          
          <p>Hello <strong>${name}</strong>,</p>
          
          <p><strong>${invitedBy}</strong> has invited you to join the Watchdog Emergency Response System as a <span class="role-badge">${role.toUpperCase()}</span>.</p>
          
          <p><strong>Your Role:</strong> ${role.charAt(0).toUpperCase() + role.slice(1)}</p>
          
          <p>Watchdog is a comprehensive emergency response coordination platform designed for search and rescue operations, emergency management, and field coordination.</p>
          
          <p><strong>Key Features:</strong></p>
          <ul>
            <li>Real-time location tracking and status updates</li>
            <li>Case management and dispatch coordination</li>
            <li>Secure team communications</li>
            <li>Resource and vehicle management</li>
            <li>Interactive mapping and navigation</li>
          </ul>
          
          <p>Click the button below to accept your invitation and set up your account:</p>
          
          <div style="text-align: center;">
            <a href="${inviteUrl}" class="button">Accept Invitation</a>
          </div>
          
          <p><small>This invitation will expire in 7 days. If you have any questions, please contact your administrator.</small></p>
        </div>
        
        <div class="footer">
          <p>© 2025 Watchdog Emergency Response System</p>
          <p>Professional Emergency Coordination Platform</p>
        </div>
      </div>
    </body>
    </html>
  `;
  
  const textContent = `
You've been invited to join Watchdog Emergency Response System!

Hello ${name},

${invitedBy} has invited you to join as a ${role.toUpperCase()}.

Accept your invitation: ${inviteUrl}

Watchdog is a comprehensive emergency response coordination platform for search and rescue operations, emergency management, and field coordination.

This invitation expires in 7 days.

© 2025 Watchdog Emergency Response System
  `;

  // Use a generic sender that works with most SendGrid accounts
  // In production, you should verify this domain in SendGrid
  return await sendEmail({
    to: email,
    from: 'westmichiganwatchdoginitiative@gmail.com', // Verified SendGrid sender
    subject,
    html: htmlContent,
    text: textContent
  });
}