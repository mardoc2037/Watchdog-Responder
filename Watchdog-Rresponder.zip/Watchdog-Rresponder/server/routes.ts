import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { sendInvitationEmail } from "./email";
import { insertUserSchema, insertCaseSchema, insertMessageSchema, insertCaseUpdateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/profile", async (req, res) => {
    try {
      // Mock user for development - in production this would come from session
      const user = await storage.getUserByEmail("test@example.com");
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/user/status", async (req, res) => {
    try {
      const { status, lat, lng } = req.body;
      const userId = "admin-001"; // Use existing admin user for development
      
      console.log(`Updating user ${userId} status to:`, status, `at location:`, lat, lng);
      
      const user = await storage.updateUserStatus(userId, status, lat, lng);
      res.json(user);
    } catch (error) {
      console.error("Status update error:", error);
      res.status(500).json({ message: "Failed to update status" });
    }
  });

  app.post("/api/user/location", async (req, res) => {
    try {
      const { lat, lng } = req.body;
      const userId = "mock-user-id"; // In production, get from session
      
      const user = await storage.updateUserLocation(userId, lat, lng);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update location" });
    }
  });

  app.get("/api/users/active", async (req, res) => {
    try {
      const users = await storage.getActiveUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active users" });
    }
  });

  // Case routes
  app.get("/api/cases", async (req, res) => {
    try {
      const cases = await storage.getAllCases();
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cases" });
    }
  });

  app.get("/api/cases/active", async (req, res) => {
    try {
      const cases = await storage.getActiveCases();
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active cases" });
    }
  });

  app.get("/api/cases/:id", async (req, res) => {
    try {
      const case_ = await storage.getCaseById(req.params.id);
      if (!case_) {
        return res.status(404).json({ message: "Case not found" });
      }
      res.json(case_);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case" });
    }
  });

  app.post("/api/cases", async (req, res) => {
    try {
      const caseData = insertCaseSchema.parse(req.body);
      caseData.createdById = "mock-user-id"; // In production, get from session
      
      const case_ = await storage.createCase(caseData);
      res.status(201).json(case_);
    } catch (error) {
      res.status(400).json({ message: "Invalid case data" });
    }
  });

  app.patch("/api/cases/:id", async (req, res) => {
    try {
      const case_ = await storage.updateCase(req.params.id, req.body);
      res.json(case_);
    } catch (error) {
      res.status(500).json({ message: "Failed to update case" });
    }
  });

  // Message routes
  app.get("/api/messages/case/:caseId", async (req, res) => {
    try {
      const messages = await storage.getMessagesByCase(req.params.caseId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.get("/api/messages/unread/count", async (req, res) => {
    try {
      const userId = "mock-user-id"; // In production, get from session
      const count = await storage.getUnreadMessagesCount(userId);
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });



  // Scanner status endpoint
  app.get("/api/scanner/status", async (req, res) => {
    try {
      res.json({
        connected: true,
        channel: "Emergency Dispatch",
        frequency: "453.825 MHz",
        location: "Kent County, MI",
        signal_strength: Math.floor(Math.random() * 5) + 1,
        last_activity: new Date().toISOString(),
        status: "Active"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get scanner status" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      messageData.senderId = "mock-user-id"; // In production, get from session
      
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid message data" });
    }
  });

  // Broadcast message endpoint for SOS messages
  app.post("/api/messages/broadcast", async (req, res) => {
    try {
      const { content, messageType } = req.body;
      
      // Get all active users
      const users = await storage.getAllUsers();
      const messages = [];
      
      // Use first admin user as sender, or first user if no admin
      const firstUser = users.find(u => u.role === 'admin') || users[0];
      if (!firstUser) {
        throw new Error('No users available for broadcasting');
      }
      
      // Create individual messages for each user
      for (const user of users) {
        const messageData = {
          content,
          messageType: messageType || 'priority_sos',
          senderId: firstUser.id, // Use real existing user for broadcasts
          recipientId: user.id,
        };
        
        const message = await storage.createMessage(messageData);
        messages.push(message);
      }
      
      res.status(201).json({ 
        success: true, 
        messagesSent: messages.length,
        messages 
      });
      
    } catch (error) {
      console.error('Error broadcasting message:', error);
      res.status(400).json({ message: "Failed to broadcast message" });
    }
  });

  // Case update routes
  app.get("/api/cases/:id/updates", async (req, res) => {
    try {
      const updates = await storage.getCaseUpdates(req.params.id);
      res.json(updates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case updates" });
    }
  });

  app.post("/api/cases/:id/updates", async (req, res) => {
    try {
      const updateData = insertCaseUpdateSchema.parse(req.body);
      updateData.caseId = req.params.id;
      updateData.userId = "mock-user-id"; // In production, get from session
      
      const update = await storage.createCaseUpdate(updateData);
      res.status(201).json(update);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  // Evidence routes
  app.get("/api/cases/:id/evidence", async (req, res) => {
    try {
      const evidence = await storage.getEvidenceByCase(req.params.id);
      res.json(evidence);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch evidence" });
    }
  });

  const httpServer = createServer(app);
  
  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to WebSocket');
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        // Broadcast status updates to all connected clients
        if (message.type === 'status_update') {
          wss.clients.forEach((client) => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'status_update',
                userId: message.userId,
                status: message.status,
                timestamp: new Date().toISOString(),
              }));
            }
          });
        }
        
        // Broadcast location updates
        if (message.type === 'location_update') {
          wss.clients.forEach((client) => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'location_update',
                userId: message.userId,
                lat: message.lat,
                lng: message.lng,
                timestamp: new Date().toISOString(),
              }));
            }
          });
        }
        
        // Broadcast new messages
        if (message.type === 'new_message') {
          wss.clients.forEach((client) => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'new_message',
                message: message.message,
                timestamp: new Date().toISOString(),
              }));
            }
          });
        }
        
        // Handle priority SOS messages - Critical priority
        if (message.type === 'priority_sos') {
          console.log(`🚨 PRIORITY SOS from ${message.userName} (${message.userRole}) - ${message.userId} 🚨`);
          
          // Broadcast SOS alert to ALL connected clients
          const sosAlert = {
            type: 'priority_sos',
            userId: message.userId,
            userName: message.userName,
            userRole: message.userRole,
            message: message.message,
            timestamp: message.timestamp,
            priority: 'CRITICAL'
          };
          
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(sosAlert));
            }
          });
        }

        // Handle emergency mode updates - Critical priority
        if (message.type === 'emergency_mode_update') {
          console.log(`🚨 Emergency mode ${message.emergencyMode ? 'ACTIVATED' : 'DEACTIVATED'} by user ${message.userId} 🚨`);
          
          // Broadcast emergency alert to ALL connected clients (including sender for confirmation)
          const emergencyAlert = {
            type: 'emergency_alert',
            userId: message.userId,
            emergencyMode: message.emergencyMode,
            timestamp: new Date().toISOString(),
            message: message.emergencyMode 
              ? '🚨 EMERGENCY MODE ACTIVATED - All units alert 🚨'
              : '✅ Emergency mode deactivated - Normal operations resumed',
            priority: 'CRITICAL'
          };
          
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(emergencyAlert));
            }
          });
        }
        
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(Array.isArray(users) ? users : []);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users", data: [] });
    }
  });

  app.post("/api/admin/invite-user", async (req, res) => {
    try {
      const invitation = await storage.createInvitation(req.body);
      
      // Send invitation email
      const emailSent = await sendInvitationEmail(
        invitation.email,
        invitation.name || 'User',
        invitation.role,
        invitation.inviteToken,
        "Watchdog Admin"
      );
      
      if (emailSent) {
        console.log(`✅ Invitation email sent successfully to ${invitation.email}`);
      } else {
        console.error(`❌ Failed to send invitation email to ${invitation.email}`);
      }
      
      res.json({
        ...invitation,
        emailSent
      });
    } catch (error) {
      console.error('Error creating invitation:', error);
      res.status(400).json({ error: "Failed to create invitation" });
    }
  });

  app.get("/api/admin/invitations", async (req, res) => {
    try {
      const invitations = await storage.getAllInvitations();
      res.json(Array.isArray(invitations) ? invitations : []);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch invitations", data: [] });
    }
  });

  app.get("/api/admin/vehicles", async (req, res) => {
    try {
      const vehicles = await storage.getAllVehicles();
      res.json(Array.isArray(vehicles) ? vehicles : []);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vehicles", data: [] });
    }
  });

  app.post("/api/admin/vehicles", async (req, res) => {
    try {
      const vehicle = await storage.createVehicle(req.body);
      res.json(vehicle);
    } catch (error) {
      console.error('Error creating vehicle:', error);
      res.status(400).json({ error: "Failed to create vehicle" });
    }
  });

  app.get("/api/admin/resources", async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.json(Array.isArray(resources) ? resources : []);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch resources", data: [] });
    }
  });

  app.post("/api/admin/resources", async (req, res) => {
    try {
      const resource = await storage.createResource(req.body);
      res.json(resource);
    } catch (error) {
      console.error('Error creating resource:', error);
      res.status(400).json({ error: "Failed to create resource" });
    }
  });

  app.get("/api/admin/scanner-feeds", async (req, res) => {
    try {
      const scannerFeeds = await storage.getAllScannerFeeds();
      res.json(Array.isArray(scannerFeeds) ? scannerFeeds : []);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch scanner feeds", data: [] });
    }
  });

  app.post("/api/admin/scanner-feeds", async (req, res) => {
    try {
      const scannerFeed = await storage.createScannerFeed(req.body);
      res.json(scannerFeed);
    } catch (error) {
      console.error('Error creating scanner feed:', error);
      res.status(400).json({ error: "Failed to create scanner feed" });
    }
  });

  // Dispatch routes for admin portal
  app.get("/api/dispatches", async (req, res) => {
    try {
      const dispatches = await storage.getAllDispatches();
      res.json(dispatches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dispatches" });
    }
  });

  app.post("/api/dispatches", async (req, res) => {
    try {
      const dispatch = await storage.createDispatch(req.body);
      res.json(dispatch);
    } catch (error) {
      res.status(400).json({ message: "Failed to create dispatch" });
    }
  });

  app.patch("/api/users/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const user = await storage.updateUserStatus(id, status);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Failed to update user status" });
    }
  });

  return httpServer;
}
