import { 
  users, 
  cases, 
  dispatches, 
  messages, 
  caseUpdates, 
  evidence,
  vehicles,
  resources,
  scannerFeeds,
  invitations,
  type User, 
  type InsertUser,
  type Case,
  type InsertCase,
  type Dispatch,
  type InsertDispatch,
  type Message,
  type InsertMessage,
  type CaseUpdate,
  type InsertCaseUpdate,
  type Evidence,
  type InsertEvidence,
  type Vehicle,
  type InsertVehicle,
  type Resource,
  type InsertResource,
  type ScannerFeed,
  type InsertScannerFeed,
  type Invitation,
  type InsertInvitation,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, sql } from "drizzle-orm";
import crypto from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: string, status: string, lat?: number, lng?: number): Promise<User>;
  updateUserLocation(id: string, lat: number, lng: number): Promise<User>;
  getActiveUsers(): Promise<User[]>;

  // Case methods
  getAllCases(): Promise<Case[]>;
  getCaseById(id: string): Promise<Case | undefined>;
  createCase(case_: InsertCase): Promise<Case>;
  updateCase(id: string, updates: Partial<Case>): Promise<Case>;
  getActiveCases(): Promise<Case[]>;
  getCasesByUser(userId: string): Promise<Case[]>;

  // Dispatch methods
  createDispatch(dispatch: InsertDispatch): Promise<Dispatch>;
  getDispatchesByCase(caseId: string): Promise<Dispatch[]>;
  getDispatchesByUser(userId: string): Promise<Dispatch[]>;
  updateDispatchStatus(id: string, status: string, timestamp?: Date): Promise<Dispatch>;

  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByCase(caseId: string): Promise<Message[]>;
  getMessagesBetweenUsers(user1Id: string, user2Id: string): Promise<Message[]>;
  markMessageAsRead(id: string): Promise<Message>;
  getUnreadMessagesCount(userId: string): Promise<number>;

  // Case update methods
  createCaseUpdate(update: InsertCaseUpdate): Promise<CaseUpdate>;
  getCaseUpdates(caseId: string): Promise<CaseUpdate[]>;

  // Evidence methods
  createEvidence(evidence_: InsertEvidence): Promise<Evidence>;
  getEvidenceByCase(caseId: string): Promise<Evidence[]>;

  // Admin methods
  getAllUsers(): Promise<User[]>;
  createInvitation(invitation: InsertInvitation): Promise<Invitation>;
  getAllInvitations(): Promise<Invitation[]>;
  getAllVehicles(): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  getAllResources(): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  getAllScannerFeeds(): Promise<ScannerFeed[]>;
  createScannerFeed(scannerFeed: InsertScannerFeed): Promise<ScannerFeed>;
  getAllDispatches(): Promise<Dispatch[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [result] = await db.insert(users).values(insertUser).returning();
    return result;
  }

  async updateUserStatus(id: string, status: string, lat?: number, lng?: number): Promise<User> {
    const updateData = {
      status,
      lastStatusUpdate: new Date(),
      ...(lat !== undefined && lng !== undefined && {
        currentLat: lat.toString(),
        currentLng: lng.toString(),
      }),
    };

    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserLocation(id: string, lat: number, lng: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        currentLat: lat.toString(),
        currentLng: lng.toString(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getActiveUsers(): Promise<User[]> {
    return db.select().from(users).where(eq(users.isActive, true));
  }

  async getAllCases(): Promise<Case[]> {
    return db.select().from(cases).orderBy(desc(cases.createdAt));
  }

  async getCaseById(id: string): Promise<Case | undefined> {
    const [case_] = await db.select().from(cases).where(eq(cases.id, id));
    return case_ || undefined;
  }

  async createCase(insertCase: InsertCase): Promise<Case> {
    // Generate case number
    const caseCount = await db.select({ count: sql<number>`count(*)` }).from(cases);
    const caseNumber = `MP-2025-${String(Number(caseCount[0].count) + 1).padStart(3, '0')}`;
    
    const [case_] = await db
      .insert(cases)
      .values({ ...insertCase, caseNumber })
      .returning();
    return case_;
  }

  async updateCase(id: string, updates: Partial<Case>): Promise<Case> {
    const [case_] = await db
      .update(cases)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(cases.id, id))
      .returning();
    return case_;
  }

  async getActiveCases(): Promise<Case[]> {
    return db.select().from(cases)
      .where(or(eq(cases.status, 'open'), eq(cases.status, 'active')))
      .orderBy(desc(cases.createdAt));
  }

  async getCasesByUser(userId: string): Promise<Case[]> {
    return db.select().from(cases)
      .where(or(eq(cases.createdById, userId), eq(cases.assignedToId, userId)))
      .orderBy(desc(cases.createdAt));
  }

  async createDispatch(insertDispatch: InsertDispatch): Promise<Dispatch> {
    const [dispatch] = await db.insert(dispatches).values(insertDispatch).returning();
    return dispatch;
  }

  async getDispatchesByCase(caseId: string): Promise<Dispatch[]> {
    return db.select().from(dispatches)
      .where(eq(dispatches.caseId, caseId))
      .orderBy(desc(dispatches.createdAt));
  }

  async getDispatchesByUser(userId: string): Promise<Dispatch[]> {
    return db.select().from(dispatches)
      .where(eq(dispatches.userId, userId))
      .orderBy(desc(dispatches.createdAt));
  }

  async updateDispatchStatus(id: string, status: string, timestamp?: Date): Promise<Dispatch> {
    const updateData: any = { status };
    
    if (timestamp) {
      switch (status) {
        case 'acknowledged':
          updateData.respondedAt = timestamp;
          break;
        case 'arrived':
          updateData.arrivedAt = timestamp;
          break;
        case 'completed':
          updateData.completedAt = timestamp;
          break;
      }
    }

    const [dispatch] = await db
      .update(dispatches)
      .set(updateData)
      .where(eq(dispatches.id, id))
      .returning();
    return dispatch;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    return message;
  }

  async getMessagesByCase(caseId: string): Promise<Message[]> {
    return db.select().from(messages)
      .where(eq(messages.caseId, caseId))
      .orderBy(desc(messages.createdAt));
  }

  async getMessagesBetweenUsers(user1Id: string, user2Id: string): Promise<Message[]> {
    return db.select().from(messages)
      .where(
        or(
          and(eq(messages.senderId, user1Id), eq(messages.recipientId, user2Id)),
          and(eq(messages.senderId, user2Id), eq(messages.recipientId, user1Id))
        )
      )
      .orderBy(desc(messages.createdAt));
  }

  async markMessageAsRead(id: string): Promise<Message> {
    const [message] = await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id))
      .returning();
    return message;
  }

  async getUnreadMessagesCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(and(eq(messages.recipientId, userId), eq(messages.isRead, false)));
    return result.count;
  }

  async createCaseUpdate(insertCaseUpdate: InsertCaseUpdate): Promise<CaseUpdate> {
    const [caseUpdate] = await db.insert(caseUpdates).values(insertCaseUpdate).returning();
    return caseUpdate;
  }

  async getCaseUpdates(caseId: string): Promise<CaseUpdate[]> {
    return db.select().from(caseUpdates)
      .where(eq(caseUpdates.caseId, caseId))
      .orderBy(desc(caseUpdates.createdAt));
  }

  async createEvidence(insertEvidence: InsertEvidence): Promise<Evidence> {
    const [evidence_] = await db.insert(evidence).values(insertEvidence).returning();
    return evidence_;
  }

  async getEvidenceByCase(caseId: string): Promise<Evidence[]> {
    return db.select().from(evidence)
      .where(eq(evidence.caseId, caseId))
      .orderBy(desc(evidence.createdAt));
  }

  // Admin methods
  async getAllUsers(): Promise<User[]> {
    try {
      const result = await db.select().from(users);
      return Array.isArray(result) ? result : [];
    } catch (error) {
      console.error('Error fetching users:', error);
      return [];
    }
  }

  async createInvitation(invitation: InsertInvitation): Promise<Invitation> {
    const inviteData = {
      ...invitation,
      inviteToken: crypto.randomUUID(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
    };
    const result = await db.insert(invitations).values(inviteData).returning();
    return result[0];
  }

  async getAllInvitations(): Promise<Invitation[]> {
    const result = await db.select().from(invitations);
    return result || [];
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    const result = await db.select().from(vehicles);
    return result || [];
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const result = await db.insert(vehicles).values(vehicle).returning();
    return result[0];
  }

  async getAllResources(): Promise<Resource[]> {
    const result = await db.select().from(resources);
    return result || [];
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const result = await db.insert(resources).values(resource).returning();
    return result[0];
  }

  async getAllScannerFeeds(): Promise<ScannerFeed[]> {
    const result = await db.select().from(scannerFeeds);
    return result || [];
  }

  async createScannerFeed(scannerFeed: InsertScannerFeed): Promise<ScannerFeed> {
    const result = await db.insert(scannerFeeds).values(scannerFeed).returning();
    return result[0];
  }

  async getAllDispatches(): Promise<Dispatch[]> {
    const result = await db.select().from(dispatches).orderBy(desc(dispatches.createdAt));
    return result || [];
  }
}

export const storage = new DatabaseStorage();
