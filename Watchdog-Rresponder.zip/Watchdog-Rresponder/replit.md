# Watchdog Responder System

## Overview

Watchdog Responder is a real-time emergency response management system designed for search and rescue (SAR) operations. The application provides a comprehensive platform for managing cases, tracking team member locations and status, facilitating communications, and coordinating emergency responses. Built as a full-stack web application, it features a React frontend with a Node.js/Express backend, real-time WebSocket communications, and PostgreSQL database storage.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (August 19, 2025)

- **Complete Database Integration**: Successfully migrated from in-memory storage to PostgreSQL with Drizzle ORM
- **Full Admin Portal Access**: Web interface now provides complete access to manage users, vehicles, resources, and scanner feeds
- **Database Seeded with Test Data**: Added comprehensive test data including 4 users, 3 vehicles, 3 resources, 2 scanner feeds, 3 cases, 3 dispatches, and 2 invitations
- **Role Management**: Added "Investigator" role with proper validation and yellow badge styling
- **Navigation Fixed**: Completed comprehensive navigation testing with all 27+ buttons properly routing using wouter hooks
- **Production Ready Storage**: Replaced MemStorage with DatabaseStorage class implementing full IStorage interface
- **API Endpoints Verified**: All admin endpoints functioning properly with real database operations
- **Real-time Features**: WebSocket integration maintained with database persistence for live updates
- **Email Integration**: SendGrid email system fully operational with verified sender (westmichiganwatchdoginitiative@gmail.com)
- **Invitation Emails**: Professional invitation emails with Watchdog branding, secure tokens, and 7-day expiration automatically sent

## System Architecture

### Frontend Architecture

The client application is built with **React** and **TypeScript**, utilizing modern development practices:

- **UI Framework**: Custom component library based on shadcn/ui with Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme optimized for emergency response scenarios
- **State Management**: TanStack Query (React Query) for server state and caching
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Updates**: Custom WebSocket hook for live data synchronization
- **Build Tool**: Vite for fast development and optimized production builds

The application follows a mobile-first responsive design pattern with a bottom navigation structure typical of mobile applications. Components are organized into reusable UI primitives and feature-specific components. The admin interface provides comprehensive resource management capabilities for organizational administrators.

### Backend Architecture

The server implements a **REST API** using **Express.js** with TypeScript:

- **Runtime**: Node.js with ES modules
- **API Design**: RESTful endpoints for CRUD operations on users, cases, dispatches, messages, and evidence
- **Real-time Communication**: WebSocket server for live status updates and messaging
- **Session Management**: Express sessions with PostgreSQL session store
- **Error Handling**: Centralized error middleware with structured error responses

### Data Storage

**PostgreSQL** database with **Drizzle ORM** for type-safe database operations:

- **Schema Definition**: Centralized schema definitions with automatic TypeScript type generation
- **Migration Management**: Drizzle Kit for database schema migrations
- **Connection**: Neon serverless PostgreSQL for scalable cloud hosting
- **Session Storage**: PostgreSQL-backed session management for user authentication

Key database entities include:
- Users (responders with roles, status, and location tracking)
- Cases (emergency incidents with priority levels and geographic data)
- Dispatches (assignments linking users to cases)
- Messages (communications between users and case-specific threads)
- Case Updates and Evidence (audit trail and documentation)
- Vehicles (fleet management with GPS tracking and assignment)
- Resources (equipment, facilities, contacts, and services)
- Scanner Feeds (radio communication streams with authentication)
- Invitations (user onboarding system with email/text delivery)

### Authentication and Authorization

The system implements a role-based access control model:

- **Roles**: Admin, responder, SAR specialist, legal, veteran
- **Status Tracking**: Real-time availability status (available, unavailable, en route, virtual, on scene)
- **Location Services**: GPS tracking for active responders
- **Session Management**: Server-side sessions with automatic cleanup

### Design Patterns

- **Component Composition**: Reusable UI components with consistent prop interfaces
- **Custom Hooks**: Encapsulated business logic for WebSocket connections, mobile detection, and toast notifications
- **Type Safety**: End-to-end TypeScript with shared schema definitions between client and server
- **Real-time Synchronization**: WebSocket events trigger React Query cache invalidation for seamless UI updates

## External Dependencies

### Core Technologies
- **React 18**: Frontend framework with hooks and concurrent features
- **Express.js**: Node.js web framework for API development
- **TypeScript**: Type safety across the entire application stack
- **Vite**: Frontend build tool and development server

### Database and ORM
- **PostgreSQL**: Primary database via Neon serverless platform
- **Drizzle ORM**: Type-safe database operations and schema management
- **Drizzle Kit**: Database migration and schema management tools

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless UI primitives for accessibility
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library for consistent iconography

### State Management and Data Fetching
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation and schema parsing

### Real-time Communication
- **WebSocket (ws)**: Native WebSocket implementation for real-time features
- **Custom WebSocket hooks**: React integration for live updates

### Development and Build Tools
- **esbuild**: Fast JavaScript bundler for server-side code
- **PostCSS**: CSS processing with Autoprefixer
- **tsx**: TypeScript execution for development

### Geolocation and Mapping
- **Browser Geolocation API**: Native location tracking with real-time positioning
- **Google Maps API**: Full integration with interactive maps, custom markers, and location services
- **Map Features**: Dark theme optimized for emergency response, status-based marker colors, click-to-info functionality
- **Location Tracking**: Real-time user and case location plotting with distance calculations

The application is designed for deployment on cloud platforms with support for environment-based configuration and scalable real-time communication through WebSocket clustering.