import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  badge: text("badge"),
  phone: text("phone"),
  role: text("role").notNull().default("responder"), // admin, responder, sar, legal, veteran, investigator
  status: text("status").notNull().default("unavailable"), // available, unavailable, enroute, virtual, onscene
  lastStatusUpdate: timestamp("last_status_update").defaultNow(),
  currentLat: decimal("current_lat", { precision: 10, scale: 8 }),
  currentLng: decimal("current_lng", { precision: 11, scale: 8 }),
  isActive: boolean("is_active").notNull().default(false),
  invitedBy: varchar("invited_by").references(() => users.id),
  inviteToken: text("invite_token").unique(),
  inviteExpires: timestamp("invite_expires"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cases = pgTable("cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseNumber: text("case_number").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority").notNull().default("medium"), // high, medium, low
  status: text("status").notNull().default("open"), // open, active, closed
  type: text("type").notNull().default("missing_person"), // missing_person, sar, investigation
  lastSeenLocation: text("last_seen_location"),
  lastSeenLat: decimal("last_seen_lat", { precision: 10, scale: 8 }),
  lastSeenLng: decimal("last_seen_lng", { precision: 11, scale: 8 }),
  createdById: varchar("created_by_id").references(() => users.id),
  assignedToId: varchar("assigned_to_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dispatches = pgTable("dispatches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").references(() => cases.id),
  userId: varchar("user_id").references(() => users.id),
  status: text("status").notNull(), // dispatched, acknowledged, responding, arrived, completed
  respondedAt: timestamp("responded_at"),
  arrivedAt: timestamp("arrived_at"),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").references(() => users.id),
  recipientId: varchar("recipient_id").references(() => users.id),
  caseId: varchar("case_id").references(() => cases.id),
  content: text("content").notNull(),
  messageType: text("message_type").notNull().default("text"), // text, voice, image, file, location
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const caseUpdates = pgTable("case_updates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").references(() => cases.id),
  userId: varchar("user_id").references(() => users.id),
  updateType: text("update_type").notNull(), // status, location, evidence, note
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // For additional structured data
  createdAt: timestamp("created_at").defaultNow(),
});

export const evidence = pgTable("evidence", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").references(() => cases.id),
  uploadedById: varchar("uploaded_by_id").references(() => users.id),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size"),
  fileUrl: text("file_url").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Admin resources
export const vehicles = pgTable("vehicles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // suv, truck, boat, atv, helicopter, drone
  callSign: text("call_sign").unique(),
  status: text("status").notNull().default("available"), // available, in_use, maintenance, offline
  currentLat: decimal("current_lat", { precision: 10, scale: 8 }),
  currentLng: decimal("current_lng", { precision: 11, scale: 8 }),
  assignedUserId: varchar("assigned_user_id").references(() => users.id),
  description: text("description"),
  capabilities: jsonb("capabilities").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const resources = pgTable("resources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // equipment, facility, contact, service
  description: text("description"),
  status: text("status").notNull().default("available"), // available, in_use, maintenance, offline
  location: text("location"),
  contactInfo: jsonb("contact_info").$type<{name?: string; phone?: string; email?: string}>(),
  metadata: jsonb("metadata"), // Additional resource-specific data
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const scannerFeeds = pgTable("scanner_feeds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  feedUrl: text("feed_url").notNull(),
  feedType: text("feed_type").notNull().default("audio"), // audio, data, mixed
  location: text("location"),
  frequency: text("frequency"),
  isActive: boolean("is_active").notNull().default(true),
  requiresAuth: boolean("requires_auth").notNull().default(false),
  authCredentials: jsonb("auth_credentials").$type<{username?: string; password?: string}>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const invitations = pgTable("invitations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email"),
  phone: text("phone"),
  name: text("name").notNull(),
  role: text("role").notNull().default("responder"),
  inviteToken: text("invite_token").notNull().unique(),
  invitedById: varchar("invited_by_id").references(() => users.id),
  status: text("status").notNull().default("pending"), // pending, accepted, expired, cancelled
  expiresAt: timestamp("expires_at").notNull(),
  acceptedAt: timestamp("accepted_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  createdCases: many(cases, { relationName: "createdBy" }),
  assignedCases: many(cases, { relationName: "assignedTo" }),
  dispatches: many(dispatches),
  sentMessages: many(messages, { relationName: "sender" }),
  receivedMessages: many(messages, { relationName: "recipient" }),
  caseUpdates: many(caseUpdates),
  uploadedEvidence: many(evidence),
}));

export const caseRelations = relations(cases, ({ one, many }) => ({
  createdBy: one(users, {
    fields: [cases.createdById],
    references: [users.id],
    relationName: "createdBy",
  }),
  assignedTo: one(users, {
    fields: [cases.assignedToId],
    references: [users.id],
    relationName: "assignedTo",
  }),
  dispatches: many(dispatches),
  messages: many(messages),
  updates: many(caseUpdates),
  evidence: many(evidence),
}));

export const dispatchRelations = relations(dispatches, ({ one }) => ({
  case: one(cases, {
    fields: [dispatches.caseId],
    references: [cases.id],
  }),
  user: one(users, {
    fields: [dispatches.userId],
    references: [users.id],
  }),
}));

export const messageRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sender",
  }),
  recipient: one(users, {
    fields: [messages.recipientId],
    references: [users.id],
    relationName: "recipient",
  }),
  case: one(cases, {
    fields: [messages.caseId],
    references: [cases.id],
  }),
}));

export const caseUpdateRelations = relations(caseUpdates, ({ one }) => ({
  case: one(cases, {
    fields: [caseUpdates.caseId],
    references: [cases.id],
  }),
  user: one(users, {
    fields: [caseUpdates.userId],
    references: [users.id],
  }),
}));

export const evidenceRelations = relations(evidence, ({ one }) => ({
  case: one(cases, {
    fields: [evidence.caseId],
    references: [cases.id],
  }),
  uploadedBy: one(users, {
    fields: [evidence.uploadedById],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastStatusUpdate: true,
});

export const insertCaseSchema = createInsertSchema(cases).omit({
  id: true,
  caseNumber: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDispatchSchema = createInsertSchema(dispatches).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertCaseUpdateSchema = createInsertSchema(caseUpdates).omit({
  id: true,
  createdAt: true,
});

export const insertEvidenceSchema = createInsertSchema(evidence).omit({
  id: true,
  createdAt: true,
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScannerFeedSchema = createInsertSchema(scannerFeeds).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvitationSchema = createInsertSchema(invitations).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Case = typeof cases.$inferSelect;
export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Dispatch = typeof dispatches.$inferSelect;
export type InsertDispatch = z.infer<typeof insertDispatchSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type CaseUpdate = typeof caseUpdates.$inferSelect;
export type InsertCaseUpdate = z.infer<typeof insertCaseUpdateSchema>;
export type Evidence = typeof evidence.$inferSelect;
export type InsertEvidence = z.infer<typeof insertEvidenceSchema>;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type ScannerFeed = typeof scannerFeeds.$inferSelect;
export type InsertScannerFeed = z.infer<typeof insertScannerFeedSchema>;
export type Invitation = typeof invitations.$inferSelect;
export type InsertInvitation = z.infer<typeof insertInvitationSchema>;
