# SendGrid Email Setup Guide

## Current Status
✅ SendGrid API key is properly configured
✅ Email invitation system is fully implemented
❌ **Issue: Sender email address needs verification**

## Error Details
The system is getting a 403 Forbidden error from SendGrid because the sender email address is not verified in your SendGrid account.

**Error Message**: "The from address does not match a verified Sender Identity"

## Solution Options

### Option 1: Single Sender Verification (Recommended for Testing)
1. Log into your SendGrid dashboard at https://app.sendgrid.com
2. Go to **Settings** → **Sender Authentication**
3. Click **Verify a Single Sender**
4. Add an email address you control (e.g., your personal email or a business email)
5. SendGrid will send a verification email - click the link to verify
6. Update the sender email in `server/email.ts` line 133 to match your verified email

### Option 2: Domain Authentication (Recommended for Production)
1. In SendGrid dashboard, go to **Settings** → **Sender Authentication**
2. Click **Authenticate Your Domain**
3. Follow the DNS configuration steps for your domain
4. Once verified, you can use any email address from that domain

## Quick Fix for Testing
✅ **Email address updated to**: westmichiganwatchdoginitiative@gmail.com

**Next step**: You need to verify this email address in your SendGrid account:
1. Go to https://app.sendgrid.com
2. Navigate to **Settings** → **Sender Authentication** 
3. Click **Verify a Single Sender**
4. Enter: **westmichiganwatchdoginitiative@gmail.com**
5. Check your Gmail for the verification email from SendGrid
6. Click the verification link

## Test the Email System
Once you've verified a sender email address, test the invitation system:

```bash
curl -X POST http://localhost:5000/api/admin/invite-user \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"recipient@example.com","role":"responder"}'
```

Look for `"emailSent": true` in the response and check the server logs for success messages.

## Email Template Features
The system sends professional invitation emails with:
- Watchdog branding and styling
- Role-specific content
- Secure invitation links with tokens
- 7-day expiration
- Mobile-responsive HTML design
- Plain text fallback

## Next Steps
1. Verify a sender email in SendGrid
2. Update the sender email in the code
3. Test the invitation system
4. Start sending real invitations through the admin portal