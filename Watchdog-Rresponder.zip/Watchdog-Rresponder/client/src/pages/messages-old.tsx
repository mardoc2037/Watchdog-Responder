import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import HeaderBar from "@/components/header-bar";
import BottomNavigation from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageCircle, Send, Users, Lock, Search, Plus, Mic, MicOff, Play, Square, Radio } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import RadioScanner from "@/components/radio-scanner";
import type { Message, User, Case } from "@shared/schema";

export default function Messages() {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const [scannerConnected, setScannerConnected] = useState(false);
  const [scannerError, setScannerError] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: activeUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users/active"],
  });

  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  const { data: unreadCount = { count: 0 } } = useQuery<{ count: number }>({
    queryKey: ["/api/messages/unread/count"],
  });

  const { data: caseMessages = [] } = useQuery<Message[]>({
    queryKey: ["/api/messages/case", selectedCase?.id],
    enabled: !!selectedCase?.id,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { recipientId?: string; caseId?: string; content: string; type?: string }) => {
      const response = await apiRequest("POST", "/api/messages", messageData);
      return response.json();
    },
    onSuccess: () => {
      setNewMessage("");
      setAudioBlob(null);
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Success",
        description: "Message sent successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // PTT Recording Functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: BlobPart[] = [];
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setAudioBlob(blob);
      };
      
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start timer
      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
      toast({
        title: "Recording Started",
        description: "Push-to-Talk recording in progress",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not access microphone",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      streamRef.current?.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      
      toast({
        title: "Recording Stopped",
        description: `Voice message recorded (${recordingTime}s)`,
      });
    }
  };

  const sendVoiceMessage = () => {
    if (!audioBlob) return;

    const messageData: { recipientId?: string; caseId?: string; content: string; type: string } = {
      content: `Voice message (${recordingTime}s)`,
      type: 'voice',
    };

    if (selectedUser) {
      messageData.recipientId = selectedUser.id;
    } else if (selectedCase) {
      messageData.caseId = selectedCase.id;
    }

    sendMessageMutation.mutate(messageData);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Scanner feed functions
  const connectToScanner = () => {
    try {
      if (audioRef.current) {
        audioRef.current.src = "http://mkgtrunker:Mkgtrunker!@73.145.220.145:55/";
        audioRef.current.load();
        audioRef.current.play().then(() => {
          setScannerConnected(true);
          setScannerError(null);
          toast({
            title: "Scanner Connected",
            description: "Live radio feed is now active",
          });
        }).catch((error) => {
          setScannerError("Could not connect to scanner feed");
          setScannerConnected(false);
          toast({
            title: "Scanner Error",
            description: "Could not connect to scanner feed",
            variant: "destructive",
          });
        });
      }
    } catch (error) {
      setScannerError("Scanner feed unavailable");
      setScannerConnected(false);
      toast({
        title: "Connection Error",
        description: "Scanner feed is currently unavailable",
        variant: "destructive",
      });
    }
  };

  const disconnectScanner = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      setScannerConnected(false);
      setScannerError(null);
      toast({
        title: "Scanner Disconnected",
        description: "Radio feed has been stopped",
      });
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const messageData: { recipientId?: string; caseId?: string; content: string } = {
      content: newMessage,
    };

    if (selectedUser) {
      messageData.recipientId = selectedUser.id;
    } else if (selectedCase) {
      messageData.caseId = selectedCase.id;
    }

    sendMessageMutation.mutate(messageData);
  };

  const filteredUsers = activeUsers.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.badge?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCases = activeCases.filter(case_ =>
    case_.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    case_.caseNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      <HeaderBar />
      
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <MessageCircle className="h-6 w-6 text-secondary" />
            <h1 className="text-xl font-semibold">Secure Communications</h1>
            {unreadCount.count > 0 && (
              <Badge className="bg-destructive text-white" data-testid="badge-unread-count">
                {unreadCount.count}
              </Badge>
            )}
          </div>
          <div className="flex items-center text-sm text-gray-400">
            <Lock className="h-4 w-4 mr-1" />
            <span>Encrypted</span>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search users or cases..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-surface border-gray-600 text-text-primary"
            data-testid="input-search-messages"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Contacts/Cases Panel */}
          <div className="lg:col-span-1">
            <Tabs defaultValue="users" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-surface">
                <TabsTrigger 
                  value="users" 
                  className="data-[state=active]:bg-secondary data-[state=active]:text-white"
                  data-testid="tab-users"
                >
                  <Users className="h-4 w-4 mr-2" />
                  Users
                </TabsTrigger>
                <TabsTrigger 
                  value="cases" 
                  className="data-[state=active]:bg-secondary data-[state=active]:text-white"
                  data-testid="tab-cases"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Cases
                </TabsTrigger>
                <TabsTrigger 
                  value="scanner" 
                  className="data-[state=active]:bg-secondary data-[state=active]:text-white"
                  data-testid="tab-scanner"
                >
                  <Radio className="h-4 w-4 mr-2" />
                  Scanner
                </TabsTrigger>
              </TabsList>

              <TabsContent value="users" className="mt-4">
                <div className="space-y-2">
                  {filteredUsers.length === 0 ? (
                    <div className="text-center py-8">
                      <Users className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-400 text-sm">No active users</p>
                    </div>
                  ) : (
                    filteredUsers.map((user) => (
                      <Card 
                        key={user.id}
                        className={`cursor-pointer transition-colors ${
                          selectedUser?.id === user.id 
                            ? 'bg-secondary/20 border-secondary' 
                            : 'bg-surface border-gray-600 hover:bg-gray-600'
                        }`}
                        onClick={() => {
                          setSelectedUser(user);
                          setSelectedCase(null);
                        }}
                        data-testid={`card-user-${user.id}`}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${
                              user.status === 'available' ? 'bg-success' :
                              user.status === 'enroute' ? 'bg-warning' :
                              user.status === 'onscene' ? 'bg-purple-500' :
                              'bg-gray-500'
                            }`}></div>
                            <div className="flex-1">
                              <p className="font-medium text-sm" data-testid={`text-user-name-${user.id}`}>{user.name}</p>
                              <p className="text-xs text-gray-400" data-testid={`text-user-badge-${user.id}`}>
                                {user.badge ? `Badge ${user.badge}` : user.role}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="cases" className="mt-4">
                <div className="space-y-2">
                  {filteredCases.length === 0 ? (
                    <div className="text-center py-8">
                      <MessageCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-400 text-sm">No active cases</p>
                    </div>
                  ) : (
                    filteredCases.map((case_) => (
                      <Card 
                        key={case_.id}
                        className={`cursor-pointer transition-colors ${
                          selectedCase?.id === case_.id 
                            ? 'bg-secondary/20 border-secondary' 
                            : 'bg-surface border-gray-600 hover:bg-gray-600'
                        }`}
                        onClick={() => {
                          setSelectedCase(case_);
                          setSelectedUser(null);
                        }}
                        data-testid={`card-case-${case_.id}`}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-sm" data-testid={`text-case-number-${case_.id}`}>{case_.caseNumber}</p>
                              <p className="text-xs text-gray-400" data-testid={`text-case-title-${case_.id}`}>{case_.title}</p>
                            </div>
                            <Badge 
                              className={`text-xs ${
                                case_.priority === 'high' ? 'bg-destructive text-white' :
                                case_.priority === 'medium' ? 'bg-warning text-black' :
                                'bg-success text-white'
                              }`}
                              data-testid={`badge-case-priority-${case_.id}`}
                            >
                              {case_.priority.toUpperCase()}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="scanner" className="mt-4">
                <div data-testid="scanner-section" className="text-center py-8">
                  <Radio className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Full scanner interface available in dedicated tab</p>
                  <Button 
                    onClick={() => window.open('/scanner', '_blank')}
                    className="bg-secondary hover:bg-secondary/80"
                  >
                    <Radio className="w-4 h-4 mr-2" />
                    Open Scanner
                  </Button>
                </div>
                
                {/* Compact Scanner Status */}
                <div className="mt-4 p-4 bg-gray-700 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium text-text-primary">Scanner Status</span>
                      <p className="text-xs text-gray-400">Professional radio interface available</p>
                    </div>
                    <Button
                      onClick={() => window.open('/scanner', '_blank')}
                      className="bg-secondary hover:bg-secondary/80 text-white"
                    >
                      <Radio className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Message Display Area */}
          <div className="flex-1 flex flex-col">
            {/* Message header and content would go here */}
            <div className="flex-1 p-4 bg-surface border-l border-gray-600">
              {selectedUser ? (
                <div>
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-3">
                      <span className="text-white font-semibold">
                        {selectedUser.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-medium text-text-primary">{selectedUser.name}</h3>
                      <p className="text-sm text-gray-400">{selectedUser.role} - {selectedUser.status}</p>
                    </div>
                  </div>
                  <div className="text-center text-gray-400 py-8">
                    <MessageCircle className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm">No messages yet</p>
                    <p className="text-xs">Start a conversation with {selectedUser.name}</p>
                  </div>
                </div>
              ) : selectedCase ? (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-medium text-text-primary">{selectedCase.caseNumber}</h3>
                      <p className="text-sm text-gray-400">{selectedCase.title}</p>
                    </div>
                    <Badge className={`${
                      selectedCase.priority === 'high' ? 'bg-destructive text-white' :
                      selectedCase.priority === 'medium' ? 'bg-warning text-black' :
                      'bg-success text-white'
                    }`}>
                      {selectedCase.priority.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="text-center text-gray-400 py-8">
                    <FileText className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm">No updates for this case</p>
                    <p className="text-xs">Case updates and communications will appear here</p>
                  </div>
                </div>
              ) : (
                <div className="text-center text-gray-400 py-8">
                  <MessageCircle className="h-8 w-8 mx-auto mb-2" />
                  <p className="text-sm">Select a contact or case to view messages</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <BottomNavigation currentPath="/messages" />
      </div>
    </div>
  );
}
