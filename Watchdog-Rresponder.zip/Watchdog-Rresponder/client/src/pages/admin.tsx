import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Users, 
  UserPlus, 
  Truck, 
  Shield, 
  Radio, 
  Settings, 
  Mail, 
  Phone, 
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  MapPin,
  Monitor
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BottomNavigation from "@/components/bottom-navigation";
import type { User, Vehicle, Resource, ScannerFeed, Invitation } from "@shared/schema";

const inviteUserSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address").optional(),
  phone: z.string().min(10, "Phone must be at least 10 digits").optional(),
  role: z.enum(["admin", "responder", "sar", "legal", "veteran", "investigator"]),
  badge: z.string().optional(),
}).refine(data => data.email || data.phone, {
  message: "Either email or phone number is required",
  path: ["email"]
});

const vehicleSchema = z.object({
  name: z.string().min(2, "Name is required"),
  type: z.enum(["suv", "truck", "boat", "atv", "helicopter", "drone"]),
  callSign: z.string().min(2, "Call sign is required"),
  description: z.string().optional(),
  capabilities: z.array(z.string()).optional(),
});

const resourceSchema = z.object({
  name: z.string().min(2, "Name is required"),
  type: z.enum(["equipment", "facility", "contact", "service"]),
  description: z.string().optional(),
  location: z.string().optional(),
  contactName: z.string().optional(),
  contactPhone: z.string().optional(),
  contactEmail: z.string().email("Invalid email").optional(),
});

const scannerFeedSchema = z.object({
  name: z.string().min(2, "Name is required"),
  description: z.string().optional(),
  feedUrl: z.string().url("Invalid URL"),
  feedType: z.enum(["audio", "data", "mixed"]),
  location: z.string().optional(),
  frequency: z.string().optional(),
  requiresAuth: z.boolean(),
  username: z.string().optional(),
  password: z.string().optional(),
});

type InviteUserForm = z.infer<typeof inviteUserSchema>;
type VehicleForm = z.infer<typeof vehicleSchema>;
type ResourceForm = z.infer<typeof resourceSchema>;
type ScannerFeedForm = z.infer<typeof scannerFeedSchema>;

export default function AdminPage() {
  const [, setLocation] = useLocation();
  const [selectedTab, setSelectedTab] = useState("users");
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showVehicleDialog, setShowVehicleDialog] = useState(false);
  const [showResourceDialog, setShowResourceDialog] = useState(false);
  const [showScannerDialog, setShowScannerDialog] = useState(false);
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch data
  const { data: users = [] } = useQuery<User[]>({ queryKey: ["/api/admin/users"], initialData: [] });
  const { data: vehicles = [] } = useQuery<Vehicle[]>({ queryKey: ["/api/admin/vehicles"], initialData: [] });
  const { data: resources = [] } = useQuery<Resource[]>({ queryKey: ["/api/admin/resources"], initialData: [] });
  const { data: scannerFeeds = [] } = useQuery<ScannerFeed[]>({ queryKey: ["/api/admin/scanner-feeds"], initialData: [] });
  const { data: invitations = [] } = useQuery<Invitation[]>({ queryKey: ["/api/admin/invitations"], initialData: [] });

  // Forms
  const inviteForm = useForm<InviteUserForm>({
    resolver: zodResolver(inviteUserSchema),
    defaultValues: { role: "responder" }
  });

  const vehicleForm = useForm<VehicleForm>({
    resolver: zodResolver(vehicleSchema),
    defaultValues: { type: "suv", capabilities: [] }
  });

  const resourceForm = useForm<ResourceForm>({
    resolver: zodResolver(resourceSchema),
    defaultValues: { type: "equipment" }
  });

  const scannerForm = useForm<ScannerFeedForm>({
    resolver: zodResolver(scannerFeedSchema),
    defaultValues: { feedType: "audio", requiresAuth: false }
  });

  // Mutations
  const inviteUserMutation = useMutation({
    mutationFn: (data: InviteUserForm) => apiRequest("POST", "/api/admin/invite-user", data),
    onSuccess: () => {
      toast({ title: "Success", description: "User invitation sent successfully" });
      inviteForm.reset();
      setShowInviteDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/invitations"] });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to send invitation", variant: "destructive" });
    }
  });

  const addVehicleMutation = useMutation({
    mutationFn: (data: VehicleForm) => apiRequest("POST", "/api/admin/vehicles", data),
    onSuccess: () => {
      toast({ title: "Success", description: "Vehicle added successfully" });
      vehicleForm.reset();
      setShowVehicleDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add vehicle", variant: "destructive" });
    }
  });

  const addResourceMutation = useMutation({
    mutationFn: (data: ResourceForm) => apiRequest("POST", "/api/admin/resources", {
      ...data,
      contactInfo: {
        name: data.contactName,
        phone: data.contactPhone,
        email: data.contactEmail,
      }
    }),
    onSuccess: () => {
      toast({ title: "Success", description: "Resource added successfully" });
      resourceForm.reset();
      setShowResourceDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/resources"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add resource", variant: "destructive" });
    }
  });

  const addScannerMutation = useMutation({
    mutationFn: (data: ScannerFeedForm) => apiRequest("POST", "/api/admin/scanner-feeds", {
      ...data,
      authCredentials: data.requiresAuth ? {
        username: data.username,
        password: data.password,
      } : null,
    }),
    onSuccess: () => {
      toast({ title: "Success", description: "Scanner feed added successfully" });
      scannerForm.reset();
      setShowScannerDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/scanner-feeds"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add scanner feed", variant: "destructive" });
    }
  });

  const togglePasswordVisibility = (id: string) => {
    setShowPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-600';
      case 'sar': return 'bg-blue-600';
      case 'legal': return 'bg-purple-600';
      case 'veteran': return 'bg-green-600';
      case 'investigator': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary pb-20">
      {/* Header */}
      <div className="bg-surface border-b border-gray-600 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-text-primary flex items-center" data-testid="text-page-title">
              <Shield className="w-6 h-6 mr-2 text-red-500" />
              Administrator Dashboard
            </h1>
            <p className="text-gray-400 mt-1">Manage users, resources, and system configuration</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setLocation('/admin-portal')}
              className="bg-secondary hover:bg-orange-600"
            >
              <Monitor className="w-4 h-4 mr-2" />
              Command Center
            </Button>
            <Badge className="bg-red-600 text-white">Admin Access</Badge>
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="users" className="data-[state=active]:bg-secondary">
              <Users className="w-4 h-4 mr-1" />
              Users
            </TabsTrigger>
            <TabsTrigger value="vehicles" className="data-[state=active]:bg-secondary">
              <Truck className="w-4 h-4 mr-1" />
              Vehicles
            </TabsTrigger>
            <TabsTrigger value="resources" className="data-[state=active]:bg-secondary">
              <Settings className="w-4 h-4 mr-1" />
              Resources
            </TabsTrigger>
            <TabsTrigger value="scanners" className="data-[state=active]:bg-secondary">
              <Radio className="w-4 h-4 mr-1" />
              Scanners
            </TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">User Management</h2>
              <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Invite User
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Invite New User</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={inviteForm.handleSubmit((data) => inviteUserMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        {...inviteForm.register("name")}
                        className="bg-gray-700 border-gray-600"
                        data-testid="input-name"
                      />
                      {inviteForm.formState.errors.name && (
                        <p className="text-red-500 text-sm mt-1">{inviteForm.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        {...inviteForm.register("email")}
                        className="bg-gray-700 border-gray-600"
                        data-testid="input-email"
                      />
                      {inviteForm.formState.errors.email && (
                        <p className="text-red-500 text-sm mt-1">{inviteForm.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        {...inviteForm.register("phone")}
                        placeholder="(555) 123-4567"
                        className="bg-gray-700 border-gray-600"
                        data-testid="input-phone"
                      />
                    </div>

                    <div>
                      <Label htmlFor="role">Role</Label>
                      <Select onValueChange={(value) => inviteForm.setValue("role", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="responder">First Responder</SelectItem>
                          <SelectItem value="sar">SAR Specialist</SelectItem>
                          <SelectItem value="legal">Legal</SelectItem>
                          <SelectItem value="veteran">Veteran</SelectItem>
                          <SelectItem value="investigator">Investigator</SelectItem>
                          <SelectItem value="admin">Administrator</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="badge">Badge Number (Optional)</Label>
                      <Input
                        id="badge"
                        {...inviteForm.register("badge")}
                        className="bg-gray-700 border-gray-600"
                        data-testid="input-badge"
                      />
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={inviteUserMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                        data-testid="button-send-invite"
                      >
                        <Mail className="w-4 h-4 mr-2" />
                        Send Invitation
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowInviteDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Active Users */}
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Active Users ({users.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {users.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Users className="h-8 w-8 mx-auto mb-2" />
                    <p>No users found</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {users.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                        data-testid={`user-item-${user.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold text-sm">
                              {user.name.split(' ').map((n: string) => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-medium text-text-primary">{user.name}</h3>
                            <p className="text-sm text-gray-400">{user.email}</p>
                            {user.badge && <p className="text-xs text-gray-500">Badge: {user.badge}</p>}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`text-white ${getRoleBadgeColor(user.role)}`}>
                            {user.role.toUpperCase()}
                          </Badge>
                          <Badge className={`${
                            user.status === 'available' ? 'bg-success' :
                            user.status === 'enroute' ? 'bg-warning text-black' :
                            'bg-gray-500'
                          } text-white`}>
                            {user.status.replace('_', ' ').toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Pending Invitations */}
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Pending Invitations ({invitations.filter(i => i.status === 'pending').length})</CardTitle>
              </CardHeader>
              <CardContent>
                {invitations.filter(i => i.status === 'pending').length === 0 ? (
                  <p className="text-center py-4 text-gray-400">No pending invitations</p>
                ) : (
                  <div className="space-y-2">
                    {invitations.filter(i => i.status === 'pending').map((invitation) => (
                      <div
                        key={invitation.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                      >
                        <div>
                          <h3 className="font-medium text-text-primary">{invitation.name}</h3>
                          <p className="text-sm text-gray-400">
                            {invitation.email || invitation.phone}
                          </p>
                          <p className="text-xs text-gray-500">
                            Expires: {new Date(invitation.expiresAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge className={`text-white ${getRoleBadgeColor(invitation.role)}`}>
                          {invitation.role.toUpperCase()}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vehicles Tab */}
          <TabsContent value="vehicles" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Vehicle Management</h2>
              <Dialog open={showVehicleDialog} onOpenChange={setShowVehicleDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Vehicle
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Add New Vehicle</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={vehicleForm.handleSubmit((data) => addVehicleMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="vehicle-name">Vehicle Name</Label>
                      <Input
                        id="vehicle-name"
                        {...vehicleForm.register("name")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="vehicle-type">Vehicle Type</Label>
                      <Select onValueChange={(value) => vehicleForm.setValue("type", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="suv">SUV</SelectItem>
                          <SelectItem value="truck">Truck</SelectItem>
                          <SelectItem value="boat">Boat</SelectItem>
                          <SelectItem value="atv">ATV</SelectItem>
                          <SelectItem value="helicopter">Helicopter</SelectItem>
                          <SelectItem value="drone">Drone</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="call-sign">Call Sign</Label>
                      <Input
                        id="call-sign"
                        {...vehicleForm.register("callSign")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="vehicle-description">Description</Label>
                      <Textarea
                        id="vehicle-description"
                        {...vehicleForm.register("description")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={addVehicleMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                      >
                        Add Vehicle
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowVehicleDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Fleet ({vehicles.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {vehicles.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Truck className="h-8 w-8 mx-auto mb-2" />
                    <p>No vehicles registered</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {vehicles.map((vehicle) => (
                      <div
                        key={vehicle.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                      >
                        <div>
                          <h3 className="font-medium text-text-primary">{vehicle.name}</h3>
                          <p className="text-sm text-gray-400">Call Sign: {vehicle.callSign}</p>
                          <p className="text-xs text-gray-500 capitalize">{vehicle.type}</p>
                        </div>
                        <Badge className={`${
                          vehicle.status === 'available' ? 'bg-success' :
                          vehicle.status === 'in_use' ? 'bg-warning text-black' :
                          'bg-gray-500'
                        } text-white`}>
                          {vehicle.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Resource Management</h2>
              <Dialog open={showResourceDialog} onOpenChange={setShowResourceDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Resource
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Add New Resource</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={resourceForm.handleSubmit((data) => addResourceMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="resource-name">Resource Name</Label>
                      <Input
                        id="resource-name"
                        {...resourceForm.register("name")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="resource-type">Resource Type</Label>
                      <Select onValueChange={(value) => resourceForm.setValue("type", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="equipment">Equipment</SelectItem>
                          <SelectItem value="facility">Facility</SelectItem>
                          <SelectItem value="contact">Contact</SelectItem>
                          <SelectItem value="service">Service</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="resource-location">Location</Label>
                      <Input
                        id="resource-location"
                        {...resourceForm.register("location")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="resource-description">Description</Label>
                      <Textarea
                        id="resource-description"
                        {...resourceForm.register("description")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-name">Contact Name</Label>
                      <Input
                        id="contact-name"
                        {...resourceForm.register("contactName")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-phone">Contact Phone</Label>
                      <Input
                        id="contact-phone"
                        {...resourceForm.register("contactPhone")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-email">Contact Email</Label>
                      <Input
                        id="contact-email"
                        type="email"
                        {...resourceForm.register("contactEmail")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={addResourceMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                      >
                        Add Resource
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowResourceDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Available Resources ({resources.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {resources.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Settings className="h-8 w-8 mx-auto mb-2" />
                    <p>No resources registered</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {resources.map((resource) => (
                      <div
                        key={resource.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                      >
                        <div>
                          <h3 className="font-medium text-text-primary">{resource.name}</h3>
                          <p className="text-sm text-gray-400 capitalize">{resource.type}</p>
                          {resource.location && (
                            <p className="text-xs text-gray-500 flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {resource.location}
                            </p>
                          )}
                        </div>
                        <Badge className={`${
                          resource.status === 'available' ? 'bg-success' :
                          resource.status === 'in_use' ? 'bg-warning text-black' :
                          'bg-gray-500'
                        } text-white`}>
                          {resource.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Scanner Feeds Tab */}
          <TabsContent value="scanners" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Scanner Feed Management</h2>
              <Dialog open={showScannerDialog} onOpenChange={setShowScannerDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Scanner Feed
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Add Scanner Feed</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={scannerForm.handleSubmit((data) => addScannerMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="scanner-name">Feed Name</Label>
                      <Input
                        id="scanner-name"
                        {...scannerForm.register("name")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="scanner-url">Feed URL</Label>
                      <Input
                        id="scanner-url"
                        type="url"
                        {...scannerForm.register("feedUrl")}
                        className="bg-gray-700 border-gray-600"
                        placeholder="http://example.com/stream"
                      />
                    </div>

                    <div>
                      <Label htmlFor="scanner-type">Feed Type</Label>
                      <Select onValueChange={(value) => scannerForm.setValue("feedType", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="audio">Audio</SelectItem>
                          <SelectItem value="data">Data</SelectItem>
                          <SelectItem value="mixed">Mixed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="scanner-location">Location</Label>
                      <Input
                        id="scanner-location"
                        {...scannerForm.register("location")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="scanner-frequency">Frequency</Label>
                      <Input
                        id="scanner-frequency"
                        {...scannerForm.register("frequency")}
                        className="bg-gray-700 border-gray-600"
                        placeholder="154.4025 MHz"
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="requires-auth"
                        {...scannerForm.register("requiresAuth")}
                        className="rounded"
                      />
                      <Label htmlFor="requires-auth">Requires Authentication</Label>
                    </div>

                    {scannerForm.watch("requiresAuth") && (
                      <>
                        <div>
                          <Label htmlFor="scanner-username">Username</Label>
                          <Input
                            id="scanner-username"
                            {...scannerForm.register("username")}
                            className="bg-gray-700 border-gray-600"
                          />
                        </div>

                        <div>
                          <Label htmlFor="scanner-password">Password</Label>
                          <Input
                            id="scanner-password"
                            type="password"
                            {...scannerForm.register("password")}
                            className="bg-gray-700 border-gray-600"
                          />
                        </div>
                      </>
                    )}

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={addScannerMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                      >
                        Add Scanner Feed
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowScannerDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Scanner Feeds ({scannerFeeds.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {scannerFeeds.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Radio className="h-8 w-8 mx-auto mb-2" />
                    <p>No scanner feeds configured</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {scannerFeeds.map((feed) => (
                      <div
                        key={feed.id}
                        className="p-3 bg-gray-700 rounded-lg"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-medium text-text-primary">{feed.name}</h3>
                            <p className="text-sm text-gray-400 capitalize">{feed.feedType} Feed</p>
                            {feed.location && (
                              <p className="text-xs text-gray-500">{feed.location}</p>
                            )}
                            {feed.frequency && (
                              <p className="text-xs text-gray-500">{feed.frequency}</p>
                            )}
                          </div>
                          <Badge className={`${feed.isActive ? 'bg-success' : 'bg-gray-500'} text-white`}>
                            {feed.isActive ? 'ACTIVE' : 'INACTIVE'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-xs text-gray-400 font-mono break-all mr-4">
                            {feed.feedUrl}
                          </div>
                          {feed.requiresAuth && (
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                                AUTH REQUIRED
                              </Badge>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => togglePasswordVisibility(feed.id)}
                                className="p-1 h-6 w-6"
                              >
                                {showPasswords[feed.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </Button>
                              {showPasswords[feed.id] && feed.authCredentials && (
                                <div className="text-xs text-gray-400">
                                  <p>User: {feed.authCredentials.username}</p>
                                  <p>Pass: {feed.authCredentials.password}</p>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNavigation currentPath="/admin" />
    </div>
  );
}