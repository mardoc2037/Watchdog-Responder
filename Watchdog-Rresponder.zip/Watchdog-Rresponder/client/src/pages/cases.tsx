import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import HeaderBar from "@/components/header-bar";
import BottomNavigation from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FolderOpen, Search, Plus, MapPin, Clock, User, Navigation, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Case } from "@shared/schema";

// Declare Google Maps types
declare global {
  interface Window {
    google: any;
  }
}

export default function Cases() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showNavigationModal, setShowNavigationModal] = useState(false);
  const [selectedCall, setSelectedCall] = useState<Case | null>(null);
  const [showRoute, setShowRoute] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const routeMapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const routeMapInstanceRef = useRef<any>(null);
  const directionsService = useRef<any>(null);
  const directionsRenderer = useRef<any>(null);
  
  const { toast } = useToast();

  // Handle directions button click
  const handleGetDirections = (case_: Case) => {
    // Get current location first
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const currentLat = position.coords.latitude;
          const currentLng = position.coords.longitude;
          
          // Use case coordinates if available, otherwise use mock coordinates based on case
          let destinationLat, destinationLng;
          
          if (case_.lastSeenLat && case_.lastSeenLng) {
            destinationLat = parseFloat(case_.lastSeenLat);
            destinationLng = parseFloat(case_.lastSeenLng);
          } else {
            // Mock coordinates for cases without specific coordinates
            if (case_.id === 'case-001') {
              // Pine Valley Trail
              destinationLat = 43.2342;
              destinationLng = -86.2901;
            } else if (case_.id === 'case-003') {
              // Oak Street
              destinationLat = 43.2287;
              destinationLng = -86.2988;
            } else {
              // Default Muskegon area
              destinationLat = 43.2187;
              destinationLng = -86.298;
            }
          }
          
          // Open Google Maps with directions
          const directionsUrl = `https://www.google.com/maps/dir/${currentLat},${currentLng}/${destinationLat},${destinationLng}`;
          window.open(directionsUrl, '_blank');
          
          toast({
            title: "Directions Opened",
            description: `Navigation to ${case_.caseNumber} opened in Google Maps`
          });
        },
        (error) => {
          // If location access is denied, still allow directions but from a general area
          let destinationLat, destinationLng;
          
          if (case_.lastSeenLat && case_.lastSeenLng) {
            destinationLat = parseFloat(case_.lastSeenLat);
            destinationLng = parseFloat(case_.lastSeenLng);
          } else {
            // Mock coordinates for cases without specific coordinates
            if (case_.id === 'case-001') {
              destinationLat = 43.2342;
              destinationLng = -86.2901;
            } else if (case_.id === 'case-003') {
              destinationLat = 43.2287;
              destinationLng = -86.2988;
            } else {
              destinationLat = 43.2187;
              destinationLng = -86.298;
            }
          }
          
          const directionsUrl = `https://www.google.com/maps/place/${destinationLat},${destinationLng}`;
          window.open(directionsUrl, '_blank');
          
          toast({
            title: "Directions Opened",
            description: `Location for ${case_.caseNumber} opened in Google Maps`,
            variant: "default"
          });
        }
      );
    } else {
      // Fallback if geolocation is not supported
      let destinationLat, destinationLng;
      
      if (case_.lastSeenLat && case_.lastSeenLng) {
        destinationLat = parseFloat(case_.lastSeenLat);
        destinationLng = parseFloat(case_.lastSeenLng);
      } else {
        if (case_.id === 'case-001') {
          destinationLat = 43.2342;
          destinationLng = -86.2901;
        } else if (case_.id === 'case-003') {
          destinationLat = 43.2287;
          destinationLng = -86.2988;
        } else {
          destinationLat = 43.2187;
          destinationLng = -86.298;
        }
      }
      
      const directionsUrl = `https://www.google.com/maps/place/${destinationLat},${destinationLng}`;
      window.open(directionsUrl, '_blank');
      
      toast({
        title: "Directions Opened",
        description: `Location for ${case_.caseNumber} opened in Google Maps`
      });
    }
  };

  const { data: allCases = [], isLoading } = useQuery<Case[]>({
    queryKey: ["/api/cases"],
  });

  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  const filteredCases = allCases.filter(case_ =>
    case_.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    case_.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    case_.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-destructive text-white';
      case 'medium':
        return 'bg-warning text-black';
      case 'low':
        return 'bg-success text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-500 text-white';
      case 'active':
        return 'bg-secondary text-white';
      case 'closed':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };



  const handleSelectCall = (call: Case) => {
    setSelectedCall(call);
    setShowRoute(false);
    initializePreviewMap(call);
  };

  const initializePreviewMap = (call: Case) => {
    if (!call.lastSeenLat || !call.lastSeenLng || !mapRef.current || !window.google) return;

    if (!mapInstanceRef.current) {
      mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
        zoom: 15,
        center: { lat: Number(call.lastSeenLat), lng: Number(call.lastSeenLng) },
        styles: [
          { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
          { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
          { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
        ],
      });
    } else {
      mapInstanceRef.current.setCenter({ lat: Number(call.lastSeenLat), lng: Number(call.lastSeenLng) });
    }

    // Add marker for case location
    new window.google.maps.Marker({
      position: { lat: Number(call.lastSeenLat), lng: Number(call.lastSeenLng) },
      map: mapInstanceRef.current,
      title: call.title,
      icon: {
        path: window.google.maps.SymbolPath.CIRCLE,
        fillColor: '#f97316',
        fillOpacity: 1,
        strokeColor: '#ea580c',
        strokeWeight: 2,
        scale: 8,
      },
    });
  };

  const handleShowRoute = () => {
    if (!selectedCall?.lastSeenLat || !selectedCall?.lastSeenLng || !window.google) return;

    setShowRoute(true);
    
    // Get current location
    navigator.geolocation.getCurrentPosition(
      (position) => {
        initializeRouteMap(position.coords.latitude, position.coords.longitude);
      },
      (error) => {
        console.error('Error getting location:', error);
        toast({
          title: "Location Error",
          description: "Could not get your current location for directions",
          variant: "destructive",
        });
      }
    );
  };

  const initializeRouteMap = (currentLat: number, currentLng: number) => {
    if (!selectedCall?.lastSeenLat || !selectedCall?.lastSeenLng || !routeMapRef.current || !window.google) return;

    if (!routeMapInstanceRef.current) {
      routeMapInstanceRef.current = new window.google.maps.Map(routeMapRef.current, {
        zoom: 13,
        center: { lat: currentLat, lng: currentLng },
        styles: [
          { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
          { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
          { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
        ],
      });

      directionsService.current = new window.google.maps.DirectionsService();
      directionsRenderer.current = new window.google.maps.DirectionsRenderer({
        map: routeMapInstanceRef.current,
        polylineOptions: {
          strokeColor: "#ef4444",
          strokeWeight: 4,
        },
      });
    }

    const request = {
      origin: { lat: currentLat, lng: currentLng },
      destination: { lat: Number(selectedCall.lastSeenLat), lng: Number(selectedCall.lastSeenLng) },
      travelMode: window.google.maps.TravelMode.DRIVING,
    };

    directionsService.current.route(request, (result: any, status: any) => {
      if (status === 'OK') {
        directionsRenderer.current.setDirections(result);
      } else {
        console.error('Directions request failed:', status);
        toast({
          title: "Route Error",
          description: "Could not calculate route to destination",
          variant: "destructive",
        });
      }
    });
  };

  const handleStartNavigation = () => {
    if (!selectedCall) return;

    toast({
      title: "Navigation Started",
      description: `In-app navigation to ${selectedCall.caseNumber}`,
    });

    // Close modal and start navigation
    setShowNavigationModal(false);
    setSelectedCall(null);
    setShowRoute(false);
    
    // Future: This will integrate with scanner system
    // For now, we show success message
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-bg">
        <HeaderBar />
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-secondary mx-auto mb-4"></div>
            <p className="text-text-primary">Loading cases...</p>
          </div>
        </div>
        <BottomNavigation currentPath="/cases" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      <HeaderBar />
      
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <FolderOpen className="h-6 w-6 text-secondary" />
            <h1 className="text-xl font-semibold">Case Management</h1>
          </div>
          <Button 
            className="bg-secondary hover:bg-orange-600 text-white"
            data-testid="button-create-case"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Case
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search cases..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-surface border-gray-600 text-text-primary"
            data-testid="input-search-cases"
          />
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-surface">
            <TabsTrigger 
              value="all" 
              className="data-[state=active]:bg-secondary data-[state=active]:text-white"
              data-testid="tab-all-cases"
            >
              All Cases ({filteredCases.length})
            </TabsTrigger>
            <TabsTrigger 
              value="active" 
              className="data-[state=active]:bg-secondary data-[state=active]:text-white"
              data-testid="tab-active-cases"
            >
              Active ({activeCases.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-4">
            <div className="space-y-4">
              {filteredCases.length === 0 ? (
                <div className="text-center py-8">
                  <FolderOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">No cases found</p>
                </div>
              ) : (
                filteredCases.map((case_) => (
                  <Card key={case_.id} className="bg-surface border-gray-600" data-testid={`card-case-${case_.id}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg text-text-primary">{case_.caseNumber}</CardTitle>
                          <p className="text-sm text-gray-400 mt-1">{case_.title}</p>
                        </div>
                        <div className="flex space-x-2">
                          <Badge className={getPriorityColor(case_.priority)} data-testid={`badge-priority-${case_.id}`}>
                            {case_.priority.toUpperCase()}
                          </Badge>
                          <Badge className={getStatusColor(case_.status)} data-testid={`badge-status-${case_.id}`}>
                            {case_.status.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      {case_.description && (
                        <p className="text-sm text-gray-300 mb-3" data-testid={`text-description-${case_.id}`}>
                          {case_.description}
                        </p>
                      )}
                      
                      {case_.lastSeenLocation && (
                        <div className="flex items-center text-sm text-gray-400 mb-2">
                          <MapPin className="h-4 w-4 mr-2 text-secondary" />
                          <span data-testid={`text-location-${case_.id}`}>{case_.lastSeenLocation}</span>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          <span data-testid={`text-created-${case_.id}`}>
                            Created {new Date(case_.createdAt!).toLocaleDateString()}
                          </span>
                        </div>
                        
                        {case_.assignedToId && (
                          <div className="flex items-center">
                            <User className="h-4 w-4 mr-1" />
                            <span>Assigned</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex space-x-2 mt-4">
                        <Button 
                          size="sm" 
                          className="bg-primary hover:bg-blue-700 text-white"
                          data-testid={`button-view-${case_.id}`}
                        >
                          View Details
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-gray-600 text-gray-300 hover:bg-gray-600"
                          data-testid={`button-update-${case_.id}`}
                        >
                          Update
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => handleGetDirections(case_)}
                          className="bg-secondary hover:bg-orange-600 text-white"
                          data-testid={`button-directions-${case_.id}`}
                        >
                          <Navigation className="h-4 w-4 mr-1" />
                          Directions
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="active" className="mt-4">
            <div className="space-y-4">
              {activeCases.length === 0 ? (
                <div className="text-center py-8">
                  <FolderOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">No active cases</p>
                </div>
              ) : (
                activeCases.map((case_) => (
                  <Card key={case_.id} className="bg-surface border-l-4 border-secondary border-gray-600" data-testid={`card-active-case-${case_.id}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg text-text-primary">{case_.caseNumber}</CardTitle>
                          <p className="text-sm text-gray-400 mt-1">{case_.title}</p>
                        </div>
                        <Badge className={getPriorityColor(case_.priority)} data-testid={`badge-active-priority-${case_.id}`}>
                          {case_.priority.toUpperCase()}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      {case_.description && (
                        <p className="text-sm text-gray-300 mb-3" data-testid={`text-active-description-${case_.id}`}>
                          {case_.description}
                        </p>
                      )}
                      
                      {case_.lastSeenLocation && (
                        <div className="flex items-center text-sm text-gray-400 mb-3">
                          <MapPin className="h-4 w-4 mr-2 text-secondary" />
                          <span data-testid={`text-active-location-${case_.id}`}>{case_.lastSeenLocation}</span>
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="bg-primary hover:bg-blue-700 text-white"
                          data-testid={`button-view-active-${case_.id}`}
                        >
                          View Details
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-warning hover:bg-yellow-600 text-black"
                          data-testid={`button-update-active-${case_.id}`}
                        >
                          Update
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => handleGetDirections(case_)}
                          className="bg-secondary hover:bg-orange-600 text-white"
                          data-testid={`button-directions-active-${case_.id}`}
                        >
                          <Navigation className="h-4 w-4 mr-1" />
                          Directions
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <BottomNavigation currentPath="/cases" />

      {/* Navigation Modal */}
      <Dialog open={showNavigationModal} onOpenChange={setShowNavigationModal}>
        <DialogContent className="bg-surface border-gray-600 max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-navigation-prompt">
          <DialogHeader>
            <DialogTitle className="text-text-primary flex items-center">
              <Navigation className="h-5 w-5 mr-2 text-secondary" />
              Location & Navigation
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Choose from recent active calls and view the route
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Call Selection List */}
            <div className="bg-gray-700 rounded-lg p-3">
              <p className="text-sm font-medium text-text-primary mb-3">Recent Active Calls (Last 5)</p>
              <div className="space-y-2">
                {allCases
                  .filter(c => c.lastSeenLat && c.lastSeenLng)
                  .slice(0, 5)
                  .map((call) => (
                    <div
                      key={call.id}
                      onClick={() => handleSelectCall(call)}
                      className={`p-3 rounded border cursor-pointer transition-all ${
                        selectedCall?.id === call.id
                          ? 'bg-secondary border-secondary text-white'
                          : 'bg-gray-800 border-gray-600 text-gray-300 hover:border-gray-500'
                      }`}
                      data-testid={`call-option-${call.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{call.caseNumber}</p>
                          <p className="text-sm opacity-80">{call.title}</p>
                          <p className="text-xs opacity-60">{call.lastSeenLocation}</p>
                          {call.lastSeenLat && call.lastSeenLng && (
                            <p className="text-xs opacity-50 mt-1">
                              {Number(call.lastSeenLat).toFixed(6)}, {Number(call.lastSeenLng).toFixed(6)}
                            </p>
                          )}
                        </div>
                        <div className="text-right">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            call.priority === 'high' ? 'bg-red-600 text-white' :
                            call.priority === 'medium' ? 'bg-orange-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}>
                            {call.priority.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>

              {allCases.filter(c => c.lastSeenLat && c.lastSeenLng).length === 0 && (
                <p className="text-gray-400 text-sm text-center py-4">
                  No cases with location data available
                </p>
              )}
            </div>

            {/* Interactive Map Preview */}
            {selectedCall && (
              <div className="bg-gray-700 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium text-text-primary">Location Preview</p>
                  <Button
                    onClick={handleShowRoute}
                    size="sm"
                    className="bg-primary hover:bg-blue-700 text-white"
                    data-testid="button-show-route"
                  >
                    Show Route
                  </Button>
                </div>
                <div 
                  ref={mapRef}
                  className="h-48 w-full rounded border border-gray-600"
                  data-testid="preview-map"
                />
              </div>
            )}

            {/* Full Route Visualization */}
            {showRoute && selectedCall && (
              <div className="bg-gray-700 rounded-lg p-3">
                <p className="text-sm font-medium text-text-primary mb-2">Full Route</p>
                <div 
                  ref={routeMapRef}
                  className="h-64 w-full rounded border border-gray-600"
                  data-testid="route-map"
                />
                <div className="flex items-center justify-between mt-3">
                  <div className="text-sm text-gray-300">
                    <p className="font-medium">{selectedCall.caseNumber}</p>
                    <p>{selectedCall.lastSeenLocation}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    selectedCall.priority === 'high' ? 'bg-red-600 text-white' :
                    selectedCall.priority === 'medium' ? 'bg-orange-600 text-white' :
                    'bg-gray-600 text-gray-300'
                  }`}>
                    {selectedCall.priority.toUpperCase()}
                  </span>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button
              onClick={() => {
                setShowNavigationModal(false);
                setSelectedCall(null);
                setShowRoute(false);
              }}
              variant="outline"
              className="border-gray-600 text-gray-300"
              data-testid="button-cancel-navigation"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            
            <Button
              onClick={handleStartNavigation}
              disabled={!selectedCall}
              className="bg-secondary hover:bg-orange-600 text-white disabled:opacity-50"
              data-testid="button-start-navigation"
            >
              <Navigation className="h-4 w-4 mr-2" />
              Start Navigation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
