import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MapPin, Navigation, Users, AlertTriangle, RefreshCw, Radio, Search, Filter, Share2, Crosshair, Eye, EyeOff, Zap, MessageSquare, Phone, Map, Compass, Clock, Target, Shield } from "lucide-react";
import BottomNavigation from "@/components/bottom-navigation";
import GoogleMap from "@/components/google-map";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  name: string;
  role: string;
  status: 'available' | 'unavailable' | 'on-break' | 'emergency' | 'enroute' | 'onscene' | 'virtual';
  location?: {
    lat: number;
    lng: number;
  };
  lastSeen?: string;
}

interface Case {
  id: string;
  caseNumber: string;
  title: string;
  priority: 'low' | 'medium' | 'high';
  status: 'open' | 'in-progress' | 'closed';
  location?: {
    lat: number;
    lng: number;
    address: string;
  };
}

interface MapLocation {
  lat: number;
  lng: number;
  title?: string;
  description?: string;
  type?: 'user' | 'case' | 'incident' | 'landmark';
  status?: 'available' | 'unavailable' | 'emergency' | 'enroute' | 'onscene' | 'virtual' | 'on-break';
}

export default function MapPage() {
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleLayers, setVisibleLayers] = useState({
    users: true,
    cases: true,
    incidents: true,
    landmarks: true,
    emergencyZones: true,
    routes: false,
    weather: false
  });
  const [selectedTeamMember, setSelectedTeamMember] = useState<User | null>(null);
  const [showTeamComms, setShowTeamComms] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [trackingEnabled, setTrackingEnabled] = useState(false);
  const [emergencyMode, setEmergencyMode] = useState(false);
  
  const { toast } = useToast();

  const { data: activeUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users/active"],
  });

  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  const availableUsers = activeUsers.filter(user => user.status === 'available');
  const emergencyUsers = activeUsers.filter(user => user.status === 'emergency');
  const enRouteUsers = activeUsers.filter(user => user.status === 'enroute');
  const onSceneUsers = activeUsers.filter(user => user.status === 'onscene');

  // Get current location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error('Location error:', error)
      );
    }
  }, []);

  // Start location tracking
  useEffect(() => {
    let watchId: number;
    if (trackingEnabled && navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error('Tracking error:', error),
        { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
      );
    }
    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [trackingEnabled]);

  const toggleLayer = (layer: keyof typeof visibleLayers) => {
    setVisibleLayers(prev => ({ ...prev, [layer]: !prev[layer] }));
  };

  const centerOnLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          toast({
            title: "Location Updated",
            description: "Map centered on your current location"
          });
        },
        (error) => {
          toast({
            title: "Location Error",
            description: "Could not get your current location",
            variant: "destructive"
          });
        }
      );
    }
  };

  const shareCurrentLocation = () => {
    if (currentLocation) {
      const url = `https://www.google.com/maps/@${currentLocation.lat},${currentLocation.lng},15z`;
      if (navigator.share) {
        navigator.share({
          title: 'My Current Location',
          text: `Emergency responder location: ${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`,
          url: url,
        }).catch(console.error);
      } else {
        navigator.clipboard.writeText(url).then(() => {
          toast({
            title: "Location Shared",
            description: "Location URL copied to clipboard"
          });
        });
      }
    }
  };

  const toggleEmergencyMode = () => {
    setEmergencyMode(!emergencyMode);
    toast({
      title: emergencyMode ? "Emergency Mode Disabled" : "Emergency Mode Enabled",
      description: emergencyMode ? "Returned to normal operations" : "All features prioritized for emergency response",
      variant: emergencyMode ? "default" : "destructive"
    });
  };

  const startTeamComm = (user: User) => {
    setSelectedTeamMember(user);
    setShowTeamComms(true);
  };

  // Convert users and cases to map locations
  const mapLocations: MapLocation[] = [
    // Mock user locations with realistic Muskegon area coordinates
    ...activeUsers.map((user, index) => {
      // Status is already in the correct format from the database
      const mapStatus = user.status;
      
      return {
        lat: 43.2187 + (Math.random() - 0.5) * 0.02, // Spread around Muskegon
        lng: -86.298 + (Math.random() - 0.5) * 0.02,
        title: user.name,
        description: `${user.role} - Status: ${user.status.toUpperCase()}`,
        type: 'user' as const,
        status: mapStatus
      };
    }),
    // Mock case locations
    ...activeCases.map((case_, index) => ({
      lat: 43.2187 + (Math.random() - 0.5) * 0.05, // Wider spread for cases
      lng: -86.298 + (Math.random() - 0.5) * 0.05,
      title: case_.caseNumber,
      description: `${case_.title} - Priority: ${case_.priority.toUpperCase()}`,
      type: 'case' as const,
    })),
    // Mock incident locations
    {
      lat: 43.2342,
      lng: -86.2901,
      title: "Training Exercise",
      description: "SAR Training in Progress",
      type: 'incident' as const,
    },
    {
      lat: 43.1987,
      lng: -86.3123,
      title: "Base Station",
      description: "West Michigan Watchdog HQ",
      type: 'landmark' as const,
    }
  ];

  const handleLocationClick = (location: MapLocation) => {
    setSelectedLocation(location);
  };

  // Filter locations based on search and layers
  const filteredLocations = mapLocations.filter(location => {
    const matchesSearch = !searchTerm || 
      location.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.description?.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesLayer = 
      (location.type === 'user' && visibleLayers.users) ||
      (location.type === 'case' && visibleLayers.cases) ||
      (location.type === 'incident' && visibleLayers.incidents) ||
      (location.type === 'landmark' && visibleLayers.landmarks);
      
    return matchesSearch && matchesLayer;
  });

  const getLocationStats = () => {
    return {
      totalLocations: mapLocations.length,
      activeUsers: activeUsers.length,
      activeCases: activeCases.length,
      emergencies: emergencyUsers.length,
      inTransit: enRouteUsers.length,
      onScene: onSceneUsers.length
    };
  };

  const stats = getLocationStats();

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary pb-20">
      {/* Enhanced Header */}
      <div className={`${emergencyMode ? 'bg-red-900/50 border-red-500' : 'bg-surface'} border-b border-gray-600 p-4 transition-colors`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <MapPin className="h-6 w-6 text-secondary" />
            <h1 className="text-2xl font-bold text-text-primary" data-testid="text-page-title">
              {emergencyMode ? 'EMERGENCY OPS MAP' : 'Location & Navigation'}
            </h1>
            {emergencyMode && (
              <Badge className="bg-red-600 text-white animate-pulse">
                <Zap className="h-3 w-3 mr-1" />
                EMERGENCY MODE
              </Badge>
            )}
          </div>
          
          {/* Control Buttons */}
          <div className="flex items-center space-x-2">
            <Button
              onClick={toggleEmergencyMode}
              size="sm"
              variant={emergencyMode ? "destructive" : "outline"}
              className={emergencyMode ? "animate-pulse" : "border-red-600 text-red-400 hover:bg-red-600 hover:text-white"}
              data-testid="button-emergency-mode"
            >
              <Shield className="h-4 w-4 mr-1" />
              {emergencyMode ? 'Exit Emergency' : 'Emergency Mode'}
            </Button>
            
            <Button
              onClick={() => setShowFilters(!showFilters)}
              size="sm"
              variant="outline"
              className="border-secondary text-secondary hover:bg-secondary hover:text-white"
              data-testid="button-filters"
            >
              <Filter className="h-4 w-4 mr-1" />
              Filters
            </Button>
          </div>
        </div>

        {/* Real-time Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-sm">
          <Badge className="bg-success text-white justify-center" data-testid="badge-available">
            <Users className="h-3 w-3 mr-1" />
            {stats.activeUsers} Active
          </Badge>
          <Badge className="bg-primary text-white justify-center" data-testid="badge-cases">
            <Target className="h-3 w-3 mr-1" />
            {stats.activeCases} Cases
          </Badge>
          <Badge className="bg-warning text-black justify-center" data-testid="badge-enroute">
            <Navigation className="h-3 w-3 mr-1" />
            {stats.inTransit} En Route
          </Badge>
          <Badge className="bg-purple-600 text-white justify-center" data-testid="badge-onscene">
            <MapPin className="h-3 w-3 mr-1" />
            {stats.onScene} On Scene
          </Badge>
          {stats.emergencies > 0 && (
            <Badge className="bg-destructive text-white animate-pulse justify-center" data-testid="badge-emergencies">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {stats.emergencies} Emergency
            </Badge>
          )}
          <Badge className="bg-gray-600 text-white justify-center" data-testid="badge-total">
            <Map className="h-3 w-3 mr-1" />
            {stats.totalLocations} Total
          </Badge>
        </div>
      </div>

      {/* Advanced Controls Panel */}
      {showFilters && (
        <div className="bg-gray-700 border-b border-gray-600 p-4 space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search locations, team members, cases..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-surface border-gray-600"
              data-testid="input-search-map"
            />
          </div>

          {/* Layer Controls */}
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => toggleLayer('users')}
              size="sm"
              variant={visibleLayers.users ? "default" : "outline"}
              className="text-xs"
              data-testid="button-toggle-users"
            >
              <Users className="h-3 w-3 mr-1" />
              Team ({activeUsers.length})
              {visibleLayers.users ? <Eye className="h-3 w-3 ml-1" /> : <EyeOff className="h-3 w-3 ml-1" />}
            </Button>
            
            <Button
              onClick={() => toggleLayer('cases')}
              size="sm"
              variant={visibleLayers.cases ? "default" : "outline"}
              className="text-xs"
              data-testid="button-toggle-cases"
            >
              <Target className="h-3 w-3 mr-1" />
              Cases ({activeCases.length})
              {visibleLayers.cases ? <Eye className="h-3 w-3 ml-1" /> : <EyeOff className="h-3 w-3 ml-1" />}
            </Button>

            <Button
              onClick={() => toggleLayer('incidents')}
              size="sm"
              variant={visibleLayers.incidents ? "default" : "outline"}
              className="text-xs"
              data-testid="button-toggle-incidents"
            >
              <AlertTriangle className="h-3 w-3 mr-1" />
              Incidents
              {visibleLayers.incidents ? <Eye className="h-3 w-3 ml-1" /> : <EyeOff className="h-3 w-3 ml-1" />}
            </Button>

            <Button
              onClick={() => toggleLayer('routes')}
              size="sm"
              variant={visibleLayers.routes ? "default" : "outline"}
              className="text-xs"
              data-testid="button-toggle-routes"
            >
              <Navigation className="h-3 w-3 mr-1" />
              Routes
              {visibleLayers.routes ? <Eye className="h-3 w-3 ml-1" /> : <EyeOff className="h-3 w-3 ml-1" />}
            </Button>

            <Button
              onClick={() => toggleLayer('weather')}
              size="sm"
              variant={visibleLayers.weather ? "default" : "outline"}
              className="text-xs"
              data-testid="button-toggle-weather"
            >
              <Compass className="h-3 w-3 mr-1" />
              Weather
              {visibleLayers.weather ? <Eye className="h-3 w-3 ml-1" /> : <EyeOff className="h-3 w-3 ml-1" />}
            </Button>
          </div>

          {/* Location Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                onClick={() => setTrackingEnabled(!trackingEnabled)}
                size="sm"
                variant={trackingEnabled ? "default" : "outline"}
                className={trackingEnabled ? "bg-success" : ""}
                data-testid="button-toggle-tracking"
              >
                {trackingEnabled ? (
                  <>
                    <Zap className="h-3 w-3 mr-1" />
                    Live Tracking ON
                  </>
                ) : (
                  <>
                    <Crosshair className="h-3 w-3 mr-1" />
                    Start Tracking
                  </>
                )}
              </Button>
              
              <Button
                onClick={centerOnLocation}
                size="sm"
                variant="outline"
                className="border-secondary text-secondary hover:bg-secondary hover:text-white"
                data-testid="button-center-location"
              >
                <Crosshair className="h-4 w-4 mr-1" />
                Center Map
              </Button>
            </div>

            {currentLocation && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-400">
                  Current: {currentLocation.lat.toFixed(4)}°, {currentLocation.lng.toFixed(4)}°
                </span>
                <Button
                  onClick={shareCurrentLocation}
                  size="sm"
                  variant="outline"
                  className="text-xs border-gray-600 hover:bg-gray-600"
                  data-testid="button-share-location"
                >
                  <Share2 className="h-3 w-3 mr-1" />
                  Share
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="p-4 space-y-4">
        {/* Enhanced Main Map Area */}
        <div className="relative">
          <GoogleMap
            center={currentLocation || { lat: 43.2187, lng: -86.298 }}
            locations={filteredLocations.map(loc => ({
              ...loc,
              status: loc.status === 'enroute' ? 'en-route' as const : 
                     loc.status === 'onscene' ? 'on-scene' as const :
                     loc.status === 'on-break' ? undefined :
                     loc.status === 'virtual' ? undefined :
                     loc.status
            }))}
            height="65vh"
            onLocationClick={(location) => {
              // Convert back to internal format
              const convertedLocation = {
                ...location,
                status: location.status === 'en-route' ? 'enroute' as const :
                       location.status === 'on-scene' ? 'onscene' as const :
                       location.status
              };
              handleLocationClick(convertedLocation);
            }}
            showCurrentLocation={true}
          />
          
          {/* Map Overlay Controls */}
          <div className="absolute top-4 right-4 space-y-2">
            <Button
              onClick={centerOnLocation}
              size="sm"
              className="bg-secondary hover:bg-orange-600 text-white shadow-lg"
              data-testid="button-recenter"
            >
              <Crosshair className="h-4 w-4" />
            </Button>
            
            {trackingEnabled && (
              <div className="bg-success text-white px-2 py-1 rounded text-xs shadow-lg animate-pulse">
                <Zap className="h-3 w-3 inline mr-1" />
                LIVE
              </div>
            )}
          </div>
        </div>

        {/* Selected Location Info */}
        {selectedLocation && (
          <Card className="bg-surface border-gray-600 border-secondary" data-testid="card-selected-location">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-text-primary flex items-center">
                <MapPin className="w-5 h-5 mr-2 text-secondary" />
                {selectedLocation.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-2">{selectedLocation.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge className={`text-xs ${
                    selectedLocation.type === 'user' ? 'bg-blue-600' :
                    selectedLocation.type === 'case' ? 'bg-orange-600' :
                    selectedLocation.type === 'incident' ? 'bg-red-600' :
                    'bg-gray-600'
                  } text-white`}>
                    {selectedLocation.type?.toUpperCase()}
                  </Badge>
                  {selectedLocation.status && (
                    <Badge className={`text-xs ${
                      selectedLocation.status === 'available' ? 'bg-success' :
                      selectedLocation.status === 'emergency' ? 'bg-destructive' :
                      selectedLocation.status === 'enroute' ? 'bg-warning text-black' :
                      selectedLocation.status === 'onscene' ? 'bg-purple-600' :
                      'bg-gray-500'
                    } text-white`}>
                      {selectedLocation.status.replace('enroute', 'en-route').replace('onscene', 'on-scene').toUpperCase()}
                    </Badge>
                  )}
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedLocation(null)}
                  className="border-gray-600 text-gray-300"
                >
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-surface border-gray-600" data-testid="card-stat-active">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-success mx-auto mb-2" />
              <p className="text-2xl font-bold text-success" data-testid="text-active-count">{availableUsers.length}</p>
              <p className="text-sm text-gray-400">Active Units</p>
            </CardContent>
          </Card>

          <Card className="bg-surface border-gray-600" data-testid="card-stat-cases">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="h-8 w-8 text-warning mx-auto mb-2" />
              <p className="text-2xl font-bold text-warning" data-testid="text-cases-count">{activeCases.length}</p>
              <p className="text-sm text-gray-400">Active Cases</p>
            </CardContent>
          </Card>

          <Card className="bg-surface border-gray-600" data-testid="card-stat-emergency">
            <CardContent className="p-4 text-center">
              <div className="h-8 w-8 bg-destructive rounded-full mx-auto mb-2 flex items-center justify-center animate-pulse">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
              <p className="text-2xl font-bold text-destructive" data-testid="text-emergency-count">{emergencyUsers.length}</p>
              <p className="text-sm text-gray-400">Emergency</p>
            </CardContent>
          </Card>

          <Card className="bg-surface border-gray-600" data-testid="card-stat-coverage">
            <CardContent className="p-4 text-center">
              <Navigation className="h-8 w-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-400" data-testid="text-coverage">85%</p>
              <p className="text-sm text-gray-400">Coverage</p>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Team Activity Panel */}
        <Tabs defaultValue="team" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-surface">
            <TabsTrigger value="team" className="data-[state=active]:bg-secondary">Team</TabsTrigger>
            <TabsTrigger value="cases" className="data-[state=active]:bg-secondary">Cases</TabsTrigger>
            <TabsTrigger value="comms" className="data-[state=active]:bg-secondary">Comms</TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-secondary">Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="team" className="mt-4">
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-lg text-text-primary flex items-center justify-between">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-secondary" />
                    Active Team Members ({activeUsers.length})
                  </div>
                  <Button
                    onClick={() => setShowTeamComms(true)}
                    size="sm"
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary hover:text-white"
                  >
                    <Radio className="h-3 w-3 mr-1" />
                    Open Comms
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 max-h-60 overflow-y-auto">
                {activeUsers.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-4 bg-gray-700 rounded hover:bg-gray-600 cursor-pointer transition-colors"
                    onClick={() => startTeamComm(user)}
                    data-testid={`user-${user.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-5 h-5 rounded-full ${
                        user.status === 'available' ? 'bg-success animate-pulse' :
                        user.status === 'emergency' ? 'bg-destructive animate-pulse' :
                        user.status === 'enroute' ? 'bg-warning' :
                        user.status === 'onscene' ? 'bg-purple-600' :
                        'bg-gray-500'
                      }`} />
                      <div>
                        <p className="font-semibold text-lg text-text-primary">{user.name}</p>
                        <p className="text-sm text-gray-400 font-medium">{user.role}</p>
                        {user.lastSeen && (
                          <p className="text-sm text-gray-500">
                            <Clock className="h-4 w-4 inline mr-1" />
                            {user.lastSeen}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={`text-lg px-4 py-2 font-bold ${
                        user.status === 'available' ? 'bg-success text-white' :
                        user.status === 'emergency' ? 'bg-destructive text-white animate-pulse' :
                        user.status === 'enroute' ? 'bg-warning text-black' :
                        user.status === 'onscene' ? 'bg-purple-600 text-white' :
                        'bg-gray-500 text-white'
                      } rounded-md`}>
                        {user.status.replace('enroute', 'EN-ROUTE').replace('onscene', 'ON-SCENE').toUpperCase()}
                      </Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0 text-gray-400 hover:text-secondary"
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cases" className="mt-4">
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-lg text-text-primary flex items-center">
                  <Target className="h-5 w-5 mr-2 text-secondary" />
                  Active Cases ({activeCases.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 max-h-60 overflow-y-auto">
                {activeCases.map((case_) => (
                  <div
                    key={case_.id}
                    className="p-4 bg-gray-700 rounded border-l-4 border-secondary hover:bg-gray-600 cursor-pointer transition-colors"
                    data-testid={`case-${case_.id}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-lg text-text-primary">{case_.caseNumber}</h4>
                      <Badge className={`text-sm px-3 py-1 font-bold ${
                        case_.priority === 'high' ? 'bg-destructive text-white' :
                        case_.priority === 'medium' ? 'bg-warning text-black' :
                        'bg-success text-white'
                      }`}>
                        {case_.priority.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-300 mb-3 font-medium">{case_.title}</p>
                    
                    {case_.location?.address && (
                      <p className="text-sm text-gray-400 mb-3 flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-secondary" />
                        Last seen: {case_.location.address}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-xs text-gray-500">
                        <Clock className="h-3 w-3 mr-1" />
                        3 hours ago
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button
                          onClick={() => {
                            // Mock coordinates for Pine Valley Trail
                            const destination = case_.id === 'case-001' 
                              ? { lat: 43.2342, lng: -86.2901 }
                              : { lat: 43.2187, lng: -86.298 };
                            
                            if (currentLocation) {
                              const directionsUrl = `https://www.google.com/maps/dir/${currentLocation.lat},${currentLocation.lng}/${destination.lat},${destination.lng}`;
                              window.open(directionsUrl, '_blank');
                            } else {
                              toast({
                                title: "Location Required",
                                description: "Enable location services to get directions",
                                variant: "destructive"
                              });
                            }
                          }}
                          size="sm"
                          className="bg-secondary hover:bg-orange-600 text-white text-xs px-3"
                          data-testid={`button-directions-${case_.id}`}
                        >
                          <Navigation className="h-3 w-3 mr-1" />
                          Directions
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-600 text-xs px-3"
                          data-testid={`button-details-${case_.id}`}
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-2 pt-2 border-t border-gray-600">
                      <span className="text-xs text-gray-400">Status: </span>
                      <span className="text-xs font-medium text-text-primary">{case_.status.toUpperCase()}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="comms" className="mt-4">
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-lg text-text-primary flex items-center">
                  <Radio className="h-5 w-5 mr-2 text-secondary" />
                  Communications Hub
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => setShowTeamComms(true)}
                    className="bg-primary hover:bg-blue-700 text-white"
                    data-testid="button-team-chat"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Team Chat
                  </Button>
                  <Button
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary hover:text-white"
                    data-testid="button-radio-check"
                  >
                    <Radio className="h-4 w-4 mr-2" />
                    Radio Check
                  </Button>
                  <Button
                    variant="outline"
                    className="border-yellow-500 text-yellow-400 hover:bg-yellow-500 hover:text-black"
                    data-testid="button-send-alert"
                  >
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Send Alert
                  </Button>
                  <Button
                    variant="outline"
                    className="border-green-500 text-green-400 hover:bg-green-500 hover:text-black"
                    data-testid="button-status-update"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Status Update
                  </Button>
                </div>
                
                <div className="pt-2 border-t border-gray-600">
                  <p className="text-xs text-gray-400 mb-2">Quick Communication</p>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs border-gray-600 justify-start"
                    >
                      <Phone className="h-3 w-3 mr-2" />
                      Call Base Station
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs border-gray-600 justify-start"
                    >
                      <Share2 className="h-3 w-3 mr-2" />
                      Broadcast Location
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="mt-4">
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-lg text-text-primary flex items-center">
                  <Compass className="h-5 w-5 mr-2 text-secondary" />
                  Navigation Tools
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 gap-3">
                  <Button
                    className="bg-secondary hover:bg-orange-600 text-white justify-start"
                    data-testid="button-get-directions"
                  >
                    <Navigation className="h-4 w-4 mr-3" />
                    Get Directions to Active Call
                  </Button>
                  <Button
                    onClick={centerOnLocation}
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary hover:text-white justify-start"
                    data-testid="button-center-map"
                  >
                    <Crosshair className="h-4 w-4 mr-3" />
                    Center Map on My Location
                  </Button>
                  <Button
                    onClick={shareCurrentLocation}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-600 justify-start"
                    data-testid="button-share-coords"
                  >
                    <Share2 className="h-4 w-4 mr-3" />
                    Share My Coordinates
                  </Button>
                  <Button
                    variant="outline"
                    className="border-yellow-500 text-yellow-400 hover:bg-yellow-500 hover:text-black justify-start"
                    data-testid="button-mark-waypoint"
                  >
                    <MapPin className="h-4 w-4 mr-3" />
                    Mark Waypoint
                  </Button>
                </div>
                
                <div className="pt-2 border-t border-gray-600">
                  <p className="text-xs text-gray-400 mb-2">Advanced Features</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Live GPS Tracking</span>
                      <Button
                        onClick={() => setTrackingEnabled(!trackingEnabled)}
                        size="sm"
                        variant={trackingEnabled ? "default" : "outline"}
                        className={trackingEnabled ? "bg-success text-white" : "border-gray-600"}
                      >
                        {trackingEnabled ? 'ON' : 'OFF'}
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Emergency Mode</span>
                      <Button
                        onClick={toggleEmergencyMode}
                        size="sm"
                        variant={emergencyMode ? "destructive" : "outline"}
                        className={emergencyMode ? "animate-pulse" : "border-red-600 text-red-400"}
                      >
                        {emergencyMode ? 'ACTIVE' : 'STANDBY'}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Team Communications Modal */}
      <Dialog open={showTeamComms} onOpenChange={setShowTeamComms}>
        <DialogContent className="bg-surface border-gray-600 max-w-md" data-testid="dialog-team-comms">
          <DialogHeader>
            <DialogTitle className="text-text-primary flex items-center">
              <Radio className="h-5 w-5 mr-2 text-secondary" />
              Team Communications
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Quick communication with {selectedTeamMember?.name || 'team'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-3">
              <Button className="bg-primary hover:bg-blue-700 text-white justify-start">
                <MessageSquare className="h-4 w-4 mr-3" />
                Send Quick Message
              </Button>
              <Button variant="outline" className="border-secondary text-secondary hover:bg-secondary hover:text-white justify-start">
                <Phone className="h-4 w-4 mr-3" />
                Voice Call
              </Button>
              <Button variant="outline" className="border-warning text-warning hover:bg-warning hover:text-black justify-start">
                <AlertTriangle className="h-4 w-4 mr-3" />
                Send Alert
              </Button>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => setShowTeamComms(false)}
              variant="outline"
              className="border-gray-600 text-gray-300"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <BottomNavigation currentPath="/map" />
    </div>
  );
}