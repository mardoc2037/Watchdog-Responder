import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Monitor, 
  Send, 
  Users, 
  MapPin, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Activity,
  Radio,
  Truck,
  Phone,
  Mail,
  Navigation,
  Search,
  Filter,
  Eye
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BottomNavigation from "@/components/bottom-navigation";
import type { User, Case, Dispatch, Vehicle } from "@shared/schema";

const dispatchSchema = z.object({
  caseId: z.string().min(1, "Case is required"),
  userId: z.string().min(1, "User is required"),
  notes: z.string().optional(),
});

const createCaseSchema = z.object({
  title: z.string().min(2, "Title is required"),
  description: z.string().optional(),
  priority: z.enum(["high", "medium", "low"]),
  type: z.enum(["missing_person", "sar", "investigation"]),
  lastSeenLocation: z.string().optional(),
  lastSeenLat: z.string().optional(),
  lastSeenLng: z.string().optional(),
});

type DispatchForm = z.infer<typeof dispatchSchema>;
type CreateCaseForm = z.infer<typeof createCaseSchema>;

export default function AdminPortalPage() {
  const [selectedTab, setSelectedTab] = useState("monitor");
  const [showDispatchDialog, setShowDispatchDialog] = useState(false);
  const [showCreateCaseDialog, setShowCreateCaseDialog] = useState(false);
  const [selectedCase, setSelectedCase] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch data
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({ 
    queryKey: ["/api/admin/users"],
    refetchInterval: 5000 // Refresh every 5 seconds for real-time monitoring
  });
  
  const { data: cases = [], isLoading: casesLoading } = useQuery<Case[]>({ 
    queryKey: ["/api/cases"],
    refetchInterval: 3000 // Refresh every 3 seconds for case updates
  });

  const { data: dispatches = [], isLoading: dispatchesLoading } = useQuery<Dispatch[]>({ 
    queryKey: ["/api/dispatches"],
    refetchInterval: 5000
  });

  const { data: vehicles = [] } = useQuery<Vehicle[]>({ 
    queryKey: ["/api/admin/vehicles"] 
  });

  // Forms
  const dispatchForm = useForm<DispatchForm>({
    resolver: zodResolver(dispatchSchema),
  });

  const createCaseForm = useForm<CreateCaseForm>({
    resolver: zodResolver(createCaseSchema),
    defaultValues: { priority: "medium", type: "missing_person" }
  });

  // Mutations
  const dispatchMutation = useMutation({
    mutationFn: (data: DispatchForm) => apiRequest("POST", "/api/dispatches", data),
    onSuccess: () => {
      toast({ title: "Success", description: "Unit dispatched successfully" });
      dispatchForm.reset();
      setShowDispatchDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/dispatches"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to dispatch unit", variant: "destructive" });
    }
  });

  const createCaseMutation = useMutation({
    mutationFn: (data: CreateCaseForm) => apiRequest("POST", "/api/cases", data),
    onSuccess: () => {
      toast({ title: "Success", description: "Case created successfully" });
      createCaseForm.reset();
      setShowCreateCaseDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create case", variant: "destructive" });
    }
  });

  const updateUserStatusMutation = useMutation({
    mutationFn: ({ userId, status }: { userId: string; status: string }) => 
      apiRequest("PATCH", `/api/users/${userId}/status`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    }
  });

  // Filter active users by status and search
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (user.badge && user.badge.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-success text-white';
      case 'enroute': return 'bg-warning text-black';
      case 'onscene': return 'bg-info text-white';
      case 'virtual': return 'bg-purple-600 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-danger text-white';
      case 'medium': return 'bg-warning text-black';
      case 'low': return 'bg-success text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getActiveUserStats = () => {
    const available = users.filter(u => u.status === 'available').length;
    const enroute = users.filter(u => u.status === 'enroute').length;
    const onscene = users.filter(u => u.status === 'onscene').length;
    const unavailable = users.filter(u => u.status === 'unavailable').length;
    
    return { available, enroute, onscene, unavailable, total: users.length };
  };

  const stats = getActiveUserStats();

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary pb-20">
      {/* Header */}
      <div className="bg-surface border-b border-gray-600 p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-text-primary flex items-center" data-testid="text-page-title">
            <Monitor className="w-6 h-6 mr-2 text-blue-500" />
            Command Center
          </h1>
          <div className="flex items-center space-x-2">
            <Badge className="bg-blue-600 text-white">
              <Activity className="w-3 h-3 mr-1" />
              {stats.total} Units
            </Badge>
            <Badge className="bg-success text-white">
              {stats.available} Available
            </Badge>
            <Badge className="bg-warning text-black">
              {stats.enroute} En Route
            </Badge>
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-3 bg-gray-800">
            <TabsTrigger value="monitor" className="data-[state=active]:bg-secondary">
              <Monitor className="w-4 h-4 mr-1" />
              Monitor
            </TabsTrigger>
            <TabsTrigger value="dispatch" className="data-[state=active]:bg-secondary">
              <Send className="w-4 h-4 mr-1" />
              Dispatch
            </TabsTrigger>
            <TabsTrigger value="cases" className="data-[state=active]:bg-secondary">
              <AlertTriangle className="w-4 h-4 mr-1" />
              Cases
            </TabsTrigger>
          </TabsList>

          {/* Monitor Tab */}
          <TabsContent value="monitor" className="space-y-4">
            {/* Status Overview Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-surface border-gray-600">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <CheckCircle className="h-6 w-6 text-success" />
                  </div>
                  <div className="text-2xl font-bold text-success">{stats.available}</div>
                  <div className="text-sm text-gray-400">Available</div>
                </CardContent>
              </Card>
              
              <Card className="bg-surface border-gray-600">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Navigation className="h-6 w-6 text-warning" />
                  </div>
                  <div className="text-2xl font-bold text-warning">{stats.enroute}</div>
                  <div className="text-sm text-gray-400">En Route</div>
                </CardContent>
              </Card>
              
              <Card className="bg-surface border-gray-600">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <MapPin className="h-6 w-6 text-info" />
                  </div>
                  <div className="text-2xl font-bold text-info">{stats.onscene}</div>
                  <div className="text-sm text-gray-400">On Scene</div>
                </CardContent>
              </Card>
              
              <Card className="bg-surface border-gray-600">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <XCircle className="h-6 w-6 text-gray-500" />
                  </div>
                  <div className="text-2xl font-bold text-gray-500">{stats.unavailable}</div>
                  <div className="text-sm text-gray-400">Off Duty</div>
                </CardContent>
              </Card>
            </div>

            {/* Search and Filter Controls */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search users by name, email, or badge..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600"
                    data-testid="input-search"
                  />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-400" />
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40 bg-gray-700 border-gray-600">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="enroute">En Route</SelectItem>
                    <SelectItem value="onscene">On Scene</SelectItem>
                    <SelectItem value="virtual">Virtual</SelectItem>
                    <SelectItem value="unavailable">Off Duty</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active Units */}
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  Active Units ({filteredUsers.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading units...</div>
                ) : filteredUsers.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Users className="h-8 w-8 mx-auto mb-2" />
                    <p>No units found</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredUsers.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                        data-testid={`user-monitor-${user.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold text-sm">
                              {user.name.split(' ').map((n: string) => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-medium text-text-primary">{user.name}</h3>
                            <div className="flex items-center space-x-2 text-sm text-gray-400">
                              <span>{user.email}</span>
                              {user.badge && <span>• Badge: {user.badge}</span>}
                              {user.role && <span>• {user.role.toUpperCase()}</span>}
                            </div>
                            {user.currentLat && user.currentLng && (
                              <div className="flex items-center text-xs text-gray-500 mt-1">
                                <MapPin className="w-3 h-3 mr-1" />
                                Location: {parseFloat(user.currentLat).toFixed(4)}, {parseFloat(user.currentLng).toFixed(4)}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusBadgeColor(user.status)}>
                            {user.status.replace('_', ' ').toUpperCase()}
                          </Badge>
                          
                          <Select onValueChange={(status) => updateUserStatusMutation.mutate({ userId: user.id, status })}>
                            <SelectTrigger className="w-32 h-8 bg-gray-600 border-gray-500 text-xs">
                              <SelectValue placeholder="Change Status" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              <SelectItem value="available">Available</SelectItem>
                              <SelectItem value="enroute">En Route</SelectItem>
                              <SelectItem value="onscene">On Scene</SelectItem>
                              <SelectItem value="virtual">Virtual</SelectItem>
                              <SelectItem value="unavailable">Off Duty</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Dispatch Tab */}
          <TabsContent value="dispatch" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Active Dispatches</h2>
              <Dialog open={showDispatchDialog} onOpenChange={setShowDispatchDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <Send className="w-4 h-4 mr-2" />
                    New Dispatch
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Create New Dispatch</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={dispatchForm.handleSubmit((data) => dispatchMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="case-select">Select Case</Label>
                      <Select onValueChange={(value) => dispatchForm.setValue("caseId", value)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select case" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {cases.map((case_) => (
                            <SelectItem key={case_.id} value={case_.id}>
                              {case_.title} - {case_.priority.toUpperCase()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="user-select">Select Unit</Label>
                      <Select onValueChange={(value) => dispatchForm.setValue("userId", value)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select unit" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {users.filter(u => u.status === 'available').map((user) => (
                            <SelectItem key={user.id} value={user.id}>
                              {user.name} ({user.badge || 'No Badge'})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="notes">Dispatch Notes</Label>
                      <Input
                        id="notes"
                        {...dispatchForm.register("notes")}
                        placeholder="Additional instructions..."
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={dispatchMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                        data-testid="button-create-dispatch"
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Dispatch Unit
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowDispatchDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Active Dispatches List */}
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Current Dispatches</CardTitle>
              </CardHeader>
              <CardContent>
                {dispatchesLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading dispatches...</div>
                ) : dispatches.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Send className="h-8 w-8 mx-auto mb-2" />
                    <p>No active dispatches</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {dispatches.map((dispatch) => {
                      const user = users.find(u => u.id === dispatch.userId);
                      const case_ = cases.find(c => c.id === dispatch.caseId);
                      
                      return (
                        <div
                          key={dispatch.id}
                          className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                        >
                          <div>
                            <h3 className="font-medium text-text-primary">
                              {user?.name || 'Unknown Unit'} → {case_?.title || 'Unknown Case'}
                            </h3>
                            <p className="text-sm text-gray-400">
                              Status: {dispatch.status.replace('_', ' ').toUpperCase()}
                            </p>
                            {dispatch.notes && (
                              <p className="text-xs text-gray-500 mt-1">Notes: {dispatch.notes}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            {case_ && (
                              <Badge className={getPriorityColor(case_.priority)}>
                                {case_.priority.toUpperCase()}
                              </Badge>
                            )}
                            <Badge className={getStatusBadgeColor(dispatch.status)}>
                              {dispatch.status.replace('_', ' ').toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cases Tab */}
          <TabsContent value="cases" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Case Management</h2>
              <Dialog open={showCreateCaseDialog} onOpenChange={setShowCreateCaseDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-orange-600">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Create Case
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-surface border-gray-600">
                  <DialogHeader>
                    <DialogTitle className="text-text-primary">Create New Case</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={createCaseForm.handleSubmit((data) => createCaseMutation.mutate(data))} className="space-y-4">
                    <div>
                      <Label htmlFor="case-title">Case Title</Label>
                      <Input
                        id="case-title"
                        {...createCaseForm.register("title")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="case-type">Case Type</Label>
                      <Select onValueChange={(value) => createCaseForm.setValue("type", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="missing_person">Missing Person</SelectItem>
                          <SelectItem value="sar">Search & Rescue</SelectItem>
                          <SelectItem value="investigation">Investigation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="case-priority">Priority</Label>
                      <Select onValueChange={(value) => createCaseForm.setValue("priority", value as any)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="high">High Priority</SelectItem>
                          <SelectItem value="medium">Medium Priority</SelectItem>
                          <SelectItem value="low">Low Priority</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="case-description">Description</Label>
                      <Input
                        id="case-description"
                        {...createCaseForm.register("description")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="last-seen">Last Seen Location</Label>
                      <Input
                        id="last-seen"
                        {...createCaseForm.register("lastSeenLocation")}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="submit"
                        disabled={createCaseMutation.isPending}
                        className="bg-secondary hover:bg-orange-600"
                        data-testid="button-create-case"
                      >
                        Create Case
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowCreateCaseDialog(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Active Cases List */}
            <Card className="bg-surface border-gray-600">
              <CardHeader>
                <CardTitle className="text-text-primary">Active Cases ({cases.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {casesLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading cases...</div>
                ) : cases.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <AlertTriangle className="h-8 w-8 mx-auto mb-2" />
                    <p>No active cases</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {cases.map((case_) => (
                      <div
                        key={case_.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer"
                        onClick={() => setSelectedCase(case_.id)}
                        data-testid={`case-item-${case_.id}`}
                      >
                        <div>
                          <h3 className="font-medium text-text-primary">{case_.title}</h3>
                          <p className="text-sm text-gray-400">{case_.description}</p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500 mt-1">
                            <span>Type: {case_.type.replace('_', ' ').toUpperCase()}</span>
                            {case_.lastSeenLocation && (
                              <>
                                <span>•</span>
                                <MapPin className="w-3 h-3" />
                                <span>{case_.lastSeenLocation}</span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getPriorityColor(case_.priority)}>
                            {case_.priority.toUpperCase()}
                          </Badge>
                          <Badge className="bg-blue-600 text-white">
                            {case_.status.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNavigation currentPath="/admin-portal" />
    </div>
  );
}