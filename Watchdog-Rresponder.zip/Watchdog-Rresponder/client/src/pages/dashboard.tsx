import { useState, useEffect } from "react";
import HeaderBar from "@/components/header-bar";
import BottomNavigation from "@/components/bottom-navigation";
import ActiveDispatchAlert from "@/components/active-dispatch-alert";
import StatusPanel from "@/components/status-panel";
import MapContainer from "@/components/map-container";
import TeamStatus from "@/components/team-status";
import ActiveCases from "@/components/active-cases";
import QuickActions from "@/components/quick-actions";
import VoiceEmergencyToggle from "@/components/voice-emergency-toggle";
import SOSAlertBanner from "@/components/sos-alert-banner";
import { useWebSocket } from "@/hooks/use-websocket";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function Dashboard() {
  const [currentStatus, setCurrentStatus] = useState("available");
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isEmergencyMode, setIsEmergencyMode] = useState(false);
  
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/profile"],
  });

  const { sendMessage } = useWebSocket();

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setUserLocation(location);
          
          // Send location update via WebSocket
          sendMessage({
            type: 'location_update',
            userId: user?.id,
            lat: location.lat,
            lng: location.lng,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  }, [user?.id, sendMessage]);

  const handleStatusChange = (newStatus: string) => {
    setCurrentStatus(newStatus);
    
    // Send status update via WebSocket
    sendMessage({
      type: 'status_update',
      userId: user?.id,
      status: newStatus,
    });
  };

  const handleEmergencyModeChange = (isActive: boolean) => {
    setIsEmergencyMode(isActive);
    
    // Auto-set status to emergency if activating emergency mode
    if (isActive) {
      handleStatusChange("emergency");
    }
    
    // Send emergency mode update via WebSocket
    sendMessage({
      type: 'emergency_mode_update',
      userId: user?.id,
      emergencyMode: isActive,
    });
  };

  return (
    <div className={`min-h-screen ${
      isEmergencyMode ? 'bg-red-950 border-2 border-red-600 animate-pulse' : 'bg-dark-bg'
    } text-text-primary transition-all duration-300`}>
      {/* SOS Alert Banner - Global priority alerts */}
      <SOSAlertBanner />
      
      <HeaderBar 
        user={user} 
        currentStatus={currentStatus} 
        onStatusToggle={() => handleStatusChange(currentStatus === 'available' ? 'unavailable' : 'available')}
      />
      
      <ActiveDispatchAlert />
      
      {/* Emergency Mode Banner */}
      {isEmergencyMode && (
        <div className="bg-destructive text-white p-3 text-center font-bold animate-pulse">
          🚨 EMERGENCY MODE ACTIVE - ALL UNITS ALERTED 🚨
        </div>
      )}
      
      <main className="pb-20 px-4 space-y-4">
        {/* Voice Emergency Toggle - Priority placement at top */}
        <VoiceEmergencyToggle 
          onEmergencyModeChange={handleEmergencyModeChange}
          isEmergencyMode={isEmergencyMode}
        />
        
        <StatusPanel currentStatus={currentStatus} onStatusChange={handleStatusChange} />
        <MapContainer location={userLocation} />
        <TeamStatus />
        <ActiveCases />
        <QuickActions />
      </main>
      
      <BottomNavigation currentPath="/" />
    </div>
  );
}
