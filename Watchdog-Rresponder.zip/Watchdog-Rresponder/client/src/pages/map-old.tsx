import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import HeaderBar from "@/components/header-bar";
import BottomNavigation from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Users, Crosshair, Route, Share2 } from "lucide-react";
import type { User, Case } from "@shared/schema";

export default function MapPage() {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);

  const { data: activeUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users/active"],
  });

  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-success';
      case 'enroute':
        return 'bg-warning';
      case 'onscene':
        return 'bg-purple-500';
      case 'virtual':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-destructive';
      case 'medium':
        return 'border-warning';
      case 'low':
        return 'border-success';
      default:
        return 'border-gray-500';
    }
  };

  const centerMap = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const getDirections = (case_: Case) => {
    if (case_.lastSeenLat && case_.lastSeenLng) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${case_.lastSeenLat},${case_.lastSeenLng}`;
      window.open(url, '_blank');
    }
  };

  const shareLocation = () => {
    if (userLocation && navigator.share) {
      navigator.share({
        title: 'My Current Location',
        text: `I'm currently at: ${userLocation.lat}, ${userLocation.lng}`,
        url: `https://www.google.com/maps/@${userLocation.lat},${userLocation.lng},15z`,
      });
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      <HeaderBar />
      
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <MapPin className="h-6 w-6 text-secondary" />
            <h1 className="text-xl font-semibold">Location & Navigation</h1>
          </div>
          <Button 
            onClick={centerMap}
            variant="outline" 
            size="sm"
            className="border-gray-600 text-gray-300 hover:bg-gray-600"
            data-testid="button-center-map"
          >
            <Crosshair className="h-4 w-4" />
          </Button>
        </div>

        {/* Map Container */}
        <Card className="bg-surface border-gray-600 mb-6" data-testid="card-map-container">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg text-text-primary flex items-center">
                <Navigation className="h-5 w-5 mr-2 text-secondary" />
                Interactive Map
              </CardTitle>
              <div className="text-sm text-gray-400" data-testid="text-coordinates">
                {userLocation ? 
                  `${userLocation.lat.toFixed(4)}°, ${userLocation.lng.toFixed(4)}°` : 
                  'Getting location...'
                }
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {/* Map placeholder - In production this would be React-Leaflet */}
            <div className="h-64 bg-gray-700 rounded-lg relative overflow-hidden" data-testid="map-container">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-12 w-12 text-gray-500 mx-auto mb-2" />
                  <p className="text-gray-400 mb-1">Interactive Map Loading...</p>
                  {userLocation && (
                    <p className="text-xs text-gray-500">
                      Current: {userLocation.lat.toFixed(4)}°N, {userLocation.lng.toFixed(4)}°W
                    </p>
                  )}
                </div>
              </div>
              
              {/* Mock location markers */}
              {userLocation && (
                <div 
                  className="absolute top-4 left-4 w-4 h-4 bg-success rounded-full border-2 border-white shadow-lg status-pulse"
                  data-testid="marker-user-location"
                ></div>
              )}
              
              {activeCases.map((case_, index) => (
                case_.lastSeenLat && case_.lastSeenLng && (
                  <div
                    key={case_.id}
                    className={`absolute w-4 h-4 bg-secondary rounded-full border-2 border-white shadow-lg cursor-pointer`}
                    style={{
                      top: `${20 + index * 10}%`,
                      right: `${20 + index * 15}%`
                    }}
                    onClick={() => setSelectedCase(case_)}
                    data-testid={`marker-case-${case_.id}`}
                  ></div>
                )
              ))}
            </div>
            
            {/* Navigation Controls */}
            <div className="flex space-x-2 mt-4">
              <Button 
                className="flex-1 bg-primary hover:bg-blue-700 text-white"
                onClick={() => selectedCase && getDirections(selectedCase)}
                disabled={!selectedCase}
                data-testid="button-get-directions"
              >
                <Route className="h-4 w-4 mr-2" />
                Get Directions
              </Button>
              <Button 
                variant="outline" 
                onClick={shareLocation}
                className="border-gray-600 text-gray-300 hover:bg-gray-600"
                data-testid="button-share-location"
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Team Location Status */}
        <Card className="bg-surface border-gray-600 mb-6" data-testid="card-team-locations">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-text-primary flex items-center">
              <Users className="h-5 w-5 mr-2 text-secondary" />
              Team Locations
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              {activeUsers.length === 0 ? (
                <p className="text-gray-400 text-center py-4" data-testid="text-no-active-users">
                  No active team members
                </p>
              ) : (
                activeUsers.map((user) => (
                  <div 
                    key={user.id} 
                    className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                    data-testid={`item-user-${user.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 ${getStatusColor(user.status)} rounded-full`}></div>
                      <div>
                        <p className="font-medium text-sm" data-testid={`text-user-name-${user.id}`}>{user.name}</p>
                        <p className="text-xs text-gray-400" data-testid={`text-user-status-${user.id}`}>
                          {user.status.replace('_', ' ').toUpperCase()}
                          {user.currentLat && user.currentLng && (
                            <span> • Location tracked</span>
                          )}
                        </p>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="text-secondary hover:bg-gray-600"
                      data-testid={`button-contact-${user.id}`}
                    >
                      Contact
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Active Cases on Map */}
        <Card className="bg-surface border-gray-600" data-testid="card-active-cases">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-text-primary">Active Cases</CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              {activeCases.length === 0 ? (
                <p className="text-gray-400 text-center py-4" data-testid="text-no-active-cases">
                  No active cases
                </p>
              ) : (
                activeCases.map((case_) => (
                  <div 
                    key={case_.id}
                    className={`p-4 rounded-lg border-l-4 ${getPriorityColor(case_.priority)} bg-gray-700 cursor-pointer hover:bg-gray-600 transition-colors`}
                    onClick={() => setSelectedCase(case_)}
                    data-testid={`item-case-${case_.id}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-medium" data-testid={`text-case-number-${case_.id}`}>{case_.caseNumber}</h4>
                        <p className="text-sm text-gray-400" data-testid={`text-case-title-${case_.id}`}>{case_.title}</p>
                      </div>
                      <Badge className="bg-secondary text-white text-xs" data-testid={`badge-case-priority-${case_.id}`}>
                        {case_.priority.toUpperCase()}
                      </Badge>
                    </div>
                    
                    {case_.lastSeenLocation && (
                      <div className="flex items-center text-sm text-gray-300 mb-2">
                        <MapPin className="h-4 w-4 mr-2 text-secondary" />
                        <span data-testid={`text-case-location-${case_.id}`}>{case_.lastSeenLocation}</span>
                      </div>
                    )}
                    
                    <div className="flex space-x-2 mt-3">
                      <Button 
                        size="sm" 
                        className="bg-primary hover:bg-blue-700 text-white text-xs"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Navigate to case details
                        }}
                        data-testid={`button-view-case-${case_.id}`}
                      >
                        View Details
                      </Button>
                      {case_.lastSeenLat && case_.lastSeenLng && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-600 text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            getDirections(case_);
                          }}
                          data-testid={`button-directions-${case_.id}`}
                        >
                          <Route className="h-3 w-3 mr-1" />
                          Directions
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <BottomNavigation currentPath="/map" />
    </div>
  );
}
