import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import HeaderBar from "@/components/header-bar";
import BottomNavigation from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  Settings, 
  Shield, 
  Bell, 
  MapPin, 
  Activity, 
  Edit,
  Save,
  Phone,
  Mail,
  Clock,
  Award
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User as UserType } from "@shared/schema";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    badge: '',
    role: '',
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading } = useQuery<UserType>({
    queryKey: ["/api/user/profile"],
  });

  // Use useEffect instead of onSuccess
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        badge: user.badge || '',
        role: user.role || '',
      });
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (updates: Partial<UserType>) => {
      const response = await apiRequest("PATCH", "/api/user/profile", updates);
      return response.json();
    },
    onSuccess: () => {
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(formData);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-success text-white';
      case 'enroute':
        return 'bg-warning text-black';
      case 'onscene':
        return 'bg-purple-500 text-white';
      case 'virtual':
        return 'bg-blue-500 text-white';
      case 'unavailable':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-destructive text-white';
      case 'responder':
        return 'bg-primary text-white';
      case 'sar':
        return 'bg-secondary text-white';
      case 'legal':
        return 'bg-purple-600 text-white';
      case 'veteran':
        return 'bg-green-700 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-bg">
        <HeaderBar />
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-secondary mx-auto mb-4"></div>
            <p className="text-text-primary">Loading profile...</p>
          </div>
        </div>
        <BottomNavigation currentPath="/profile" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      <HeaderBar />
      
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <User className="h-6 w-6 text-secondary" />
            <h1 className="text-xl font-semibold">Profile & Settings</h1>
          </div>
          <Button
            onClick={() => isEditing ? handleSaveProfile() : setIsEditing(true)}
            disabled={updateProfileMutation.isPending}
            className="bg-secondary hover:bg-orange-600 text-white"
            data-testid="button-edit-profile"
          >
            {isEditing ? (
              <>
                <Save className="h-4 w-4 mr-2" />
                Save
              </>
            ) : (
              <>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </>
            )}
          </Button>
        </div>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-surface">
            <TabsTrigger 
              value="profile" 
              className="data-[state=active]:bg-secondary data-[state=active]:text-white"
              data-testid="tab-profile"
            >
              <User className="h-4 w-4 mr-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger 
              value="activity" 
              className="data-[state=active]:bg-secondary data-[state=active]:text-white"
              data-testid="tab-activity"
            >
              <Activity className="h-4 w-4 mr-2" />
              Activity
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="data-[state=active]:bg-secondary data-[state=active]:text-white"
              data-testid="tab-settings"
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-6">
            <div className="space-y-6">
              {/* Basic Information */}
              <Card className="bg-surface border-gray-600" data-testid="card-basic-info">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary">Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      {isEditing ? (
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="bg-gray-700 border-gray-600 text-text-primary mt-1"
                          data-testid="input-name"
                        />
                      ) : (
                        <p className="text-text-primary mt-1" data-testid="text-user-name">
                          {user?.name || 'Not set'}
                        </p>
                      )}
                    </div>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="badge">Badge Number</Label>
                      {isEditing ? (
                        <Input
                          id="badge"
                          value={formData.badge}
                          onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                          className="bg-gray-700 border-gray-600 text-text-primary mt-1"
                          data-testid="input-badge"
                        />
                      ) : (
                        <p className="text-text-primary mt-1" data-testid="text-user-badge">
                          {user?.badge || 'Not assigned'}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="role">Role</Label>
                      {isEditing ? (
                        <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                          <SelectTrigger className="bg-gray-700 border-gray-600 text-text-primary mt-1" data-testid="select-role">
                            <SelectValue placeholder="Select role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="responder">First Responder</SelectItem>
                            <SelectItem value="sar">SAR Team</SelectItem>
                            <SelectItem value="veteran">Veteran</SelectItem>
                            <SelectItem value="legal">Legal Team</SelectItem>
                            <SelectItem value="admin">Administrator</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <div className="mt-1">
                          <Badge className={getRoleBadge(user?.role || '')} data-testid="badge-user-role">
                            {user?.role?.replace('_', ' ').toUpperCase() || 'NOT SET'}
                          </Badge>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Current Status</Label>
                      <div className="mt-1">
                        <Badge className={getStatusColor(user?.status || '')} data-testid="badge-user-status">
                          {user?.status?.replace('_', ' ').toUpperCase() || 'UNKNOWN'}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <Label>Active</Label>
                      <div className="mt-1">
                        <Badge className={user?.isActive ? 'bg-success text-white' : 'bg-gray-500 text-white'} data-testid="badge-user-active">
                          {user?.isActive ? 'ACTIVE' : 'INACTIVE'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card className="bg-surface border-gray-600" data-testid="card-contact-info">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-4 w-4 text-secondary" />
                    <div>
                      <Label>Email Address</Label>
                      <p className="text-text-primary" data-testid="text-user-email">
                        {user?.email || 'Not provided'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-secondary" />
                    <div>
                      <Label>Emergency Contact</Label>
                      <p className="text-text-primary">Not provided</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <MapPin className="h-4 w-4 text-secondary" />
                    <div>
                      <Label>Last Known Location</Label>
                      <p className="text-text-primary" data-testid="text-user-location">
                        {user?.currentLat && user?.currentLng ? 
                          `${parseFloat(user.currentLat).toFixed(4)}°, ${parseFloat(user.currentLng).toFixed(4)}°` : 
                          'Location not tracked'
                        }
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <div className="space-y-6">
              <Card className="bg-surface border-gray-600" data-testid="card-activity-summary">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary">Activity Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-secondary" data-testid="text-cases-count">0</div>
                      <p className="text-gray-400">Active Cases</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-success" data-testid="text-responses-count">0</div>
                      <p className="text-gray-400">Responses</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-surface border-gray-600" data-testid="card-recent-activity">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-gray-700 rounded-lg">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-text-primary">Status updated to Available</p>
                        <p className="text-xs text-gray-400">
                          {user?.lastStatusUpdate ? 
                            new Date(user.lastStatusUpdate).toLocaleString() : 
                            'No recent updates'
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <div className="space-y-6">
              {/* Notification Settings */}
              <Card className="bg-surface border-gray-600" data-testid="card-notification-settings">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary flex items-center">
                    <Bell className="h-5 w-5 mr-2 text-secondary" />
                    Notification Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="push-notifications">Push Notifications</Label>
                      <p className="text-sm text-gray-400">Receive notifications for new dispatches</p>
                    </div>
                    <Switch id="push-notifications" defaultChecked data-testid="switch-push-notifications" />
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="audio-alerts">Audio Alerts</Label>
                      <p className="text-sm text-gray-400">Play sound for emergency dispatches</p>
                    </div>
                    <Switch id="audio-alerts" defaultChecked data-testid="switch-audio-alerts" />
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="location-tracking">Location Tracking</Label>
                      <p className="text-sm text-gray-400">Allow real-time location sharing</p>
                    </div>
                    <Switch id="location-tracking" defaultChecked data-testid="switch-location-tracking" />
                  </div>
                </CardContent>
              </Card>

              {/* Security Settings */}
              <Card className="bg-surface border-gray-600" data-testid="card-security-settings">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-secondary" />
                    Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-gray-400">Add extra security to your account</p>
                    </div>
                    <Button variant="outline" className="border-gray-600 text-gray-300" data-testid="button-setup-2fa">
                      Setup
                    </Button>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>End-to-End Encryption</Label>
                      <p className="text-sm text-gray-400">Secure messaging encryption</p>
                    </div>
                    <Badge className="bg-success text-white" data-testid="badge-encryption-status">
                      ENABLED
                    </Badge>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Change Password</Label>
                      <p className="text-sm text-gray-400">Update your account password</p>
                    </div>
                    <Button variant="outline" className="border-gray-600 text-gray-300" data-testid="button-change-password">
                      Change
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Application Settings */}
              <Card className="bg-surface border-gray-600" data-testid="card-app-settings">
                <CardHeader>
                  <CardTitle className="text-lg text-text-primary">Application Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="theme">Theme</Label>
                    <Select defaultValue="dark">
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-text-primary mt-1" data-testid="select-theme">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="auto">Auto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="language">Language</Label>
                    <Select defaultValue="en">
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-text-primary mt-1" data-testid="select-language">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <BottomNavigation currentPath="/profile" />
    </div>
  );
}
