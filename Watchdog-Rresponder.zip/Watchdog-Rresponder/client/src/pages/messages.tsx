import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageCircle, Search, Send, FileText, Lock, Users, MapPin, Shield, Clock, AlertCircle, Mic, MicOff, Play, Square } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import BottomNavigation from "@/components/bottom-navigation";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  name: string;
  role: string;
  status: 'available' | 'unavailable' | 'on-break' | 'emergency' | 'en-route' | 'on-scene' | 'virtual';
  badge?: string;
  lastSeen?: string;
}

interface Case {
  id: string;
  caseNumber: string;
  title: string;
  priority: 'low' | 'medium' | 'high';
  status: 'open' | 'in-progress' | 'closed';
  location?: string;
}

interface Message {
  id?: string;
  senderId: string;
  recipientId?: string;
  caseId?: string;
  content: string;
  createdAt?: string;
}

export default function Messages() {
  const [selectedTab, setSelectedTab] = useState("users");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [newMessage, setNewMessage] = useState("");
  
  // Voice recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch active users
  const { data: activeUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users/active"],
  });

  // Fetch active cases
  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  // Fetch case messages
  const { data: caseMessages = [] } = useQuery<Message[]>({
    queryKey: ["/api/messages/case", selectedCase?.id],
    enabled: !!selectedCase,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: (data: { recipientId?: string; caseId?: string; content: string }) =>
      apiRequest(`/api/messages`, {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      setNewMessage("");
      setAudioBlob(null);
      toast({
        title: "Message Sent",
        description: "Your secure message has been delivered",
      });
      
      // Invalidate and refetch messages
      if (selectedCase) {
        queryClient.invalidateQueries({ queryKey: ["/api/messages/case", selectedCase.id] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/messages/unread/count"] });
    },
    onError: (error) => {
      console.error("Failed to send message:", error);
      toast({
        title: "Message Failed",
        description: "Could not send your message. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Voice recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const mediaRecorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
      };
      
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start recording timer
      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 30) { // 30 second limit
            stopRecording();
            return 30;
          }
          return prev + 1;
        });
      }, 1000);
      
    } catch (error) {
      toast({
        title: "Recording Error",
        description: "Could not access microphone",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    setIsRecording(false);
  };

  const sendVoiceMessage = () => {
    if (audioBlob) {
      const messageData: { recipientId?: string; caseId?: string; content: string } = {
        content: `🎤 Voice message (${formatTime(recordingTime)})`,
      };

      if (selectedUser) {
        messageData.recipientId = selectedUser.id;
      } else if (selectedCase) {
        messageData.caseId = selectedCase.id;
      }

      sendMessageMutation.mutate(messageData);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const messageData: { recipientId?: string; caseId?: string; content: string } = {
      content: newMessage,
    };

    if (selectedUser) {
      messageData.recipientId = selectedUser.id;
    } else if (selectedCase) {
      messageData.caseId = selectedCase.id;
    }

    sendMessageMutation.mutate(messageData);
  };

  const filteredUsers = activeUsers.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.badge?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCases = activeCases.filter(case_ =>
    case_.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    case_.caseNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      <div className="flex flex-col h-screen">
        {/* Header */}
        <div className="bg-surface border-b border-gray-600 p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-text-primary" data-testid="text-page-title">
              Secure Communications
            </h1>
            <div className="flex items-center space-x-2">
              <Lock className="h-5 w-5 text-secondary" />
              <span className="text-sm text-gray-400">End-to-End Encrypted</span>
            </div>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search users and cases..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-700 border-gray-600 text-text-primary"
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex">
          {/* Sidebar */}
          <div className="w-80 bg-surface border-r border-gray-600 flex flex-col">
            <div className="p-4">
              <Tabs value={selectedTab} onValueChange={setSelectedTab}>
                <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                  <TabsTrigger 
                    value="users" 
                    className="data-[state=active]:bg-secondary data-[state=active]:text-white"
                    data-testid="tab-users"
                  >
                    Users
                  </TabsTrigger>
                  <TabsTrigger 
                    value="cases" 
                    className="data-[state=active]:bg-secondary data-[state=active]:text-white"
                    data-testid="tab-cases"
                  >
                    Cases
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="users" className="mt-4">
                  <div className="space-y-2" data-testid="users-list">
                    {filteredUsers.length === 0 ? (
                      <div className="text-center py-8 text-gray-400">
                        <Users className="h-8 w-8 mx-auto mb-2" />
                        <p className="text-sm">No users available</p>
                      </div>
                    ) : (
                      filteredUsers.map((user) => (
                        <Card
                          key={user.id}
                          className={`cursor-pointer transition-all ${
                            selectedUser?.id === user.id
                              ? 'bg-secondary/20 border-secondary'
                              : 'bg-gray-700 border-gray-600 hover:bg-gray-600'
                          }`}
                          onClick={() => {
                            setSelectedUser(user);
                            setSelectedCase(null);
                          }}
                          data-testid={`card-user-${user.id}`}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                                  <span className="text-white font-semibold text-sm">
                                    {user.name.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div>
                                  <h3 className="font-medium text-text-primary text-sm" data-testid={`text-user-name-${user.id}`}>
                                    {user.name}
                                  </h3>
                                  <p className="text-xs text-gray-400" data-testid={`text-user-role-${user.id}`}>
                                    {user.role}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge 
                                  className={`text-xs mb-1 ${
                                    user.status === 'available' ? 'bg-success text-white' :
                                    user.status === 'emergency' ? 'bg-destructive text-white' :
                                    user.status === 'en-route' ? 'bg-warning text-black' :
                                    'bg-gray-500 text-white'
                                  }`}
                                  data-testid={`badge-user-status-${user.id}`}
                                >
                                  {user.status.replace('-', ' ').toUpperCase()}
                                </Badge>
                                {user.badge && (
                                  <p className="text-xs text-gray-400" data-testid={`text-user-badge-${user.id}`}>
                                    {user.badge}
                                  </p>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="cases" className="mt-4">
                  <div className="space-y-2" data-testid="cases-list">
                    {filteredCases.length === 0 ? (
                      <div className="text-center py-8 text-gray-400">
                        <FileText className="h-8 w-8 mx-auto mb-2" />
                        <p className="text-sm">No active cases</p>
                      </div>
                    ) : (
                      filteredCases.map((case_) => (
                        <Card
                          key={case_.id}
                          className={`cursor-pointer transition-all ${
                            selectedCase?.id === case_.id
                              ? 'bg-secondary/20 border-secondary'
                              : 'bg-gray-700 border-gray-600 hover:bg-gray-600'
                          }`}
                          onClick={() => {
                            setSelectedCase(case_);
                            setSelectedUser(null);
                          }}
                          data-testid={`card-case-${case_.id}`}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-medium text-text-primary text-sm" data-testid={`text-case-number-${case_.id}`}>
                                {case_.caseNumber}
                              </h3>
                              <Badge className={`text-xs ${
                                case_.priority === 'high' ? 'bg-destructive text-white' :
                                case_.priority === 'medium' ? 'bg-warning text-black' :
                                'bg-success text-white'
                              }`}>
                                {case_.priority.toUpperCase()}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-300 mb-2" data-testid={`text-case-title-${case_.id}`}>
                              {case_.title}
                            </p>
                            <div className="flex items-center text-xs text-gray-400">
                              {case_.location && (
                                <>
                                  <MapPin className="h-3 w-3 mr-1" />
                                  <span data-testid={`text-case-location-${case_.id}`}>{case_.location}</span>
                                </>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Message Panel */}
          <div className="flex-1">
            {!selectedUser && !selectedCase ? (
              <Card className="bg-surface border-gray-600 h-96 m-4">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 text-lg mb-2">Select a contact or case</p>
                    <p className="text-gray-500 text-sm">Choose a user or case to start messaging</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-surface border-gray-600 m-4 h-[calc(100vh-8rem)]" data-testid="card-message-panel">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg text-text-primary">
                      {selectedUser ? (
                        <span data-testid="text-selected-user">{selectedUser.name}</span>
                      ) : (
                        <span data-testid="text-selected-case">{selectedCase?.caseNumber} - {selectedCase?.title}</span>
                      )}
                    </CardTitle>
                    <div className="flex items-center text-sm text-gray-400">
                      <Lock className="h-4 w-4 mr-1" />
                      <span>End-to-End Encrypted</span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Messages Container */}
                  <div className="h-64 overflow-y-auto bg-gray-700 rounded-lg p-4 space-y-3" data-testid="messages-container">
                    {selectedCase && caseMessages.length === 0 && (
                      <div className="text-center py-8">
                        <MessageCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-400 text-sm">No messages yet</p>
                      </div>
                    )}
                    
                    {selectedCase && caseMessages.map((message) => (
                      <div 
                        key={message.id} 
                        className="bg-surface p-3 rounded-lg"
                        data-testid={`message-${message.id}`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <span className="text-sm font-medium text-secondary" data-testid={`text-sender-${message.id}`}>
                            {message.senderId === "mock-user-id" ? "You" : "Team Member"}
                          </span>
                          <span className="text-xs text-gray-400" data-testid={`text-time-${message.id}`}>
                            {new Date(message.createdAt!).toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm text-text-primary" data-testid={`text-content-${message.id}`}>
                          {message.content}
                        </p>
                      </div>
                    ))}
                    
                    {selectedUser && (
                      <div className="text-center py-8">
                        <MessageCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-400 text-sm">Start a conversation with {selectedUser.name}</p>
                      </div>
                    )}
                  </div>

                  {/* PTT Controls */}
                  {isRecording && (
                    <div className="bg-destructive/20 border-2 border-destructive rounded-lg p-4 mb-4 animate-pulse relative overflow-hidden">
                      {/* Animated background pulse */}
                      <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-red-400/20 to-red-500/10 animate-pulse"></div>
                      
                      <div className="flex items-center justify-between relative z-10">
                        <div className="flex items-center space-x-3">
                          <div className="relative">
                            <div className="w-4 h-4 bg-destructive rounded-full animate-pulse"></div>
                            <div className="absolute inset-0 w-4 h-4 bg-red-400 rounded-full animate-ping"></div>
                          </div>
                          <span className="text-destructive font-bold text-sm animate-pulse">🎙️ RECORDING</span>
                          
                          {/* Audio waveform animation */}
                          <div className="flex items-center space-x-1 ml-2">
                            {[1, 2, 3, 4, 5, 6].map((wave) => (
                              <div
                                key={wave}
                                className="w-1 bg-destructive rounded-full animate-bounce"
                                style={{
                                  height: `${8 + Math.sin((Date.now() * 0.01) + wave) * 6}px`,
                                  animationDelay: `${wave * 0.08}s`,
                                  animationDuration: '0.5s'
                                }}
                              />
                            ))}
                          </div>
                          
                          <span className="text-sm text-gray-300 font-mono animate-pulse">
                            {formatTime(recordingTime)}
                          </span>
                        </div>
                        <Button
                          onClick={stopRecording}
                          className="bg-destructive hover:bg-red-700 text-white animate-bounce"
                          size="sm"
                          data-testid="button-stop-recording"
                        >
                          <Square className="h-4 w-4 mr-1" />
                          Stop
                        </Button>
                      </div>
                      
                      {/* Recording level indicator */}
                      <div className="mt-3 relative z-10">
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 h-2 rounded-full transition-all duration-300"
                            style={{ 
                              width: `${Math.min(100, 20 + (recordingTime * 2.5))}%`,
                              animation: 'pulse 0.3s ease-in-out infinite'
                            }}
                          ></div>
                        </div>
                        <div className="flex justify-between text-xs text-gray-400 mt-1">
                          <span>Level</span>
                          <span>Max: 30s</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Voice Message Preview */}
                  {audioBlob && !isRecording && (
                    <div className="bg-success/20 border border-success rounded-lg p-4 mb-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Play className="h-4 w-4 text-success" />
                          <span className="text-success font-medium">Voice message ready</span>
                          <span className="text-sm text-gray-400">({formatTime(recordingTime)})</span>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => setAudioBlob(null)}
                            variant="outline"
                            size="sm"
                            data-testid="button-discard-voice"
                          >
                            Discard
                          </Button>
                          <Button
                            onClick={sendVoiceMessage}
                            disabled={sendMessageMutation.isPending}
                            className="bg-success hover:bg-green-700 text-white"
                            size="sm"
                            data-testid="button-send-voice"
                          >
                            Send
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Message Input */}
                  <div className="flex space-x-2">
                    <Textarea
                      placeholder="Type your secure message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      className="flex-1 bg-gray-700 border-gray-600 text-text-primary resize-none"
                      rows={2}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      data-testid="textarea-message-input"
                      disabled={isRecording}
                    />
                    
                    {/* PTT Button */}
                    <Button
                      onMouseDown={startRecording}
                      onMouseUp={stopRecording}
                      onTouchStart={startRecording}
                      onTouchEnd={stopRecording}
                      disabled={sendMessageMutation.isPending || !!audioBlob}
                      className={`self-end transition-all duration-200 ${
                        isRecording 
                          ? 'bg-destructive hover:bg-red-700 animate-ptt-glow scale-110 shadow-lg shadow-red-500/50' 
                          : 'bg-blue-600 hover:bg-blue-700 hover:scale-105'
                      } text-white min-w-[48px] relative overflow-hidden`}
                      data-testid="button-ptt"
                    >
                      {isRecording && (
                        <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-400 animate-pulse"></div>
                      )}
                      <div className="relative z-10">
                        {isRecording ? (
                          <MicOff className="h-4 w-4 animate-bounce" />
                        ) : (
                          <Mic className="h-4 w-4" />
                        )}
                      </div>
                      {isRecording && (
                        <div className="absolute inset-0 border-2 border-white/30 rounded animate-ping"></div>
                      )}
                    </Button>
                    
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || sendMessageMutation.isPending || isRecording}
                      className="bg-secondary hover:bg-orange-600 text-white self-end"
                      data-testid="button-send-message"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <BottomNavigation currentPath="/messages" />
      </div>
    </div>
  );
}