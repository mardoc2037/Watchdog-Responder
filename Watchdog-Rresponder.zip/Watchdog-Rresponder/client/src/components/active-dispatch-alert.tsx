import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";
import { useLocation } from "wouter";
import type { Case } from "@shared/schema";

export default function ActiveDispatchAlert() {
  const [, setLocation] = useLocation();
  const [isDismissed, setIsDismissed] = useState(false);

  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  // Show alert only for high priority cases
  const highPriorityCases = activeCases.filter(case_ => case_.priority === 'high');
  const activeDispatch = highPriorityCases[0]; // Show the first high priority case

  const handleRespond = () => {
    if (activeDispatch) {
      // Navigate to cases page to view case details
      setLocation('/cases');
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
  };

  // Don't show if dismissed or no high priority cases
  if (isDismissed || !activeDispatch) {
    return null;
  }

  return (
    <div className="bg-secondary px-4 py-3 shadow-md relative" data-testid="alert-active-dispatch">
      <div className="flex items-center space-x-3">
        <AlertTriangle className="h-5 w-5 text-white flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-white" data-testid="text-dispatch-title">
            ACTIVE DISPATCH
          </p>
          <p className="text-orange-100 text-sm truncate" data-testid="text-dispatch-details">
            {activeDispatch.title} - {activeDispatch.lastSeenLocation || 'Location TBD'}
          </p>
        </div>
        <div className="flex items-center space-x-2 flex-shrink-0">
          <Button
            onClick={handleRespond}
            className="bg-white text-secondary px-3 py-1 rounded font-medium text-sm hover:bg-gray-100 transition-colors"
            data-testid="button-respond-dispatch"
          >
            RESPOND
          </Button>
          <Button
            onClick={handleDismiss}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-orange-600 p-1"
            data-testid="button-dismiss-alert"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
