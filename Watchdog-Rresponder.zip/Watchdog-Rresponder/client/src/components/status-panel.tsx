import { useState, useEffect, useRef } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Radio, X, Navigation, MapPin } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Case } from "@shared/schema";

// Declare Google Maps types
declare global {
  interface Window {
    google: any;
  }
}

interface StatusPanelProps {
  currentStatus: string;
  onStatusChange: (status: string) => void;
}

export default function StatusPanel({ currentStatus, onStatusChange }: StatusPanelProps) {
  const [showModal, setShowModal] = useState(false);
  const [showNavigationModal, setShowNavigationModal] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedCall, setSelectedCall] = useState<Case | null>(null);
  const [showRoute, setShowRoute] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const routeMapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const routeMapInstanceRef = useRef<any>(null);
  const directionsService = useRef<any>(null);
  const directionsRenderer = useRef<any>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get active cases for navigation
  const { data: activeCases = [] } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ status, lat, lng }: { status: string; lat?: number; lng?: number }) => {
      const response = await apiRequest("POST", "/api/user/status", { status, lat, lng });
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Status update successful:', data);
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/active"] });
      toast({
        title: "Status Updated",
        description: `Status changed to ${selectedStatus.replace('_', ' ')}`,
      });
    },
    onError: (error) => {
      console.error('Status update error:', error);
      toast({
        title: "Error",
        description: "Failed to update status - please try again",
        variant: "destructive",
      });
    },
  });

  const statusOptions = [
    {
      id: "available",
      label: "Available",
      description: "Ready for dispatch",
      color: "bg-success",
      hoverColor: "hover:border-success",
    },
    {
      id: "enroute",
      label: "En Route",
      description: "Traveling to scene",
      color: "bg-warning",
      hoverColor: "hover:border-warning",
    },
    {
      id: "virtual",
      label: "Virtual",
      description: "Remote assistance",
      color: "bg-blue-500",
      hoverColor: "hover:border-blue-500",
    },
    {
      id: "onscene",
      label: "On Scene",
      description: "Arrived at location",
      color: "bg-purple-500",
      hoverColor: "hover:border-purple-500",
    },
  ];

  const handleStatusClick = (status: string) => {
    setSelectedStatus(status);
    setShowModal(true);
  };

  const handleConfirmStatus = () => {
    // Check if this is enroute or onscene status and we have active cases
    if ((selectedStatus === 'enroute' || selectedStatus === 'onscene') && activeCases.length > 0) {
      const availableCases = activeCases.filter(c => c.lastSeenLat && c.lastSeenLng);
      
      if (availableCases.length > 0) {
        // Pre-select the highest priority case but let user choose
        const highPriorityCase = availableCases
          .sort((a, b) => {
            const priorityOrder = { 'high': 3, 'medium': 2, 'low': 1 };
            return priorityOrder[b.priority] - priorityOrder[a.priority];
          })[0];
        
        setSelectedCall(highPriorityCase);
        setShowNavigationModal(true);
        return;
      }
    }

    // Normal status update process
    performStatusUpdate();
  };

  const performStatusUpdate = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          updateStatusMutation.mutate({
            status: selectedStatus,
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          // If location fails, update status without location
          updateStatusMutation.mutate({ status: selectedStatus });
        }
      );
    } else {
      updateStatusMutation.mutate({ status: selectedStatus });
    }
    
    onStatusChange(selectedStatus);
    setShowModal(false);
    setShowNavigationModal(false);
  };

  const handleSelectCall = (call: Case) => {
    setSelectedCall(call);
    setShowRoute(false); // Reset route view when switching calls
  };

  const handleShowRoute = () => {
    if (selectedCall) {
      setShowRoute(true);
      // Will trigger route rendering in useEffect
    }
  };

  const handleNavigateToCall = () => {
    if (selectedCall) {
      // Start in-app navigation (prepare for scanner integration)
      toast({
        title: "In-App Navigation Started",
        description: `Navigating to ${selectedCall.title}`,
      });
      
      // Complete the status update
      performStatusUpdate();
      
      // Future: This will integrate with scanner and real-time updates
      console.log('Starting in-app navigation to:', selectedCall.title);
    }
  };

  const handleSkipNavigation = () => {
    // Just complete the status update without navigation
    performStatusUpdate();
  };

  // Initialize preview map when navigation modal opens with selected call
  useEffect(() => {
    if (showNavigationModal && selectedCall && selectedCall.lastSeenLat && selectedCall.lastSeenLng && mapRef.current && window.google) {
      const lat = parseFloat(selectedCall.lastSeenLat);
      const lng = parseFloat(selectedCall.lastSeenLng);
      
      const map = new window.google.maps.Map(mapRef.current, {
        center: { lat, lng },
        zoom: 15,
        styles: [
          {
            "elementType": "geometry",
            "stylers": [{"color": "#212121"}]
          },
          {
            "elementType": "labels.text.fill",
            "stylers": [{"color": "#757575"}]
          },
          {
            "elementType": "labels.text.stroke",
            "stylers": [{"color": "#212121"}]
          },
          {
            "featureType": "road",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#2c2c2c"}]
          },
          {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}]
          }
        ]
      });

      // Add marker for selected call location
      new window.google.maps.Marker({
        position: { lat, lng },
        map: map,
        title: selectedCall.title,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22S19 14.25 19 9C19 5.13 15.87 2 12 2ZM12 11.5C10.62 11.5 9.5 10.38 9.5 9S10.62 6.5 12 6.5S14.5 7.62 14.5 9S13.38 11.5 12 11.5Z" fill="#ef4444"/>
            </svg>
          `),
          scaledSize: new window.google.maps.Size(32, 32)
        }
      });

      mapInstanceRef.current = map;
    }
  }, [showNavigationModal, selectedCall]);

  // Initialize route map with directions when showing route
  useEffect(() => {
    if (showRoute && selectedCall && selectedCall.lastSeenLat && selectedCall.lastSeenLng && routeMapRef.current && window.google) {
      const lat = parseFloat(selectedCall.lastSeenLat);
      const lng = parseFloat(selectedCall.lastSeenLng);
      
      const map = new window.google.maps.Map(routeMapRef.current, {
        center: { lat: 43.2187, lng: -86.298 }, // Muskegon center
        zoom: 12,
        styles: [
          {
            "elementType": "geometry",
            "stylers": [{"color": "#212121"}]
          },
          {
            "elementType": "labels.text.fill",
            "stylers": [{"color": "#757575"}]
          },
          {
            "elementType": "labels.text.stroke",
            "stylers": [{"color": "#212121"}]
          },
          {
            "featureType": "road",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#2c2c2c"}]
          },
          {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}]
          }
        ]
      });

      // Initialize directions service and renderer
      directionsService.current = new window.google.maps.DirectionsService();
      directionsRenderer.current = new window.google.maps.DirectionsRenderer({
        suppressMarkers: false,
        polylineOptions: {
          strokeColor: '#ef4444',
          strokeWeight: 4,
          strokeOpacity: 0.8
        }
      });
      directionsRenderer.current.setMap(map);

      // Get current location and calculate route
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const request = {
              origin: { lat: position.coords.latitude, lng: position.coords.longitude },
              destination: { lat, lng },
              travelMode: window.google.maps.TravelMode.DRIVING,
            };

            directionsService.current.route(request, (result: any, status: any) => {
              if (status === 'OK') {
                directionsRenderer.current.setDirections(result);
              } else {
                console.error('Directions request failed:', status);
              }
            });
          },
          (error) => {
            console.error('Geolocation error:', error);
            // Fallback to default location
            const request = {
              origin: { lat: 43.2187, lng: -86.298 },
              destination: { lat, lng },
              travelMode: window.google.maps.TravelMode.DRIVING,
            };

            directionsService.current.route(request, (result: any, status: any) => {
              if (status === 'OK') {
                directionsRenderer.current.setDirections(result);
              }
            });
          }
        );
      }

      routeMapInstanceRef.current = map;
    }
  }, [showRoute, selectedCall]);

  const handleUnavailable = () => {
    setSelectedStatus("unavailable");
    setShowModal(true);
  };

  return (
    <section className="p-4">
      <Card className="bg-surface border-gray-600" data-testid="card-status-panel">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold text-text-primary flex items-center">
            <Radio className="h-5 w-5 mr-2 text-secondary" />
            Response Status
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3 mb-4">
            {statusOptions.map((option) => (
              <Button
                key={option.id}
                onClick={() => handleStatusClick(option.id)}
                className={`h-auto p-4 text-left transition-all bg-gray-700 hover:bg-gray-600 border-2 border-transparent ${option.hoverColor} text-text-primary`}
                variant="ghost"
                data-testid={`button-status-${option.id}`}
              >
                <div className="flex items-center space-x-3 w-full">
                  <div className={`w-4 h-4 ${option.color} rounded-full flex-shrink-0`}></div>
                  <div className="flex-1">
                    <p className="font-medium">{option.label}</p>
                    <p className="text-xs text-gray-400">{option.description}</p>
                  </div>
                </div>
              </Button>
            ))}
          </div>
          
          <Button
            onClick={handleUnavailable}
            className="w-full bg-destructive hover:bg-red-600 p-4 font-medium text-white"
            data-testid="button-status-unavailable"
          >
            <X className="h-4 w-4 mr-2" />
            Mark Unavailable
          </Button>
        </CardContent>
      </Card>

      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="bg-surface border-gray-600 text-text-primary" data-testid="dialog-status-confirm">
          <DialogHeader>
            <DialogTitle>Update Status</DialogTitle>
            <DialogDescription className="text-gray-300">
              Are you sure you want to change your status to{" "}
              <span className="font-medium text-secondary">
                {selectedStatus.replace('_', ' ')}
              </span>
              ?
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter className="flex space-x-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="bg-gray-600 hover:bg-gray-500 border-gray-600 text-text-primary"
              data-testid="button-cancel-status"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmStatus}
              disabled={updateStatusMutation.isPending}
              className="bg-secondary hover:bg-orange-600 text-white"
              data-testid="button-confirm-status"
            >
              {updateStatusMutation.isPending ? "Updating..." : "Confirm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Navigation Prompt Modal */}
      <Dialog open={showNavigationModal} onOpenChange={setShowNavigationModal}>
        <DialogContent className="bg-surface border-gray-600 max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-navigation-prompt">
          <DialogHeader>
            <DialogTitle className="text-text-primary flex items-center">
              <Navigation className="h-5 w-5 mr-2 text-secondary" />
              Select Call for Navigation
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Choose from recent active calls and view the route
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Call Selection List */}
            <div className="bg-gray-700 rounded-lg p-3">
              <p className="text-sm font-medium text-text-primary mb-3">Recent Active Calls (Last 5)</p>
              <div className="space-y-2">
                {activeCases
                  .filter(c => c.lastSeenLat && c.lastSeenLng)
                  .slice(0, 5)
                  .map((call) => (
                    <div
                      key={call.id}
                      onClick={() => handleSelectCall(call)}
                      className={`p-3 rounded border cursor-pointer transition-all ${
                        selectedCall?.id === call.id
                          ? 'bg-secondary border-secondary text-white'
                          : 'bg-gray-800 border-gray-600 text-gray-300 hover:border-gray-500'
                      }`}
                      data-testid={`call-option-${call.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{call.caseNumber}</p>
                          <p className="text-sm opacity-80">{call.title}</p>
                          <p className="text-xs opacity-60">{call.lastSeenLocation}</p>
                        </div>
                        <div className="text-right">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            call.priority === 'high' ? 'bg-red-600 text-white' :
                            call.priority === 'medium' ? 'bg-orange-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}>
                            {call.priority.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {selectedCall && (
              <div className="space-y-4">
                {/* Selected Call Preview Map */}
                <div className="bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-text-primary">Call Location Preview</p>
                    <Button
                      onClick={handleShowRoute}
                      size="sm"
                      variant="outline"
                      className="border-gray-600 text-gray-300 text-xs"
                      data-testid="button-show-route"
                    >
                      Show Route
                    </Button>
                  </div>
                  <div 
                    ref={mapRef} 
                    className="w-full h-32 rounded border border-gray-600 bg-gray-800 mb-2"
                    data-testid="navigation-preview-map"
                  />
                  <div className="text-xs text-gray-400">
                    {parseFloat(selectedCall.lastSeenLat!).toFixed(6)}, {parseFloat(selectedCall.lastSeenLng!).toFixed(6)}
                  </div>
                </div>

                {/* Full Route View */}
                {showRoute && (
                  <div className="bg-gray-700 rounded-lg p-3">
                    <p className="text-sm font-medium text-text-primary mb-2">Navigation Route</p>
                    <div 
                      ref={routeMapRef} 
                      className="w-full h-64 rounded border border-gray-600 bg-gray-800"
                      data-testid="navigation-route-map"
                    />
                    <p className="text-xs text-gray-400 mt-2">
                      Route calculated from your current location to {selectedCall.title}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <DialogFooter className="gap-2 mt-4">
            <Button
              onClick={handleSkipNavigation}
              variant="outline"
              className="border-gray-600 text-gray-300"
              data-testid="button-skip-navigation"
            >
              Skip Navigation
            </Button>
            <Button
              onClick={handleNavigateToCall}
              disabled={!selectedCall}
              className="bg-secondary text-white disabled:opacity-50"
              data-testid="button-navigate-call"
            >
              <Navigation className="h-4 w-4 mr-2" />
              Start Navigation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
