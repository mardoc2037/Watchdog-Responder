import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Mic, MicOff, Volume2, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface VoiceEmergencyToggleProps {
  onEmergencyModeChange: (isActive: boolean) => void;
  isEmergencyMode: boolean;
}

export default function VoiceEmergencyToggle({ 
  onEmergencyModeChange, 
  isEmergencyMode 
}: VoiceEmergencyToggleProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [lastCommand, setLastCommand] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(0);
  
  const recognitionRef = useRef<any>(null);
  const { toast } = useToast();
  const { sendMessage } = useWebSocket();

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/profile"],
  });

  // Emergency activation phrases
  const emergencyTriggers = [
    "activate emergency mode",
    "emergency mode on",
    "start emergency",
    "emergency activation",
    "code red activate",
    "emergency protocol",
    "activate emergency",
    "emergency mode activate"
  ];

  // SOS activation phrases - for priority messages to all users
  const sosTriggers = [
    "send sos",
    "sos message",
    "need assistance",
    "request backup",
    "emergency assistance",
    "help needed",
    "priority sos",
    "assistance required",
    "backup needed",
    "emergency help"
  ];

  // Emergency deactivation phrases
  const deactivationTriggers = [
    "deactivate emergency mode",
    "emergency mode off",
    "stop emergency",
    "emergency deactivation",
    "code green",
    "all clear",
    "deactivate emergency",
    "emergency mode deactivate",
    "cancel emergency"
  ];

  useEffect(() => {
    // Check for Web Speech API support
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      setIsSupported(true);
      
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;
      
      recognition.onstart = () => {
        console.log('Voice recognition started');
        setIsListening(true);
      };

      recognition.onend = () => {
        console.log('Voice recognition ended');
        setIsListening(false);
        
        // Auto-restart if voice is enabled and not in emergency mode
        if (voiceEnabled && !isEmergencyMode) {
          setTimeout(() => {
            if (voiceEnabled && recognitionRef.current) {
              try {
                recognitionRef.current.start();
              } catch (error) {
                console.log('Recognition restart failed:', error);
              }
            }
          }, 1000);
        }
      };

      recognition.onerror = (event: any) => {
        console.error('Voice recognition error:', event.error);
        setIsListening(false);
        
        if (event.error === 'not-allowed') {
          toast({
            title: "Microphone Access Denied",
            description: "Please allow microphone access for voice commands",
            variant: "destructive",
          });
          setVoiceEnabled(false);
        }
      };

      recognition.onresult = (event: any) => {
        const result = event.results[event.results.length - 1];
        const transcript = result[0].transcript.toLowerCase().trim();
        const conf = result[0].confidence;
        
        console.log('Voice command detected:', transcript, 'Confidence:', conf);
        setLastCommand(transcript);
        setConfidence(conf);
        
        // Check for emergency activation
        const isEmergencyTrigger = emergencyTriggers.some(trigger => 
          transcript.includes(trigger)
        );
        
        // Check for SOS activation
        const isSOSTrigger = sosTriggers.some(trigger => 
          transcript.includes(trigger)
        );
        
        // Check for emergency deactivation
        const isDeactivationTrigger = deactivationTriggers.some(trigger => 
          transcript.includes(trigger)
        );
        
        if (isSOSTrigger && conf > 0.6) {
          console.log('SOS message triggered by voice');
          sendSOSMessage();
          setLastCommand(`🚨 SOS: ${transcript}`);
          
          toast({
            title: "SOS Message Sent",
            description: "Priority assistance request sent to all users",
            variant: "destructive",
          });
          
          // Play SOS confirmation sound
          playSOSSound();
          
        } else if (isEmergencyTrigger && !isEmergencyMode && conf > 0.6) {
          console.log('Emergency mode activation triggered by voice');
          onEmergencyModeChange(true);
          setLastCommand(`✓ ${transcript}`);
          
          toast({
            title: "Emergency Mode Activated",
            description: "Voice command recognized - Emergency protocols engaged",
            variant: "destructive",
          });
          
          // Play confirmation sound
          playConfirmationSound(true);
          
        } else if (isDeactivationTrigger && isEmergencyMode && conf > 0.6) {
          console.log('Emergency mode deactivation triggered by voice');
          onEmergencyModeChange(false);
          setLastCommand(`✓ ${transcript}`);
          
          toast({
            title: "Emergency Mode Deactivated",
            description: "Voice command recognized - Normal operations resumed",
          });
          
          // Play confirmation sound
          playConfirmationSound(false);
        }
      };

      recognitionRef.current = recognition;
    } else {
      setIsSupported(false);
      console.log('Web Speech API not supported');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [voiceEnabled, isEmergencyMode, onEmergencyModeChange, toast]);

  const playConfirmationSound = (isActivation: boolean) => {
    // Create audio context for confirmation beeps
    if ('AudioContext' in window || 'webkitAudioContext' in window) {
      const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContext();
      
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Different tones for activation vs deactivation
      oscillator.frequency.setValueAtTime(isActivation ? 880 : 440, audioContext.currentTime);
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    }
  };

  const playSOSSound = () => {
    // Create urgent SOS audio pattern
    if ('AudioContext' in window || 'webkitAudioContext' in window) {
      const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContext();
      
      // SOS pattern: 3 short, 3 long, 3 short
      const pattern = [200, 100, 200, 100, 200, 300, 800, 100, 800, 100, 800, 300, 200, 100, 200, 100, 200];
      let currentTime = audioContext.currentTime;
      
      pattern.forEach((duration, index) => {
        if (index % 2 === 0) { // Sound
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          oscillator.frequency.setValueAtTime(800, currentTime);
          oscillator.type = 'sine';
          
          gainNode.gain.setValueAtTime(0.5, currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, currentTime + duration / 1000);
          
          oscillator.start(currentTime);
          oscillator.stop(currentTime + duration / 1000);
        }
        currentTime += duration / 1000;
      });
    }
  };

  const sendSOSMessage = async () => {
    if (!user) return;

    try {
      // Create priority SOS message
      const sosMessage = {
        content: `🚨 PRIORITY SOS: ${user.name} (${user.role.toUpperCase()}) requires immediate assistance. Location tracking active. Please respond with status and ETA.`,
        messageType: 'priority_sos',
      };

      // Send to all users via API  
      const response = await fetch('/api/messages/broadcast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sosMessage),
      });
      
      if (!response.ok) {
        throw new Error('Failed to broadcast SOS message');
      }

      // Also send via WebSocket for immediate delivery
      sendMessage({
        type: 'priority_sos',
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        message: sosMessage.content,
        priority: 'CRITICAL',
        timestamp: new Date().toISOString(),
      });

      console.log('🚨 SOS message sent to all users');
      
    } catch (error) {
      console.error('Failed to send SOS message:', error);
      toast({
        title: "SOS Send Failed",
        description: "Could not send SOS message. Please try manual alert.",
        variant: "destructive",
      });
    }
  };

  const toggleVoiceRecognition = async () => {
    if (!isSupported) {
      toast({
        title: "Voice Recognition Unavailable",
        description: "Your browser doesn't support voice recognition",
        variant: "destructive",
      });
      return;
    }

    if (!voiceEnabled) {
      try {
        // Request microphone permission
        await navigator.mediaDevices.getUserMedia({ audio: true });
        setVoiceEnabled(true);
        recognitionRef.current?.start();
        
        toast({
          title: "Voice Commands Enabled",
          description: "Listening for emergency activation commands",
        });
      } catch (error) {
        toast({
          title: "Microphone Access Required",
          description: "Please allow microphone access for voice commands",
          variant: "destructive",
        });
      }
    } else {
      setVoiceEnabled(false);
      recognitionRef.current?.stop();
      setIsListening(false);
      
      toast({
        title: "Voice Commands Disabled",
        description: "Voice recognition stopped",
      });
    }
  };

  if (!isSupported) {
    return (
      <Card className="bg-surface border-gray-600" data-testid="card-voice-unavailable">
        <CardContent className="p-4">
          <div className="flex items-center text-gray-400">
            <MicOff className="h-4 w-4 mr-2" />
            <span className="text-sm">Voice commands not supported in this browser</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface border-gray-600" data-testid="card-voice-emergency">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-text-primary flex items-center justify-between">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-secondary" />
            Voice Emergency Control
          </div>
          <Badge 
            className={`${
              voiceEnabled && isListening ? 'bg-success animate-pulse' : 
              voiceEnabled ? 'bg-blue-600' : 'bg-gray-500'
            } text-white`}
          >
            {voiceEnabled ? (isListening ? 'LISTENING' : 'READY') : 'DISABLED'}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Voice Control Toggle */}
        <div className="flex items-center justify-between">
          <Button
            onClick={toggleVoiceRecognition}
            className={`${
              voiceEnabled 
                ? 'bg-success hover:bg-green-700' 
                : 'bg-gray-600 hover:bg-gray-500'
            } text-white`}
            data-testid="button-toggle-voice"
          >
            {voiceEnabled ? (
              <>
                <Mic className="h-4 w-4 mr-2" />
                Voice Active
              </>
            ) : (
              <>
                <MicOff className="h-4 w-4 mr-2" />
                Enable Voice
              </>
            )}
          </Button>
          
          {isListening && (
            <div className="flex items-center text-success">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse mr-2"></div>
              <span className="text-sm">Listening...</span>
            </div>
          )}
        </div>

        {/* Last Command Display */}
        {lastCommand && (
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">Last Command:</div>
            <div className="text-sm font-mono">{lastCommand}</div>
            <div className="text-xs text-gray-400 mt-1">
              Confidence: {Math.round(confidence * 100)}%
            </div>
          </div>
        )}

        {/* Emergency Status */}
        <div className={`p-3 rounded-lg border-2 ${
          isEmergencyMode 
            ? 'bg-destructive/20 border-destructive animate-pulse' 
            : 'bg-gray-700 border-gray-600'
        }`}>
          <div className="flex items-center justify-between">
            <span className="font-medium">
              {isEmergencyMode ? 'EMERGENCY MODE ACTIVE' : 'Normal Operations'}
            </span>
            {isEmergencyMode && (
              <AlertTriangle className="h-5 w-5 text-destructive" />
            )}
          </div>
        </div>

        {/* Voice Commands Help */}
        <div className="text-xs text-gray-400 p-3 bg-gray-700 rounded-lg">
          <p className="mb-2"><strong>Emergency Mode Commands:</strong></p>
          <p className="mb-1">• "Activate emergency mode"</p>
          <p className="mb-1">• "Emergency activation"</p>
          <p className="mb-1">• "Code red activate"</p>
          
          <p className="mb-2 mt-3"><strong>SOS Commands:</strong></p>
          <p className="mb-1">• "Send SOS"</p>
          <p className="mb-1">• "Need assistance"</p>
          <p className="mb-1">• "Request backup"</p>
          
          <p className="mb-2 mt-3"><strong>Deactivation Commands:</strong></p>
          <p className="mb-1">• "Deactivate emergency mode"</p>
          <p className="mb-1">• "All clear"</p>
          <p>• "Code green"</p>
        </div>
      </CardContent>
    </Card>
  );
}