import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FolderOpen, Plus, MapPin, Clock, Navigation } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import type { Case } from "@shared/schema";

export default function ActiveCases() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { data: activeCases = [], isLoading } = useQuery<Case[]>({
    queryKey: ["/api/cases/active"],
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-secondary text-white';
      case 'medium':
        return 'bg-warning text-black';
      case 'low':
        return 'bg-success text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getPriorityBorderColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-secondary';
      case 'medium':
        return 'border-l-warning';
      case 'low':
        return 'border-l-success';
      default:
        return 'border-l-gray-500';
    }
  };

  const getTimeAgo = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffHours = Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) {
      return 'Less than 1 hour ago';
    } else if (diffHours === 1) {
      return '1 hour ago';
    } else {
      return `${diffHours} hours ago`;
    }
  };

  const handleViewCase = (caseId: string) => {
    // Navigate to cases page with case details
    setLocation('/cases');
  };

  const handleUpdateCase = (caseId: string) => {
    // Navigate to cases page for updating
    setLocation('/cases');
  };

  const handleCreateCase = () => {
    // Navigate to cases page for creating new case
    setLocation('/cases');
  };

  const handleGetDirections = (case_: Case) => {
    if (case_.lastSeenLat && case_.lastSeenLng) {
      // Navigate to cases page which will show the navigation modal
      setLocation('/cases');
      
      toast({
        title: "Navigate to Cases",
        description: "Use the directions button in case management for in-app navigation",
      });
    } else {
      toast({
        title: "No Location Available",
        description: "This case doesn't have GPS coordinates for navigation",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <section className="px-4 mb-6">
        <Card className="bg-surface border-gray-600">
          <CardContent className="p-4">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-secondary"></div>
              <span className="ml-2 text-gray-400">Loading active cases...</span>
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="px-4 mb-6">
      <Card className="bg-surface border-gray-600" data-testid="card-active-cases">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-semibold flex items-center text-text-primary">
              <FolderOpen className="h-5 w-5 mr-2 text-secondary" />
              Active Cases
            </CardTitle>
            <Button
              onClick={handleCreateCase}
              variant="ghost"
              size="sm"
              className="text-secondary hover:text-orange-400 transition-colors p-1"
              data-testid="button-create-case"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          {activeCases.length === 0 ? (
            <div className="text-center py-8">
              <FolderOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No active cases</p>
              <Button
                onClick={handleCreateCase}
                className="mt-4 bg-secondary hover:bg-orange-600 text-white"
                data-testid="button-create-first-case"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create First Case
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {activeCases.map((case_) => (
                <div 
                  key={case_.id}
                  className={`bg-gray-700 p-4 rounded-lg border-l-4 ${getPriorityBorderColor(case_.priority)} transition-colors hover:bg-gray-600`}
                  data-testid={`case-${case_.id}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-medium text-text-primary" data-testid={`case-number-${case_.id}`}>
                        {case_.caseNumber}
                      </h4>
                      <p className="text-sm text-gray-400" data-testid={`case-title-${case_.id}`}>
                        {case_.title}
                      </p>
                    </div>
                    <Badge 
                      className={getPriorityColor(case_.priority)}
                      data-testid={`case-priority-${case_.id}`}
                    >
                      {case_.priority.toUpperCase()}
                    </Badge>
                  </div>
                  
                  {case_.description && (
                    <p className="text-sm text-gray-300 mb-3" data-testid={`case-description-${case_.id}`}>
                      {case_.description}
                    </p>
                  )}
                  
                  {case_.lastSeenLocation && (
                    <div className="flex items-center text-sm text-gray-400 mb-2">
                      <MapPin className="h-4 w-4 mr-2 text-secondary" />
                      <span data-testid={`case-location-${case_.id}`}>
                        Last seen: {case_.lastSeenLocation}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center text-sm text-gray-400 mb-3">
                    <Clock className="h-4 w-4 mr-2" />
                    <span data-testid={`case-time-${case_.id}`}>
                      {case_.createdAt ? getTimeAgo(case_.createdAt.toString()) : 'Unknown'}
                    </span>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      onClick={() => handleViewCase(case_.id)}
                      size="sm" 
                      className="bg-primary hover:bg-blue-700 text-white text-xs"
                      data-testid={`button-view-case-${case_.id}`}
                    >
                      View Details
                    </Button>
                    <Button 
                      onClick={() => handleUpdateCase(case_.id)}
                      size="sm" 
                      className="bg-warning hover:bg-yellow-600 text-black text-xs"
                      data-testid={`button-update-case-${case_.id}`}
                    >
                      Update
                    </Button>
                    {case_.lastSeenLat && case_.lastSeenLng && (
                      <Button 
                        onClick={() => handleGetDirections(case_)}
                        size="sm" 
                        variant="outline" 
                        className="border-secondary text-secondary hover:bg-secondary hover:text-white text-xs"
                        data-testid={`button-directions-case-${case_.id}`}
                      >
                        <Navigation className="h-3 w-3 mr-1" />
                        Directions
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
