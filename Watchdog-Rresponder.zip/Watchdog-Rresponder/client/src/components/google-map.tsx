import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Navigation, Users, AlertTriangle } from 'lucide-react';

interface MapLocation {
  lat: number;
  lng: number;
  title?: string;
  description?: string;
  type?: 'user' | 'case' | 'incident' | 'landmark';
  status?: 'available' | 'unavailable' | 'emergency' | 'en-route' | 'on-scene';
}

interface GoogleMapProps {
  center?: MapLocation;
  locations?: MapLocation[];
  zoom?: number;
  height?: string;
  showCurrentLocation?: boolean;
  onLocationClick?: (location: MapLocation) => void;
}

declare global {
  interface Window {
    google: any;
    initMap: () => void;
  }
}

export default function GoogleMap({
  center = { lat: 43.2187, lng: -86.298 }, // Muskegon, MI default
  locations = [],
  zoom = 12,
  height = '400px',
  showCurrentLocation = true,
  onLocationClick
}: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [userLocation, setUserLocation] = useState<MapLocation | null>(null);

  // Initialize map when Google Maps is loaded
  useEffect(() => {
    const initializeMap = () => {
      if (window.google && window.google.maps && mapRef.current) {
        const map = new window.google.maps.Map(mapRef.current, {
          center,
          zoom,
          styles: [
            // Dark theme for emergency response
            {
              "elementType": "geometry",
              "stylers": [{"color": "#212121"}]
            },
            {
              "elementType": "labels.icon",
              "stylers": [{"visibility": "off"}]
            },
            {
              "elementType": "labels.text.fill",
              "stylers": [{"color": "#757575"}]
            },
            {
              "elementType": "labels.text.stroke",
              "stylers": [{"color": "#212121"}]
            },
            {
              "featureType": "administrative",
              "elementType": "geometry",
              "stylers": [{"color": "#757575"}]
            },
            {
              "featureType": "road",
              "elementType": "geometry.fill",
              "stylers": [{"color": "#2c2c2c"}]
            },
            {
              "featureType": "water",
              "elementType": "geometry",
              "stylers": [{"color": "#000000"}]
            }
          ],
          mapTypeControl: true,
          streetViewControl: true,
          fullscreenControl: true,
          zoomControl: true,
        });

        mapInstanceRef.current = map;
        setIsLoaded(true);
      }
    };

    // Check if Google Maps is already loaded
    if (window.google && window.google.maps) {
      initializeMap();
    } else {
      // Wait for Google Maps to load
      const checkGoogleMaps = setInterval(() => {
        if (window.google && window.google.maps) {
          clearInterval(checkGoogleMaps);
          initializeMap();
        }
      }, 100);

      return () => clearInterval(checkGoogleMaps);
    }
  }, [center.lat, center.lng, zoom]);

  // Get user's current location
  useEffect(() => {
    if (showCurrentLocation && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location: MapLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            title: "Your Location",
            type: "user",
            status: "available"
          };
          setUserLocation(location);
        },
        (error) => {
          console.log("Location access denied or unavailable");
        }
      );
    }
  }, [showCurrentLocation]);

  // Add markers to map
  useEffect(() => {
    if (!mapInstanceRef.current || !isLoaded) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add location markers
    [...locations, ...(userLocation ? [userLocation] : [])].forEach((location) => {
      const marker = new window.google.maps.Marker({
        position: { lat: location.lat, lng: location.lng },
        map: mapInstanceRef.current,
        title: location.title,
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          fillColor: getMarkerColor(location),
          fillOpacity: 0.8,
          strokeColor: '#ffffff',
          strokeWeight: 2,
          scale: location.type === 'user' && location.title === 'Your Location' ? 8 : 6,
        }
      });

      // Add info window
      const infoWindow = new window.google.maps.InfoWindow({
        content: `
          <div style="color: #333; font-family: Arial, sans-serif;">
            <h3 style="margin: 0 0 8px 0; color: #333;">${location.title || 'Location'}</h3>
            ${location.description ? `<p style="margin: 0 0 8px 0;">${location.description}</p>` : ''}
            ${location.status ? `<span style="background: ${getStatusColor(location.status)}; color: white; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${location.status.toUpperCase()}</span>` : ''}
          </div>
        `
      });

      marker.addListener('click', () => {
        infoWindow.open(mapInstanceRef.current, marker);
        if (onLocationClick) {
          onLocationClick(location);
        }
      });

      markersRef.current.push(marker);
    });
  }, [locations, userLocation, isLoaded, onLocationClick]);

  const getMarkerColor = (location: MapLocation): string => {
    if (location.type === 'user' && location.title === 'Your Location') {
      return '#3b82f6'; // Blue for current user
    }
    
    switch (location.status) {
      case 'available': return '#22c55e'; // Green
      case 'emergency': return '#ef4444'; // Red
      case 'enroute': return '#f59e0b'; // Orange - matching status panel
      case 'onscene': return '#8b5cf6'; // Purple - matching status panel
      case 'unavailable': return '#6b7280'; // Gray
      default:
        switch (location.type) {
          case 'incident': return '#ef4444'; // Red
          case 'case': return '#f59e0b'; // Orange
          case 'landmark': return '#6b7280'; // Gray
          default: return '#22c55e'; // Green
        }
    }
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'available': return '#22c55e';
      case 'emergency': return '#ef4444';
      case 'enroute': return '#f59e0b'; // Fixed to match status panel
      case 'onscene': return '#8b5cf6'; // Fixed to match status panel
      case 'unavailable': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const centerOnUserLocation = () => {
    if (userLocation && mapInstanceRef.current) {
      mapInstanceRef.current.setCenter({ lat: userLocation.lat, lng: userLocation.lng });
      mapInstanceRef.current.setZoom(15);
    }
  };

  return (
    <div className="w-full">
      <div 
        ref={mapRef} 
        style={{ height, width: '100%' }} 
        className="rounded-lg border border-gray-600 bg-gray-800"
        data-testid="google-map"
      />
      
      {/* Map Controls */}
      <div className="flex justify-between items-center mt-2">
        <div className="flex space-x-2">
          {userLocation && (
            <Button
              onClick={centerOnUserLocation}
              variant="outline"
              size="sm"
              className="border-gray-600 text-gray-300"
              data-testid="button-center-location"
            >
              <Navigation className="w-4 h-4 mr-1" />
              My Location
            </Button>
          )}
        </div>
        
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <MapPin className="w-4 h-4" />
          <span>{locations.length} locations</span>
        </div>
      </div>

      {/* Status Legend */}
      {locations.some(loc => loc.status) && (
        <Card className="mt-4 bg-gray-800 border-gray-600">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-300">Status Legend</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-2">
              {['available', 'enroute', 'onscene', 'emergency', 'unavailable'].map(status => {
                const hasStatus = locations.some(loc => loc.status === status);
                if (!hasStatus) return null;
                
                const statusLabel = status === 'enroute' ? 'En Route' : 
                                   status === 'onscene' ? 'On Scene' : 
                                   status.charAt(0).toUpperCase() + status.slice(1);
                
                return (
                  <div key={status} className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: getMarkerColor({ status } as MapLocation) }}
                    />
                    <span className="text-xs text-gray-400">
                      {statusLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}