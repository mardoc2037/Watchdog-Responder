import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";
import type { User } from "@shared/schema";

export default function TeamStatus() {
  const [, setLocation] = useLocation();
  const { data: activeUsers = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users/active"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-success';
      case 'enroute':
        return 'bg-warning status-pulse';
      case 'onscene':
        return 'bg-purple-500';
      case 'virtual':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available':
        return 'Available';
      case 'enroute':
        return 'En Route';
      case 'onscene':
        return 'On Scene';
      case 'virtual':
        return 'Virtual';
      default:
        return 'Unknown';
    }
  };

  const getDistanceText = (user: User) => {
    if (user.currentLat && user.currentLng) {
      // Mock distance calculation - in production would use actual geolocation
      const mockDistance = Math.random() * 5;
      return `${mockDistance.toFixed(1)} mi away`;
    }
    return 'Location unknown';
  };

  const handleContactMember = (user: User) => {
    // Navigate to messages page for team communication
    setLocation('/messages');
  };

  if (isLoading) {
    return (
      <section className="px-4 mb-6">
        <Card className="bg-surface border-gray-600">
          <CardContent className="p-4">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-secondary"></div>
              <span className="ml-2 text-gray-400">Loading team status...</span>
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="px-4 mb-6">
      <Card className="bg-surface border-gray-600" data-testid="card-team-status">
        <CardHeader className="pb-3">
          <CardTitle className="font-semibold flex items-center text-text-primary">
            <Users className="h-5 w-5 mr-2 text-secondary" />
            Team Status
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          {activeUsers.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No active team members</p>
            </div>
          ) : (
            <div className="space-y-2">
              {activeUsers.map((user) => (
                <div 
                  key={user.id} 
                  className="bg-gray-700 p-3 rounded-lg flex items-center justify-between transition-colors hover:bg-gray-600"
                  data-testid={`team-member-${user.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 ${getStatusColor(user.status)} rounded-full`}></div>
                    <div>
                      <p className="font-medium text-sm text-text-primary" data-testid={`member-name-${user.id}`}>
                        {user.name}
                      </p>
                      <p className="text-xs text-gray-400" data-testid={`member-status-${user.id}`}>
                        {getStatusText(user.status)} • {getDistanceText(user)}
                      </p>
                    </div>
                  </div>
                  <Button 
                    onClick={() => handleContactMember(user)}
                    variant="ghost"
                    size="sm"
                    className="text-secondary hover:text-orange-400 transition-colors p-1"
                    data-testid={`button-contact-${user.id}`}
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
