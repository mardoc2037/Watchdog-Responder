import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X, MessageSquare } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";

interface SOSAlert {
  userId: string;
  userName: string;
  userRole: string;
  message: string;
  timestamp: string;
  priority: 'CRITICAL';
}

export default function SOSAlertBanner() {
  const [sosAlert, setSOSAlert] = useState<SOSAlert | null>(null);
  const [isDismissed, setIsDismissed] = useState(false);
  const { sendMessage } = useWebSocket();

  useEffect(() => {
    // Listen for SOS alerts via WebSocket
    const handleMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'priority_sos') {
          setSOSAlert(data);
          setIsDismissed(false);
          
          // Auto-dismiss after 30 seconds if not manually dismissed
          setTimeout(() => {
            setIsDismissed(true);
          }, 30000);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message in SOS banner:', error);
      }
    };

    // Note: This is a simplified WebSocket listener
    // In a real implementation, this would be integrated with the main WebSocket hook
    
    return () => {
      // Cleanup if needed
    };
  }, []);

  const handleDismiss = () => {
    setIsDismissed(true);
  };

  const handleRespond = () => {
    if (!sosAlert) return;
    
    // Send acknowledgment via WebSocket
    sendMessage({
      type: 'sos_acknowledgment',
      originalUserId: sosAlert.userId,
      responderId: 'current-user-id', // Would get from session
      timestamp: new Date().toISOString(),
    });
    
    setIsDismissed(true);
  };

  // Don't show if no alert or dismissed
  if (!sosAlert || isDismissed) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 p-4">
      <Card className="bg-destructive border-2 border-red-400 shadow-2xl animate-pulse">
        <CardContent className="p-4">
          <div className="flex items-start justify-between text-white">
            <div className="flex items-start space-x-3 flex-1">
              <AlertTriangle className="h-6 w-6 text-yellow-300 animate-bounce mt-1" />
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="text-lg font-bold">🚨 PRIORITY SOS ALERT</h3>
                  <span className="text-xs bg-red-600 px-2 py-1 rounded">CRITICAL</span>
                </div>
                
                <div className="mb-2">
                  <p className="font-semibold">
                    {sosAlert.userName} ({sosAlert.userRole.toUpperCase()})
                  </p>
                  <p className="text-sm text-gray-200">
                    {new Date(sosAlert.timestamp).toLocaleTimeString()}
                  </p>
                </div>
                
                <p className="text-sm bg-red-800 p-2 rounded">
                  {sosAlert.message}
                </p>
              </div>
            </div>
            
            <div className="flex space-x-2 ml-4">
              <Button
                onClick={handleRespond}
                className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1"
                data-testid="button-respond-sos"
              >
                <MessageSquare className="h-3 w-3 mr-1" />
                RESPOND
              </Button>
              <Button
                onClick={handleDismiss}
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-red-600 text-xs px-2 py-1"
                data-testid="button-dismiss-sos"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}