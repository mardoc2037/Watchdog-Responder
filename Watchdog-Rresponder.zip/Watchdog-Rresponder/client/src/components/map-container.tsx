import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Route, Share2, Crosshair } from "lucide-react";

interface MapContainerProps {
  location: { lat: number; lng: number } | null;
}

export default function MapContainer({ location }: MapContainerProps) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const centerMap = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log("Centering map to:", position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const getDirections = () => {
    if (location) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`;
      window.open(url, '_blank');
    }
  };

  const shareLocation = () => {
    if (location && navigator.share) {
      navigator.share({
        title: 'My Current Location',
        text: `I'm currently at: ${location.lat}, ${location.lng}`,
        url: `https://www.google.com/maps/@${location.lat},${location.lng},15z`,
      }).catch(console.error);
    } else if (location) {
      // Fallback for browsers without Web Share API
      const url = `https://www.google.com/maps/@${location.lat},${location.lng},15z`;
      navigator.clipboard.writeText(url).then(() => {
        console.log('Location URL copied to clipboard');
      }).catch(console.error);
    }
  };

  return (
    <section className="px-4 mb-6">
      <Card className="bg-surface border-gray-600" data-testid="card-map-container">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-semibold flex items-center text-text-primary">
              <MapPin className="h-5 w-5 mr-2 text-secondary" />
              Location & Navigation
            </CardTitle>
            <Button
              onClick={centerMap}
              variant="ghost"
              size="sm"
              className="text-secondary hover:text-orange-400 transition-colors p-1"
              data-testid="button-center-map"
            >
              <Crosshair className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Map Placeholder - In production this would be React-Leaflet */}
          <div className="h-64 bg-gray-700 relative rounded-lg overflow-hidden" data-testid="map-display">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-secondary mx-auto mb-2"></div>
                  <p className="text-gray-400">Loading Map...</p>
                  {location && (
                    <p className="text-xs text-gray-500 mt-1">
                      GPS: {location.lat.toFixed(4)}° N, {location.lng.toFixed(4)}° W
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-12 w-12 text-gray-500 mx-auto mb-2" />
                  <p className="text-gray-400">Interactive Map</p>
                  {location ? (
                    <p className="text-xs text-gray-500">
                      Current: {location.lat.toFixed(4)}°N, {location.lng.toFixed(4)}°W
                    </p>
                  ) : (
                    <p className="text-xs text-gray-500">Location not available</p>
                  )}
                </div>
              </div>
            )}
            
            {/* Current location marker */}
            {location && !isLoading && (
              <div 
                className="absolute top-4 left-4 w-4 h-4 bg-success rounded-full border-2 border-white shadow-lg status-pulse"
                data-testid="marker-current-location"
              ></div>
            )}
            
            {/* Mock dispatch location marker */}
            {!isLoading && (
              <div 
                className="absolute bottom-4 right-4 w-4 h-4 bg-secondary rounded-full border-2 border-white shadow-lg"
                data-testid="marker-dispatch-location"
              ></div>
            )}
          </div>
          
          {/* Navigation Controls */}
          <div className="flex space-x-2 mt-4">
            <Button 
              onClick={getDirections}
              disabled={!location}
              className="flex-1 bg-primary hover:bg-blue-700 text-white transition-colors"
              data-testid="button-get-directions"
            >
              <Route className="h-4 w-4 mr-2" />
              Get Directions
            </Button>
            <Button 
              onClick={shareLocation}
              disabled={!location}
              variant="outline"
              className="bg-surface hover:bg-gray-600 border-gray-600 text-gray-300 transition-colors"
              data-testid="button-share-location"
            >
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
