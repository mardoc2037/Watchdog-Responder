import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, Phone, FolderPlus, Camera, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function QuickActions() {
  const [, setLocation] = useLocation();

  const handleEmergencyContacts = () => {
    // Navigate to profile page where emergency contacts would be managed
    setLocation('/profile');
  };

  const handleCreateCase = () => {
    // Navigate to cases page where users can create new cases
    setLocation('/cases');
  };

  const handleUploadEvidence = () => {
    // Navigate to cases page where evidence can be uploaded
    setLocation('/cases');
  };

  const handleTeamMessaging = () => {
    // Navigate to messages page for team communication
    setLocation('/messages');
  };

  const actionButtons = [
    {
      id: 'emergency',
      icon: Phone,
      label: 'Emergency',
      subtitle: 'Contacts',
      color: 'text-destructive',
      bgColor: 'hover:bg-red-900/20',
      action: handleEmergencyContacts,
      testId: 'button-emergency-contacts',
    },
    {
      id: 'case',
      icon: FolderPlus,
      label: 'New Case',
      subtitle: 'Create File',
      color: 'text-success',
      bgColor: 'hover:bg-green-900/20',
      action: handleCreateCase,
      testId: 'button-create-case',
    },
    {
      id: 'evidence',
      icon: Camera,
      label: 'Evidence',
      subtitle: 'Upload',
      color: 'text-warning',
      bgColor: 'hover:bg-yellow-900/20',
      action: handleUploadEvidence,
      testId: 'button-upload-evidence',
    },
    {
      id: 'messaging',
      icon: MessageCircle,
      label: 'Team Chat',
      subtitle: 'Secure Msg',
      color: 'text-blue-500',
      bgColor: 'hover:bg-blue-900/20',
      action: handleTeamMessaging,
      testId: 'button-team-messaging',
    },
  ];

  return (
    <section className="px-4 mb-6">
      <Card className="bg-surface border-gray-600" data-testid="card-quick-actions">
        <CardHeader className="pb-3">
          <CardTitle className="font-semibold flex items-center text-text-primary">
            <Zap className="h-5 w-5 mr-2 text-secondary" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {actionButtons.map((button) => {
              const Icon = button.icon;
              return (
                <Button
                  key={button.id}
                  onClick={button.action}
                  variant="ghost"
                  className={`h-auto p-4 bg-gray-700 hover:bg-gray-600 ${button.bgColor} transition-all text-center flex flex-col items-center justify-center space-y-2`}
                  data-testid={button.testId}
                >
                  <Icon className={`h-6 w-6 ${button.color} mb-1`} />
                  <div>
                    <p className="text-sm font-medium text-text-primary">{button.label}</p>
                    <p className="text-xs text-gray-400">{button.subtitle}</p>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
