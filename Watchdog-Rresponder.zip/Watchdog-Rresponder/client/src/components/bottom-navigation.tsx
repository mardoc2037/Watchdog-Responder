import { Link, useLocation } from "wouter";
import { Home, FolderOpen, Map, MessageCircle, User, Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface BottomNavigationProps {
  currentPath: string;
}

export default function BottomNavigation({ currentPath }: BottomNavigationProps) {
  const [location] = useLocation();
  
  const { data: unreadCount = { count: 0 } } = useQuery<{ count: number }>({
    queryKey: ["/api/messages/unread/count"],
  });

  const navItems = [
    {
      path: "/",
      icon: Home,
      label: "Dashboard",
      testId: "nav-dashboard",
    },
    {
      path: "/cases",
      icon: FolderOpen,
      label: "Cases",
      testId: "nav-cases",
    },
    {
      path: "/map",
      icon: Map,
      label: "Map",
      testId: "nav-map",
    },
    {
      path: "/messages",
      icon: MessageCircle,
      label: "Messages",
      badge: unreadCount.count > 0 ? unreadCount.count : null,
      testId: "nav-messages",
    },
    {
      path: "/admin-portal",
      icon: Shield,
      label: "Admin",
      testId: "nav-admin",
    },
    {
      path: "/profile",
      icon: User,
      label: "Profile",
      testId: "nav-profile",
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-surface border-t border-gray-600 z-40">
      <div className="flex">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
          
          return (
            <Link key={item.path} href={item.path} className="flex-1">
              <button 
                className={`w-full py-3 px-2 text-center hover:bg-gray-600 transition-colors relative ${
                  isActive ? 'border-t-2 border-secondary' : ''
                }`}
                data-testid={item.testId}
              >
                <Icon 
                  className={`h-5 w-5 mx-auto mb-1 ${
                    isActive ? 'text-secondary' : 'text-gray-400'
                  }`} 
                />
                <p className={`text-xs ${isActive ? 'font-medium text-text-primary' : 'text-gray-400'}`}>
                  {item.label}
                </p>
                
                {item.badge && (
                  <Badge 
                    className="absolute top-1 right-3 bg-destructive text-white text-xs w-5 h-5 flex items-center justify-center p-0 min-w-0"
                    data-testid={`badge-${item.testId}`}
                  >
                    {item.badge}
                  </Badge>
                )}
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
