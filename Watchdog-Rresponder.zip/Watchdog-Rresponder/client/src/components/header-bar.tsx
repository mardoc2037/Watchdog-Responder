import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, Bell, Power } from "lucide-react";
import { useLocation } from "wouter";
import type { User } from "@shared/schema";

interface HeaderBarProps {
  user?: User;
  currentStatus?: string;
  onStatusToggle?: () => void;
}

export default function HeaderBar({ user, currentStatus = "available", onStatusToggle }: HeaderBarProps) {
  const [, setLocation] = useLocation();
  
  const handleNotificationClick = () => {
    // Navigate to messages page for notifications
    setLocation('/messages');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-success';
      case 'enroute':
        return 'bg-warning';
      case 'onscene':
        return 'bg-purple-500';
      case 'virtual':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <header className="bg-primary shadow-lg relative z-50">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <Shield className="h-5 w-5 text-secondary" />
          <div>
            <h1 className="text-lg font-semibold text-white" data-testid="text-app-title">Watchdog Responder</h1>
            {user?.badge && (
              <p className="text-xs text-blue-200" data-testid="text-user-badge">Badge #{user.badge}</p>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleNotificationClick}
            className="relative" 
            data-testid="button-notifications"
          >
            <Bell className="h-5 w-5 text-white" />
            <span className="absolute -top-1 -right-1 bg-destructive text-xs rounded-full w-4 h-4 flex items-center justify-center text-white" data-testid="badge-notification-count">
              3
            </span>
          </button>
          
          <div className="w-8 h-8 rounded-full bg-secondary border-2 border-orange-300 flex items-center justify-center">
            <span className="text-white text-sm font-semibold" data-testid="avatar-initials">
              {user?.name?.charAt(0) || 'U'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="bg-surface px-4 py-2 border-t border-gray-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-3 h-3 ${getStatusColor(currentStatus)} rounded-full status-pulse`} data-testid="status-indicator"></div>
            <span className="text-sm font-medium text-text-primary" data-testid="text-current-status">
              {currentStatus.replace('_', ' ').toUpperCase()}
            </span>
            <span className="text-xs text-gray-400" data-testid="text-last-update">
              Updated {user?.lastStatusUpdate ? 
                new Date(user.lastStatusUpdate).toLocaleTimeString() : 
                '2 min ago'
              }
            </span>
          </div>
          
          <Button 
            onClick={onStatusToggle}
            className="bg-primary hover:bg-blue-700 px-3 py-1 rounded text-sm font-medium transition-colors text-white"
            data-testid="button-toggle-active"
          >
            <Power className="h-3 w-3 mr-1" />
            {user?.isActive ? 'Active' : 'Inactive'}
          </Button>
        </div>
      </div>
    </header>
  );
}
