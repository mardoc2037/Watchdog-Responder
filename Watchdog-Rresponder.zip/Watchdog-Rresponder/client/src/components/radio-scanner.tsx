import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Radio, Play, Pause, Volume2, VolumeX, Power, Signal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface RadioScannerProps {
  scannerUrl: string;
  username: string;
  password: string;
}

export default function RadioScanner({ scannerUrl, username, password }: RadioScannerProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState([75]);
  const [currentChannel, setCurrentChannel] = useState("Emergency Dispatch");
  const [signalStrength, setSignalStrength] = useState(0);
  const [lastActivity, setLastActivity] = useState<Date | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  // Simulate scanner activity
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isConnected && isPlaying) {
      interval = setInterval(() => {
        // Simulate signal strength changes
        setSignalStrength(Math.floor(Math.random() * 5) + 1);
        
        // Simulate occasional activity
        if (Math.random() < 0.1) {
          setLastActivity(new Date());
        }
      }, 2000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isConnected, isPlaying]);

  const connectToScanner = async () => {
    try {
      if (audioRef.current) {
        // Clear any existing source and event listeners
        audioRef.current.src = "";
        audioRef.current.load();
        
        // Set up event listeners before attempting to load
        const handleLoadStart = () => {
          console.log('Scanner audio loading started');
        };
        
        const handleCanPlay = () => {
          console.log('Scanner audio ready to play');
          setIsConnected(true);
          setLastActivity(new Date());
          toast({
            title: "Scanner Connected",
            description: "Radio feed ready - click Play to start monitoring",
          });
        };
        
        const handleError = (e: Event) => {
          console.error('Scanner audio error:', e);
          setIsConnected(false);
          toast({
            title: "Connection Error",
            description: "Scanner feed unavailable - check network connection",
            variant: "destructive",
          });
        };
        
        const handleStalled = () => {
          console.log('Scanner audio stream stalled, attempting reconnection...');
        };
        
        // Remove any existing listeners and add new ones
        audioRef.current.removeEventListener('loadstart', handleLoadStart);
        audioRef.current.removeEventListener('canplay', handleCanPlay);
        audioRef.current.removeEventListener('error', handleError);
        audioRef.current.removeEventListener('stalled', handleStalled);
        
        audioRef.current.addEventListener('loadstart', handleLoadStart);
        audioRef.current.addEventListener('canplay', handleCanPlay);
        audioRef.current.addEventListener('error', handleError);
        audioRef.current.addEventListener('stalled', handleStalled);
        
        // Use our backend proxy to avoid CORS issues
        audioRef.current.src = "/api/scanner/stream";
        audioRef.current.volume = volume[0] / 100;
        audioRef.current.preload = "none"; // Don't preload to avoid CORS issues
        
        // Load the audio source
        audioRef.current.load();
        
        toast({
          title: "Connecting...",
          description: "Establishing connection to scanner feed",
        });
      }
    } catch (error) {
      console.error('Scanner connection error:', error);
      toast({
        title: "Connection Failed",
        description: "Unable to initialize scanner connection",
        variant: "destructive",
      });
    }
  };

  const disconnectScanner = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
    }
    setIsConnected(false);
    setIsPlaying(false);
    setSignalStrength(0);
    
    toast({
      title: "Scanner Disconnected",
      description: "Radio feed stopped",
    });
  };

  const togglePlayback = async () => {
    if (!audioRef.current || !isConnected) {
      toast({
        title: "Not Connected",
        description: "Connect to scanner first",
        variant: "destructive",
      });
      return;
    }

    try {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
        toast({
          title: "Scanner Paused",
          description: "Audio monitoring paused",
        });
      } else {
        // Reset the audio source if needed
        if (audioRef.current.readyState === 0) {
          audioRef.current.load();
          await new Promise(resolve => {
            audioRef.current!.addEventListener('canplay', resolve, { once: true });
          });
        }
        
        await audioRef.current.play();
        setIsPlaying(true);
        setLastActivity(new Date());
        toast({
          title: "Scanner Active",
          description: "Now monitoring radio communications",
        });
      }
    } catch (error: any) {
      console.error('Audio play error:', error);
      let errorMessage = "Unable to start audio playback";
      
      if (error.name === 'NotAllowedError') {
        errorMessage = "Audio blocked by browser - click to enable";
      } else if (error.name === 'NotSupportedError') {
        errorMessage = "Audio format not supported";
      } else if (error.name === 'NetworkError') {
        errorMessage = "Network connection lost";
      }
      
      toast({
        title: "Playback Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (newVolume: number[]) => {
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume[0] / 100;
    }
  };

  return (
    <Card className="bg-surface border-gray-600">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-text-primary flex items-center justify-between">
          <div className="flex items-center">
            <Radio className="h-5 w-5 mr-2 text-secondary" />
            Radio Scanner
          </div>
          <Badge 
            className={`${
              isConnected ? 'bg-success' : 'bg-gray-500'
            } text-white`}
          >
            {isConnected ? 'ONLINE' : 'OFFLINE'}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Scanner Display */}
        <div className={`bg-black rounded-lg p-4 font-mono text-green-400 min-h-[120px] relative overflow-hidden ${
          isPlaying ? 'animate-pulse' : ''
        }`}>
          {/* Scanning Line Animation */}
          {isConnected && (
            <div className="absolute inset-0 pointer-events-none">
              <div className={`w-full h-0.5 bg-gradient-to-r from-transparent via-green-400 to-transparent ${
                isPlaying ? 'animate-scan-line' : 'animate-pulse'
              }`} 
              style={{
                position: 'absolute',
                top: '20%',
              }}></div>
            </div>
          )}
          
          <div className="flex items-center justify-between mb-2 relative z-10">
            <div className="flex items-center space-x-2">
              <Signal className={`h-4 w-4 ${isPlaying ? 'animate-bounce' : ''}`} />
              <div className="flex space-x-1">
                {[1, 2, 3, 4, 5].map((bar) => (
                  <div 
                    key={bar}
                    className={`w-2 transition-all duration-300 ${
                      bar <= signalStrength 
                        ? 'bg-green-400 animate-signal-bounce' 
                        : 'bg-gray-600'
                    }`}
                    style={{
                      height: `${8 + (bar * 2)}px`,
                      animationDelay: `${bar * 0.1}s`
                    }}
                  />
                ))}
              </div>
            </div>
            <div className={`text-xs transition-all duration-300 ${
              isConnected && lastActivity ? 'text-green-400 animate-pulse' : 'text-gray-500'
            }`}>
              {isConnected && lastActivity ? 
                `LAST: ${lastActivity.toLocaleTimeString()}` : 
                'NO SIGNAL'
              }
            </div>
          </div>
          
          <div className="text-center relative z-10">
            <div className="text-xs mb-1">CHANNEL</div>
            <div className={`text-lg font-bold transition-all duration-300 ${
              isPlaying ? 'text-yellow-400 animate-pulse' : ''
            }`}>
              {currentChannel}
            </div>
            <div className="text-xs mt-2 text-gray-400">
              {scannerUrl.replace(/^https?:\/\//, '').split('@')[1] || scannerUrl}
            </div>
          </div>

          {isPlaying && (
            <div className="mt-3 flex items-center justify-center relative z-10">
              <div className="relative">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <div className="absolute inset-0 w-3 h-3 bg-red-400 rounded-full animate-ping"></div>
              </div>
              <span className="text-xs ml-2 animate-pulse">RECEIVING</span>
              {/* Audio waves animation */}
              <div className="flex items-center ml-3 space-x-1">
                {[1, 2, 3, 4].map((wave) => (
                  <div
                    key={wave}
                    className="w-1 bg-green-400 rounded-full animate-bounce"
                    style={{
                      height: `${4 + Math.sin(Date.now() * 0.01 + wave) * 2}px`,
                      animationDelay: `${wave * 0.1}s`,
                      animationDuration: '0.6s'
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Scanner Controls */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={isConnected ? disconnectScanner : connectToScanner}
            className={`${
              isConnected 
                ? 'bg-destructive hover:bg-red-700' 
                : 'bg-success hover:bg-green-700'
            } text-white`}
            data-testid={isConnected ? "button-disconnect" : "button-connect"}
          >
            <Power className="h-4 w-4 mr-2" />
            {isConnected ? 'Disconnect' : 'Connect'}
          </Button>

          <Button
            onClick={togglePlayback}
            disabled={!isConnected}
            className="bg-blue-600 hover:bg-blue-700 text-white"
            data-testid="button-play-pause"
          >
            {isPlaying ? (
              <>
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Play
              </>
            )}
          </Button>
        </div>

        {/* Volume Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Volume</span>
            <Button
              onClick={toggleMute}
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              data-testid="button-mute"
            >
              {isMuted ? (
                <VolumeX className="h-4 w-4" />
              ) : (
                <Volume2 className="h-4 w-4" />
              )}
            </Button>
          </div>
          <Slider
            value={volume}
            onValueChange={handleVolumeChange}
            max={100}
            step={1}
            className="w-full"
            disabled={!isConnected}
          />
        </div>

        {/* Scanner Info */}
        <div className="text-xs text-gray-400 p-3 bg-gray-700 rounded-lg">
          <p className="mb-1"><strong>Emergency Radio Scanner</strong></p>
          <p className="mb-1">• Live monitoring of emergency communications</p>
          <p className="mb-1">• Multi-channel dispatch feed</p>
          <p>• Authentication: {username}@{scannerUrl.split('@')[1]?.split('/')[0] || 'server'}</p>
        </div>

        {/* Hidden Audio Element */}
        <audio
          ref={audioRef}
          preload="none"
          style={{ display: 'none' }}
          onError={(e) => {
            console.error('Scanner audio error:', e);
            toast({
              title: "Audio Error", 
              description: "Scanner audio stream error - check server connection",
              variant: "destructive",
            });
            setIsConnected(false);
            setIsPlaying(false);
          }}
          onLoadStart={() => {
            console.log('Scanner audio loading started');
          }}
          onCanPlay={() => {
            console.log('Scanner audio can play');
          }}
          onLoadedData={() => {
            console.log('Scanner audio data loaded');
          }}
        />
      </CardContent>
    </Card>
  );
}