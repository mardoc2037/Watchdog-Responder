export interface DispatchStatus {
  id: string;
  label: string;
  color: string;
  description: string;
}

export interface LocationCoordinates {
  lat: number;
  lng: number;
  accuracy?: number;
  timestamp?: Date;
}

export interface DispatchAlert {
  id: string;
  caseId: string;
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  location?: LocationCoordinates;
  locationName?: string;
  createdAt: Date;
  expiresAt?: Date;
}

export interface TeamMember {
  id: string;
  name: string;
  badge?: string;
  role: string;
  status: string;
  location?: LocationCoordinates;
  lastUpdate: Date;
  isActive: boolean;
}

export interface CaseEvidence {
  id: string;
  caseId: string;
  type: 'photo' | 'video' | 'document' | 'audio' | 'other';
  fileName: string;
  fileUrl: string;
  description?: string;
  uploadedBy: string;
  uploadedAt: Date;
  metadata?: Record<string, any>;
}

export interface CaseTimeline {
  id: string;
  caseId: string;
  type: 'status_change' | 'location_update' | 'evidence_added' | 'note_added' | 'assignment_changed';
  title: string;
  description: string;
  userId: string;
  userName: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface SecureMessage {
  id: string;
  senderId: string;
  senderName: string;
  recipientId?: string;
  recipientName?: string;
  caseId?: string;
  content: string;
  messageType: 'text' | 'image' | 'file' | 'location' | 'emergency';
  isRead: boolean;
  isEncrypted: boolean;
  createdAt: Date;
  metadata?: Record<string, any>;
}

export interface NotificationSettings {
  pushNotifications: boolean;
  audioAlerts: boolean;
  emergencyAlerts: boolean;
  caseUpdates: boolean;
  teamMessages: boolean;
  locationSharing: boolean;
}

export interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  email?: string;
  isPrimary: boolean;
  isActive: boolean;
}

export interface ResponseMetrics {
  totalResponses: number;
  averageResponseTime: number; // in minutes
  casesResolved: number;
  activeCases: number;
  hoursLogged: number;
  lastActiveDate: Date;
}

export interface DispatchEvent {
  type: 'status_update' | 'location_update' | 'new_dispatch' | 'case_update' | 'team_message' | 'emergency_alert';
  userId?: string;
  caseId?: string;
  timestamp: Date;
  data: Record<string, any>;
}

export const DISPATCH_STATUSES: DispatchStatus[] = [
  {
    id: 'available',
    label: 'Available',
    color: 'success',
    description: 'Ready for dispatch',
  },
  {
    id: 'enroute',
    label: 'En Route',
    color: 'warning',
    description: 'Traveling to scene',
  },
  {
    id: 'virtual',
    label: 'Virtual',
    color: 'blue',
    description: 'Remote assistance',
  },
  {
    id: 'onscene',
    label: 'On Scene',
    color: 'purple',
    description: 'Arrived at location',
  },
  {
    id: 'unavailable',
    label: 'Unavailable',
    color: 'gray',
    description: 'Not available for dispatch',
  },
];

export const USER_ROLES = [
  { id: 'admin', label: 'Administrator', color: 'destructive' },
  { id: 'responder', label: 'First Responder', color: 'primary' },
  { id: 'sar', label: 'SAR Team', color: 'secondary' },
  { id: 'legal', label: 'Legal Team', color: 'purple' },
  { id: 'veteran', label: 'Veteran', color: 'green' },
] as const;

export const CASE_PRIORITIES = [
  { id: 'high', label: 'High', color: 'destructive' },
  { id: 'medium', label: 'Medium', color: 'warning' },
  { id: 'low', label: 'Low', color: 'success' },
] as const;

export const MESSAGE_TYPES = [
  { id: 'text', label: 'Text Message' },
  { id: 'image', label: 'Image' },
  { id: 'file', label: 'File Attachment' },
  { id: 'location', label: 'Location Share' },
  { id: 'emergency', label: 'Emergency Alert' },
] as const;

// Utility functions
export function getStatusConfig(statusId: string): DispatchStatus | undefined {
  return DISPATCH_STATUSES.find(status => status.id === statusId);
}

export function formatLocationString(coords: LocationCoordinates): string {
  return `${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)}`;
}

export function calculateDistance(point1: LocationCoordinates, point2: LocationCoordinates): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (point2.lat - point1.lat) * Math.PI / 180;
  const dLon = (point2.lng - point1.lng) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(point1.lat * Math.PI / 180) * Math.cos(point2.lat * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in miles
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
}
