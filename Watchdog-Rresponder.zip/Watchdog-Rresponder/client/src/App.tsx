import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Cases from "@/pages/cases";
import MapPage from "@/pages/map";
import Messages from "@/pages/messages";
import Profile from "@/pages/profile";
import AdminPage from "@/pages/admin";
import AdminPortalPage from "@/pages/admin-portal";

import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/cases" component={Cases} />
      <Route path="/map" component={MapPage} />
      <Route path="/messages" component={Messages} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/admin-portal" component={AdminPortalPage} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark min-h-screen bg-dark-bg text-text-primary">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
