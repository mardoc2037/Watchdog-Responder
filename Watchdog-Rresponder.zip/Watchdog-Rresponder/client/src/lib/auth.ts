import { apiRequest } from "./queryClient";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  badge?: string;
  role: string;
  isActive: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  name: string;
  password: string;
  badge?: string;
  role: string;
}

class AuthService {
  private currentUser: AuthUser | null = null;

  async login(credentials: LoginCredentials): Promise<AuthUser> {
    try {
      const response = await apiRequest("POST", "/api/auth/login", credentials);
      const user = await response.json();
      this.currentUser = user;
      return user;
    } catch (error) {
      throw new Error("Invalid credentials");
    }
  }

  async register(data: RegisterData): Promise<AuthUser> {
    try {
      const response = await apiRequest("POST", "/api/auth/register", data);
      const user = await response.json();
      this.currentUser = user;
      return user;
    } catch (error) {
      throw new Error("Registration failed");
    }
  }

  async logout(): Promise<void> {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      this.currentUser = null;
    } catch (error) {
      console.error("Logout error:", error);
      // Clear local state even if server request fails
      this.currentUser = null;
    }
  }

  async getCurrentUser(): Promise<AuthUser | null> {
    if (this.currentUser) {
      return this.currentUser;
    }

    try {
      const response = await apiRequest("GET", "/api/auth/me", {});
      const user = await response.json();
      this.currentUser = user;
      return user;
    } catch (error) {
      return null;
    }
  }

  async refreshToken(): Promise<string | null> {
    try {
      const response = await apiRequest("POST", "/api/auth/refresh", {});
      const data = await response.json();
      return data.token;
    } catch (error) {
      return null;
    }
  }

  async googleAuth(): Promise<AuthUser> {
    try {
      // Redirect to Google OAuth endpoint
      window.location.href = "/api/auth/google";
      // This will redirect, so we'll never reach this return
      throw new Error("Redirecting to Google OAuth");
    } catch (error) {
      throw new Error("Google authentication failed");
    }
  }

  isAuthenticated(): boolean {
    return this.currentUser !== null;
  }

  getUser(): AuthUser | null {
    return this.currentUser;
  }

  hasRole(role: string): boolean {
    return this.currentUser?.role === role;
  }

  hasAnyRole(roles: string[]): boolean {
    return this.currentUser ? roles.includes(this.currentUser.role) : false;
  }

  canAccessAdmin(): boolean {
    return this.hasRole('admin');
  }

  canAccessSAR(): boolean {
    return this.hasAnyRole(['admin', 'sar']);
  }

  canAccessLegal(): boolean {
    return this.hasAnyRole(['admin', 'legal']);
  }
}

export const auth = new AuthService();

// Helper function to check if user has permission for specific actions
export function checkPermission(action: string, resource?: string): boolean {
  const user = auth.getUser();
  if (!user) return false;

  switch (action) {
    case 'create_case':
      return auth.hasAnyRole(['admin', 'responder', 'sar']);
    
    case 'update_case':
      return auth.hasAnyRole(['admin', 'responder', 'sar']);
    
    case 'delete_case':
      return auth.hasRole('admin');
    
    case 'access_evidence':
      return auth.hasAnyRole(['admin', 'responder', 'sar', 'legal']);
    
    case 'manage_users':
      return auth.hasRole('admin');
    
    case 'view_sensitive_info':
      return auth.hasAnyRole(['admin', 'legal']);
    
    default:
      return false;
  }
}

// Environment variables for OAuth configuration
export const OAUTH_CONFIG = {
  GOOGLE_CLIENT_ID: import.meta.env.VITE_GOOGLE_CLIENT_ID || "",
  OAUTH_REDIRECT_URI: import.meta.env.VITE_OAUTH_REDIRECT_URI || `${window.location.origin}/auth/callback`,
};
